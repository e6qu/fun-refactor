#!/usr/bin/env python3
"""Check current documentation links and refresh generated prose on a runner."""
import argparse
import importlib.util
import json
import os
from pathlib import Path
import re
import subprocess
from urllib.parse import unquote, urlsplit

ROOT = Path(__file__).resolve().parents[1]


def guides():
    return (sorted(ROOT.glob('*.md')) + sorted((ROOT / 'docs').glob('*.md'))
            + sorted((ROOT / 'skills/fr').rglob('*.md'))
            + [ROOT / name for name in ('sdk/python/README.md', 'queries/README.md',
                                       'vendor/README.md', 'wasm-shim/README.md',
                                       'web/README.md', 'grammars/README.md',
                                       'tests/agent-eval/EVIDENCE-ARCHIVES.md',
                                       'tests/agent-eval/PROVENANCE.md',
                                       'tests/corpus/PROVENANCE.md',
                                       'tests/framework-corpus/PROVENANCE.md',
                                       'tests/agent-eval/python-repository-flow/README.md',
                                       'tests/agent-eval/opencode/repositories/README.md',
                                       'crates/tree-sitter-language/README.md')])


def prose(text):
    lines, fence = [], None
    for line in text.splitlines():
        marker = re.match(r'^\s*(`{3,}|~{3,})(.*)$', line)
        if marker:
            run, rest = marker.groups()
            if fence is None:
                fence = run
            elif run[0] == fence[0] and len(run) >= len(fence) and not rest.strip():
                fence = None
            continue
        if fence is None:
            lines.append(line)
    if fence is not None:
        raise ValueError('unclosed code fence')
    return '\n'.join(lines)


def anchors(text):
    found, counts = set(), {}
    for line in prose(text).splitlines():
        heading = re.match(r'^\s{0,3}#{1,6}\s+(.+?)\s*#*\s*$', line)
        if heading:
            label = re.sub(r'\[([^\]]+)\]\([^)]*\)', r'\1', heading[1])
            value = re.sub(r'[^\w\s-]', '', label.lower()).replace(' ', '-')
            number = counts.get(value, 0)
            counts[value] = number + 1
            found.add(value if number == 0 else f'{value}-{number}')
    found.update(re.findall(r'<a\s+[^>]*?(?:id|name)=[\"\']([^\"\']+)', text))
    return found


def links(path):
    text = prose(path.read_text())
    text = re.sub(r'(`+).*?\1', '', text)
    return [match[1] for match in re.finditer(r'\[[^\]\n]*\]\(<?([^\s)>]+)>?(?:\s+[^)]*)?\)', text)] + [
        match[1] for match in re.finditer(r'^\s{0,3}\[[^\]]+\]:\s*<?([^\s>]+)>?', text, re.M)]


def check_links():
    failures, seen = [], {}
    pages = guides()
    edges = {page: set() for page in pages}
    for page in pages:
        try:
            targets = links(page)
        except ValueError as error:
            failures.append(f'{page.relative_to(ROOT)}: {error}')
            continue
        for target in targets:
            url = urlsplit(target)
            if url.scheme or url.netloc:
                continue
            child = (page.parent / unquote(url.path)).resolve() if url.path else page
            if not child.is_relative_to(ROOT) or not child.exists():
                failures.append(f'{page.relative_to(ROOT)}: missing {target}')
            elif url.fragment and child.suffix == '.md':
                if child not in seen:
                    seen[child] = anchors(child.read_text())
                if unquote(url.fragment) not in seen[child]:
                    failures.append(f'{page.relative_to(ROOT)}: missing heading {target}')
            if child in edges:
                edges[page].add(child)
    reachable, pending = {ROOT / 'README.md'}, [ROOT / 'README.md']
    while pending:
        for child in edges[pending.pop()]:
            if child not in reachable:
                reachable.add(child)
                pending.append(child)
    for page in pages:
        if page.parent in (ROOT, ROOT / 'docs') and page not in reachable:
            failures.append(f'{page.relative_to(ROOT)}: no link path from README.md')
    if failures:
        raise ValueError('\n'.join(failures))
    from reader_examples import check_measurements
    check_measurements()
    print(f'Checked local links and headings in {len(pages)} current guides.')


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, ROOT / path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def refresh():
    if os.environ.get('GITHUB_ACTIONS') != 'true':
        raise ValueError('Refresh documentation on GitHub runners.')
    from agent_eval import native_outcomes, native_read_outcomes
    for stem, module in [('native-change', native_outcomes), ('native-read', native_read_outcomes)]:
        report = json.loads((ROOT / f'tests/agent-eval/opencode/{stem}-outcomes.json').read_text())
        (ROOT / f'docs/{stem}-outcomes.md').write_text(module.markdown(report['cohorts']))
    protocol = load('doc_context_protocol', 'tools/agent-context-protocol-v3.py')
    projection = protocol.measure(protocol.v2.harness.tokenizer())
    (ROOT / 'tests/agent-eval/context-protocol-v3.json').write_text(
        json.dumps(projection, indent=2, ensure_ascii=False) + '\n')
    subprocess.run(['python3', '-B', 'tools/roadmap-status.py', '--write'], cwd=ROOT, check=True, timeout=60)
    check = load('doc_prose', 'tools/check-prose.py')
    counts, budget = check.gather(), check.read_budget()
    rising = {key: value for key, value in counts.items() if value > budget[key]}
    if rising:
        for name in check.DOCS:
            path = ROOT / name
            text = path.read_text()
            for key, pattern, _ in check.RULES:
                if key in rising and pattern:
                    for match in re.finditer(pattern, text, re.I):
                        line = text[:match.start()].count('\n') + 1
                        print(f'{name}:{line}: {key}: {match[0]}', flush=True)
            if 'long-sentence' in rising:
                for paragraph in re.split(r'\n\s*\n', text):
                    for sentence in re.split(r'(?<=[.!?])\s+', paragraph):
                        if len(sentence.split()) > 25:
                            print(f'{name}: long sentence: {sentence[:220]}', flush=True)
        raise ValueError(f'Improve the prose; do not raise its budgets: {rising}')
    text = check.BUDGET.read_text()
    for key, value in counts.items():
        text = re.sub(rf'^{re.escape(key)} \d+$', f'{key} {value}', text, flags=re.M)
    check.BUDGET.write_text(text)
    print('Updated generated prose and lowered only improved writing counts.')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--write', action='store_true')
    args = parser.parse_args()
    if args.write:
        refresh()
    check_links()


if __name__ == '__main__':
    try:
        main()
    except (OSError, ValueError) as error:
        raise SystemExit(str(error))
