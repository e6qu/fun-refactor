//! Durable, checked workspace transactions for the native CLI.

use crate::edit::{CommitLocks, FileChange};
use anyhow::{bail, ensure, Context, Result};
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use std::fs::{self, File};
use std::io::{Read, Write};
use std::os::unix::ffi::OsStrExt;
use std::os::unix::fs::PermissionsExt;
use std::path::{Component, Path, PathBuf};

mod failure;
pub mod files;
mod host;
pub use failure::{FailureOutcome, FailurePhase, HistoryFailure};
use host::install;
mod patch;
pub use patch::{
    check_git_patch, check_patch_basis, export_patch, git_mode, git_mode_change_supported,
    git_snapshot_mode, matches_patch_basis, owner_executable_mode, GitPatchCheck, PatchBasisCheck,
    PatchBasisFile, PatchExport,
};

const DIRECTORY: &str = ".fr-history";

fn workspace(root: &Path) -> Result<PathBuf> {
    let root = root.canonicalize()?;
    Ok(if root.is_file() {
        root.parent()
            .context("file root has no parent")?
            .to_path_buf()
    } else {
        root
    })
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Snapshot {
    pub content: String,
    pub mode: u32,
    #[serde(default, skip_serializing_if = "SnapshotKind::is_regular")]
    pub kind: SnapshotKind,
}

#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "kebab-case")]
pub enum SnapshotKind {
    #[default]
    Regular,
    Symlink,
}

impl SnapshotKind {
    fn is_regular(&self) -> bool {
        *self == Self::Regular
    }
}

impl Snapshot {
    pub(crate) fn reported_mode(&self) -> Option<u32> {
        (self.kind == SnapshotKind::Regular).then_some(self.mode)
    }
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Change {
    pub path: PathBuf,
    pub before: Option<Snapshot>,
    pub after: Option<Snapshot>,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "kebab-case")]
pub enum Status {
    Planned,
    Applied,
    Undone,
    Abandoned,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Record {
    pub id: u64,
    pub status: Status,
    pub basis: String,
    pub source_revision: String,
    pub validation: String,
    pub changes: Vec<Change>,
    #[serde(default, skip_serializing_if = "is_zero")]
    pub compacted_paths: usize,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub compaction_digest: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub required_checks: Option<CheckRequirement>,
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub check_evidence: Vec<CheckEvidence>,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct CheckRequirement {
    pub configuration_basis: String,
    pub checks: Vec<String>,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct CheckEvidence {
    pub receipt: String,
    pub configuration_basis: String,
    pub source_revision: String,
    pub checks: Vec<String>,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize, Deserialize, clap::ValueEnum)]
#[serde(rename_all = "kebab-case")]
pub enum Action {
    Apply,
    Undo,
    Redo,
    Recover,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Pending {
    pub id: u64,
    pub action: Action,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct History {
    pub schema: u32,
    pub root: PathBuf,
    pub records: Vec<Record>,
    pub applied: Vec<u64>,
    pub redo: Vec<u64>,
    pub pending: Option<Pending>,
}

fn is_zero(value: &usize) -> bool {
    *value == 0
}

pub fn record_compactable(detailed: bool, pending: bool, retained: bool, planned: bool) -> bool {
    detailed && !pending && !retained && !planned
}

fn regular(path: &Path) -> Result<bool> {
    match fs::symlink_metadata(path) {
        Ok(meta) if meta.is_file() => Ok(true),
        Ok(_) => bail!("{} is not a regular file", path.display()),
        Err(e) if e.kind() == std::io::ErrorKind::NotFound => Ok(false),
        Err(e) => Err(e.into()),
    }
}

fn snapshot(path: &Path) -> Result<Option<Snapshot>> {
    let metadata = match fs::symlink_metadata(path) {
        Ok(metadata) => metadata,
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => return Ok(None),
        Err(error) => return Err(error.into()),
    };
    if metadata.file_type().is_symlink() {
        let target = fs::read_link(path)?;
        let content = target
            .to_str()
            .with_context(|| format!("symlink target must use UTF-8: {}", path.display()))?
            .to_owned();
        validate_symlink_target(&content)?;
        return Ok(Some(Snapshot {
            content,
            mode: 0,
            kind: SnapshotKind::Symlink,
        }));
    }
    if !metadata.is_file() {
        bail!("{} is neither a regular file nor a symlink", path.display());
    }
    Ok(Some(Snapshot {
        content: crate::vfs::read_to_string(path)
            .with_context(|| format!("reading snapshot for {}", path.display()))?,
        mode: metadata.permissions().mode() & 0o7777,
        kind: SnapshotKind::Regular,
    }))
}

fn validate_symlink_target(target: &str) -> Result<()> {
    if target.is_empty() || target.len() > 1023 || target.contains('\0') {
        bail!("symlink targets require between 1 and 1023 UTF-8 bytes without NUL");
    }
    Ok(())
}

fn directory(root: &Path) -> Result<PathBuf> {
    let dir = root.join(DIRECTORY);
    match fs::symlink_metadata(&dir) {
        Ok(meta) if meta.is_dir() => (),
        Ok(_) => bail!("{} must be a real directory", dir.display()),
        Err(e) if e.kind() == std::io::ErrorKind::NotFound => (),
        Err(e) => return Err(e.into()),
    }
    Ok(dir)
}

fn target(root: &Path, relative: &Path) -> Result<PathBuf> {
    if relative.as_os_str().is_empty()
        || relative
            .components()
            .any(|part| !matches!(part, Component::Normal(_)))
        || relative
            .components()
            .any(|part| matches!(part.as_os_str().to_str(), Some(".fr-history" | ".git")))
    {
        bail!("invalid history target {}", relative.display());
    }
    let mut path = root.to_path_buf();
    let mut components = relative.components().peekable();
    while let Some(component) = components.next() {
        path.push(component);
        match fs::symlink_metadata(&path) {
            Ok(meta) if meta.file_type().is_symlink() && components.peek().is_some() => {
                bail!("history target traverses a symlink: {}", path.display())
            }
            Ok(_) => (),
            Err(e) if e.kind() == std::io::ErrorKind::NotFound => (),
            Err(e) => return Err(e.into()),
        }
    }
    Ok(path)
}

impl History {
    pub fn read(root: &Path) -> Result<Self> {
        let root = workspace(root)?;
        let path = directory(&root)?.join("state.json");
        if !regular(&path)? {
            return Ok(Self {
                schema: 1,
                root,
                records: Vec::new(),
                applied: Vec::new(),
                redo: Vec::new(),
                pending: None,
            });
        }
        let history: Self = serde_json::from_str(&crate::vfs::read_to_string(&path)?)
            .context("reading transaction history; preserve the journal for recovery")?;
        if history.schema != 1 || history.root != root {
            bail!("unsupported history version or different workspace root");
        }
        let mut ids = std::collections::BTreeSet::new();
        for record in &history.records {
            let detailed = !record.changes.is_empty();
            if record.id == 0
                || !ids.insert(record.id)
                || !sha256_text(&record.basis)
                || (detailed && record.basis != basis(&record.changes)?)
            {
                bail!("invalid transaction identity or basis");
            }
            if !((detailed && record.compacted_paths == 0 && record.compaction_digest.is_none())
                || (!detailed
                    && record.compacted_paths > 0
                    && record.status != Status::Planned
                    && record.compaction_digest.as_deref()
                        == Some(compaction_digest(record)?.as_str())))
            {
                bail!("invalid transaction payload or compaction summary");
            }
            let mut paths = std::collections::BTreeSet::new();
            for change in &record.changes {
                target(&root, &change.path)?;
                if !paths.insert(&change.path) || change.before == change.after {
                    bail!("duplicate or unchanged history target");
                }
                for state in [&change.before, &change.after].into_iter().flatten() {
                    if state.kind == SnapshotKind::Regular && state.mode > 0o7777 {
                        bail!("invalid recorded file mode");
                    }
                    if state.kind == SnapshotKind::Symlink {
                        if state.mode != 0 {
                            bail!("invalid recorded symlink mode");
                        }
                        validate_symlink_target(&state.content)?;
                    }
                }
            }
            if let Some(requirement) = &record.required_checks {
                let mut names = std::collections::BTreeSet::new();
                if !sha256_text(&requirement.configuration_basis)
                    || requirement.checks.is_empty()
                    || requirement.checks.len() > 32
                    || requirement.checks.iter().any(|name| {
                        name.is_empty()
                            || name.len() > 64
                            || !name
                                .bytes()
                                .all(|byte| byte.is_ascii_alphanumeric() || b"_-".contains(&byte))
                            || !names.insert(name)
                    })
                {
                    bail!("invalid required check selection.");
                }
            }
            let mut receipts = std::collections::BTreeSet::new();
            for evidence in &record.check_evidence {
                let mut names = std::collections::BTreeSet::new();
                if !sha256_text(&evidence.configuration_basis)
                    || !sha256_text(&evidence.source_revision)
                    || evidence.checks.is_empty()
                    || evidence.checks.len() > 32
                    || evidence.checks.iter().any(|name| {
                        name.is_empty()
                            || name.len() > 64
                            || !name
                                .bytes()
                                .all(|byte| byte.is_ascii_alphanumeric() || b"_-".contains(&byte))
                            || !names.insert(name)
                    })
                    || evidence.receipt
                        != check_evidence_receipt(
                            &evidence.configuration_basis,
                            &evidence.source_revision,
                            &evidence.checks,
                        )?
                    || !receipts.insert(&evidence.receipt)
                {
                    bail!("invalid recorded check evidence.");
                }
            }
        }
        let mut active = std::collections::BTreeSet::new();
        for (stack, status) in [
            (&history.applied, Status::Applied),
            (&history.redo, Status::Undone),
        ] {
            for id in stack {
                if !active.insert(id)
                    || history.record(*id)?.status != status
                    || history.record(*id)?.changes.is_empty()
                {
                    bail!("invalid transaction stack");
                }
            }
        }
        for record in &history.records {
            if !record.changes.is_empty()
                && matches!(record.status, Status::Applied | Status::Undone)
                && !active.contains(&record.id)
            {
                bail!("transaction is missing from its stack");
            }
        }
        if let Some(pending) = &history.pending {
            history.check_action(pending.action, pending.id)?;
        }
        Ok(history)
    }

    pub fn record(&self, id: u64) -> Result<&Record> {
        self.records
            .iter()
            .find(|r| r.id == id)
            .context("unknown transaction identity")
    }

    pub fn ensure_ready(&self) -> Result<()> {
        if let Some(pending) = &self.pending {
            bail!(
                "transaction {} needs recovery; run `fr history recover {} --write`",
                pending.id,
                pending.id
            );
        }
        Ok(())
    }

    fn save(&self) -> Result<()> {
        host::save(self)
    }

    fn check_action(&self, action: Action, id: u64) -> Result<()> {
        let record = self.record(id)?;
        let valid = match action {
            Action::Apply => record.status == Status::Planned,
            Action::Undo => self.applied.last() == Some(&id),
            Action::Redo => self.redo.last() == Some(&id),
            Action::Recover => false,
        };
        if !valid {
            bail!(
                "transaction {id} cannot {action:?} from {:?}; undo and redo follow stack order",
                record.status
            );
        }
        Ok(())
    }

    fn finish(&mut self, action: Action, id: u64) {
        match action {
            Action::Apply => {
                for record in &mut self.records {
                    if self.redo.contains(&record.id) {
                        record.status = Status::Abandoned;
                    }
                }
                self.redo.clear();
                self.applied.push(id);
            }
            Action::Redo => {
                self.redo.pop();
                self.applied.push(id);
            }
            Action::Undo => {
                self.applied.pop();
                self.redo.push(id);
            }
            Action::Recover => unreachable!(),
        }
        self.records.iter_mut().find(|r| r.id == id).unwrap().status = if action == Action::Undo {
            Status::Undone
        } else {
            Status::Applied
        };
        self.pending = None;
    }
}

impl Record {
    pub(crate) fn ensure_replayable(&self) -> Result<()> {
        ensure!(
            !self.changes.is_empty(),
            "transaction {} replay payload was compacted",
            self.id
        );
        Ok(())
    }
}

fn basis(changes: &[Change]) -> Result<String> {
    let source = changes
        .iter()
        .map(|c| (&c.path, &c.before))
        .collect::<Vec<_>>();
    Ok(hex::encode(Sha256::digest(serde_json::to_vec(&source)?)))
}

pub(crate) fn check_evidence_receipt(
    configuration_basis: &str,
    source_revision: &str,
    checks: &[String],
) -> Result<String> {
    Ok(format!(
        "frce1:{}",
        hex::encode(Sha256::digest(serde_json::to_vec(&(
            configuration_basis,
            source_revision,
            checks
        ))?))
    ))
}

fn sha256_text(value: &str) -> bool {
    value.len() == 64 && value.bytes().all(|byte| byte.is_ascii_hexdigit())
}

pub(crate) fn source_revision(root: &Path) -> Result<String> {
    let mut digest = Sha256::new();
    let walker = ignore::WalkBuilder::new(root)
        .standard_filters(false)
        .filter_entry(|entry| {
            !matches!(
                entry.file_name().to_str(),
                Some(".fr-history" | ".git" | "target" | "node_modules" | ".lake")
            )
        })
        .build();
    let mut paths = Vec::new();
    for entry in walker {
        let entry = entry?;
        if entry.file_type().is_some_and(|t| t.is_file())
            && crate::lang::detect(entry.path()).is_some()
        {
            paths.push(entry.into_path());
        }
    }
    paths.sort();
    for file in paths {
        let path = file.strip_prefix(root)?.to_string_lossy();
        let mut source = File::open(&file)
            .with_context(|| format!("opening project source {}", file.display()))?;
        let executable = source.metadata()?.permissions().mode() & 0o100 != 0;
        let mut content = String::new();
        source
            .read_to_string(&mut content)
            .with_context(|| format!("hashing project source {}", file.display()))?;
        digest.update((path.len() as u64).to_le_bytes());
        digest.update(path.as_bytes());
        digest.update([u8::from(executable)]);
        digest.update((content.len() as u64).to_le_bytes());
        digest.update(content.as_bytes());
    }
    Ok(hex::encode(digest.finalize()))
}

fn lock(root: &Path) -> Result<File> {
    let dir = directory(root)?;
    fs::create_dir_all(&dir)?;
    fs::set_permissions(&dir, fs::Permissions::from_mode(0o700))?;
    File::open(root)?.sync_all()?;
    let path = dir.join("lock");
    regular(&path)?;
    let file = fs::OpenOptions::new()
        .write(true)
        .create(true)
        .truncate(false)
        .open(path)?;
    file.lock()?;
    let ignore = dir.join(".gitignore");
    if !regular(&ignore)? {
        let mut temp = tempfile::NamedTempFile::new_in(&dir)?;
        temp.write_all(b"*\n")?;
        temp.as_file().sync_all()?;
        temp.persist(ignore)?;
    }
    Ok(file)
}

fn sync_ancestors(root: &Path, directory: &Path) -> Result<()> {
    for parent in directory.ancestors() {
        match File::open(parent) {
            Ok(file) => host::step(host::Operation::SyncAncestor, parent, || {
                Ok(file.sync_all()?)
            })?,
            Err(error) if error.kind() == std::io::ErrorKind::NotFound => {}
            Err(error) => return Err(error.into()),
        }
        if parent == root {
            break;
        }
    }
    Ok(())
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct RecordResult {
    pub id: u64,
    pub created: bool,
}

pub(crate) struct FileRemoval<'a> {
    pub path: &'a Path,
    pub original: &'a str,
}

pub fn record(
    root: &Path,
    changes: &[FileChange<'_>],
    apply: bool,
    validation: &str,
) -> Result<Option<u64>> {
    Ok(record_with_status(root, changes, apply, validation)?.map(|result| result.id))
}

pub fn record_with_status(
    root: &Path,
    changes: &[FileChange<'_>],
    apply: bool,
    validation: &str,
) -> Result<Option<RecordResult>> {
    record_with_removals_status(root, changes, &[], apply, validation, None)
}

pub(crate) fn record_with_required_checks(
    root: &Path,
    changes: &[FileChange<'_>],
    validation: &str,
    required_checks: &CheckRequirement,
) -> Result<Option<RecordResult>> {
    record_with_removals_status(root, changes, &[], false, validation, Some(required_checks))
}

pub(crate) fn record_with_removals_status(
    root: &Path,
    changes: &[FileChange<'_>],
    removals: &[FileRemoval<'_>],
    apply: bool,
    validation: &str,
    required_checks: Option<&CheckRequirement>,
) -> Result<Option<RecordResult>> {
    if !changes.iter().any(|c| c.original != c.updated) && removals.is_empty() {
        return Ok(None);
    }
    let requested_root = std::path::absolute(root)?;
    let requested_root = if requested_root.is_file() {
        requested_root.parent().unwrap().to_path_buf()
    } else {
        requested_root
    };
    let root = workspace(root)?;
    let _lock = lock(&root)?;
    let mut history = History::read(&root)?;
    history.ensure_ready()?;
    let mut paths = Vec::new();
    for change in changes.iter().filter(|c| c.original != c.updated) {
        let absolute = std::path::absolute(change.path)?;
        let relative = absolute
            .strip_prefix(&root)
            .or_else(|_| absolute.strip_prefix(&requested_root))
            .context("history targets must be inside the workspace root; choose -C accordingly")?;
        paths.push(target(&root, relative)?);
    }
    let changed_paths = paths.len();
    for removal in removals {
        let absolute = std::path::absolute(removal.path)?;
        let relative = absolute
            .strip_prefix(&root)
            .or_else(|_| absolute.strip_prefix(&requested_root))
            .context("history targets must be inside the workspace root; choose -C accordingly")?;
        paths.push(target(&root, relative)?);
    }
    let guards = paths
        .iter()
        .map(|path| FileChange {
            path,
            original: "",
            updated: "lock",
        })
        .collect::<Vec<_>>();
    let _locks = CommitLocks::acquire(&guards)?;
    for path in &paths {
        sync_ancestors(&root, path.parent().unwrap())?;
    }
    let mut stored = Vec::new();
    let mut seen = std::collections::BTreeSet::new();
    for (change, path) in changes
        .iter()
        .filter(|c| c.original != c.updated)
        .zip(paths.iter().take(changed_paths))
    {
        if !seen.insert(path.to_path_buf()) {
            bail!("duplicate history target {}", path.display());
        }
        let before = snapshot(path)?;
        if before
            .as_ref()
            .is_some_and(|snapshot| snapshot.kind != SnapshotKind::Regular)
        {
            bail!(
                "source refactors require a regular file: {}",
                path.display()
            );
        }
        if before.as_ref().map(|s| s.content.as_str()).unwrap_or("") != change.original {
            bail!("{} changed after planning", path.display());
        }
        let after = Some(Snapshot {
            content: change.updated.to_owned(),
            mode: before.as_ref().map_or(0o600, |s| s.mode),
            kind: SnapshotKind::Regular,
        });
        stored.push(Change {
            path: path.strip_prefix(&root)?.to_path_buf(),
            before,
            after,
        });
    }
    for (removal, path) in removals.iter().zip(paths.iter().skip(changed_paths)) {
        if !seen.insert(path.to_path_buf()) {
            bail!("duplicate history target {}", path.display());
        }
        let before = snapshot(path)?;
        let snapshot = before
            .as_ref()
            .with_context(|| format!("source removal target does not exist: {}", path.display()))?;
        if snapshot.kind != SnapshotKind::Regular || snapshot.content != removal.original {
            bail!("{} changed after planning", path.display());
        }
        stored.push(Change {
            path: path.strip_prefix(&root)?.to_path_buf(),
            before,
            after: None,
        });
    }
    store_record(&mut history, stored, apply, validation, required_checks).map(Some)
}

fn store_record(
    history: &mut History,
    changes: Vec<Change>,
    apply: bool,
    validation: &str,
    required_checks: Option<&CheckRequirement>,
) -> Result<RecordResult> {
    let record_basis = basis(&changes)?;
    let revision = source_revision(&history.root)?;
    if !apply {
        if let Some(record) = history.records.iter().find(|record| {
            record.status == Status::Planned
                && record.basis == record_basis
                && record.source_revision == revision
                && record.validation == validation
                && record.changes == changes
                && record.required_checks.as_ref() == required_checks
        }) {
            return Ok(RecordResult {
                id: record.id,
                created: false,
            });
        }
    }
    let id = history
        .records
        .iter()
        .map(|r| r.id)
        .max()
        .unwrap_or(0)
        .checked_add(1)
        .context("transaction identities exhausted")?;
    history.records.push(Record {
        id,
        status: Status::Planned,
        basis: record_basis,
        source_revision: revision,
        validation: validation.to_owned(),
        changes,
        compacted_paths: 0,
        compaction_digest: None,
        required_checks: required_checks.cloned(),
        check_evidence: Vec::new(),
    });
    history.save()?;
    if apply {
        transition(history, Action::Apply, id)?;
    }
    Ok(RecordResult { id, created: true })
}

fn digest(value: &impl Serialize) -> Result<String> {
    Ok(hex::encode(Sha256::digest(serde_json::to_vec(value)?)))
}

fn compaction_digest(record: &Record) -> Result<String> {
    digest(&(
        record.id,
        record.status,
        &record.basis,
        &record.source_revision,
        &record.validation,
        record.compacted_paths,
        &record.required_checks,
        &record.check_evidence,
    ))
}

fn retained(stack: &[u64], keep: usize) -> std::collections::BTreeSet<u64> {
    stack.iter().rev().take(keep).copied().collect()
}

pub fn compact(
    root: &Path,
    keep: usize,
    expected_basis: Option<&str>,
    write: bool,
) -> Result<serde_json::Value> {
    ensure!(
        keep <= 10_000,
        "source history keep count must be 0 through 10000"
    );
    let root = workspace(root)?;
    let _lock = write.then(|| lock(&root)).transpose()?;
    let mut history = History::read(&root)?;
    history.ensure_ready()?;
    let retained = retained(&history.applied, keep)
        .into_iter()
        .chain(retained(&history.redo, keep))
        .collect::<std::collections::BTreeSet<_>>();
    let candidates = history
        .records
        .iter()
        .filter(|record| {
            record_compactable(
                !record.changes.is_empty(),
                history
                    .pending
                    .as_ref()
                    .is_some_and(|pending| pending.id == record.id),
                retained.contains(&record.id),
                record.status == Status::Planned,
            )
        })
        .map(|record| record.id)
        .collect::<std::collections::BTreeSet<_>>();
    let paths = candidates
        .iter()
        .map(|id| history.record(*id).map(|record| record.changes.len()))
        .collect::<Result<Vec<_>>>()?
        .into_iter()
        .sum::<usize>();
    let state_path = directory(&root)?.join("state.json");
    let before_bytes = fs::metadata(&state_path)
        .map(|metadata| metadata.len() as usize)
        .unwrap_or(0);
    let basis = format!(
        "frhistorycompact1:{}",
        digest(&(&history, keep, &candidates))?
    );
    if let Some(expected) = expected_basis {
        ensure!(
            expected == basis,
            "stale source history compaction basis; request a new preview"
        );
    }
    history.applied.retain(|id| !candidates.contains(id));
    history.redo.retain(|id| !candidates.contains(id));
    for record in &mut history.records {
        if candidates.contains(&record.id) {
            record.compacted_paths = record.changes.len();
            record.changes.clear();
            record.compaction_digest = Some(compaction_digest(record)?);
        }
    }
    let after_bytes = serde_json::to_vec(&history)?.len();
    let mut report = serde_json::json!({
        "schema": 1,
        "operation": if write { "history-compact" } else { "history-compact-preview" },
        "basis": basis,
        "basis_verified": expected_basis.is_some(),
        "applied": false,
        "keep_per_stack": keep,
        "records_compacted": candidates.len(),
        "paths_compacted": paths,
        "journal_bytes_before": before_bytes,
        "journal_bytes_after": after_bytes,
        "can_compact": !candidates.is_empty(),
        "undo_after": history.applied.last(),
        "redo_after": history.redo.last(),
        "source_bodies": "omitted",
    });
    if write {
        ensure!(
            !candidates.is_empty(),
            "source history has no replay payloads eligible for compaction"
        );
        history.save()?;
        report["applied"] = serde_json::json!(true);
    }
    Ok(report)
}

pub(crate) fn record_check_evidence(root: &Path, id: u64, evidence: CheckEvidence) -> Result<bool> {
    let root = workspace(root)?;
    let _lock = lock(&root)?;
    let mut history = History::read(&root)?;
    history.ensure_ready()?;
    ensure_check_evidence_target(
        &history,
        &root,
        id,
        &evidence.source_revision,
        &evidence.configuration_basis,
        &evidence.checks,
    )?;
    let record = history.record(id)?;
    if record
        .check_evidence
        .iter()
        .any(|existing| existing.receipt == evidence.receipt)
    {
        return Ok(false);
    }
    history
        .records
        .iter_mut()
        .find(|record| record.id == id)
        .unwrap()
        .check_evidence
        .push(evidence);
    history.save()?;
    Ok(true)
}

fn ensure_check_evidence_target(
    history: &History,
    root: &Path,
    id: u64,
    revision: &str,
    configuration_basis: &str,
    checks: &[String],
) -> Result<()> {
    let record = history.record(id)?;
    record.ensure_replayable()?;
    ensure!(
        record.status == Status::Applied,
        "transaction must be applied."
    );
    for change in &record.changes {
        ensure!(
            snapshot(&target(root, &change.path)?)? == change.after,
            "{} differs from transaction {id}.",
            change.path.display()
        );
    }
    ensure!(
        source_revision(root)? == revision,
        "source changed after checks."
    );
    let requirement_present = record.required_checks.is_some();
    let configuration_matches = record
        .required_checks
        .as_ref()
        .is_some_and(|requirement| requirement.configuration_basis == configuration_basis);
    let check_names_match = record
        .required_checks
        .as_ref()
        .is_some_and(|requirement| requirement.checks == checks);
    ensure!(
        crate::checks::check_requirement_satisfied(
            requirement_present,
            configuration_matches,
            check_names_match,
        ),
        "check evidence does not satisfy the transaction's required selection"
    );
    Ok(())
}

pub(crate) fn check_evidence_target(
    root: &Path,
    id: u64,
    revision: &str,
    configuration_basis: &str,
    checks: &[String],
) -> Result<()> {
    let root = workspace(root)?;
    let history = History::read(&root)?;
    history.ensure_ready()?;
    ensure_check_evidence_target(&history, &root, id, revision, configuration_basis, checks)
}

pub fn act(root: &Path, action: Action, id: u64, write: bool) -> Result<serde_json::Value> {
    act_with_diff(root, action, id, write, true)
}

pub fn act_with_diff(
    root: &Path,
    action: Action,
    id: u64,
    write: bool,
    include_diff: bool,
) -> Result<serde_json::Value> {
    act_with_context(root, action, id, write, include_diff, None)
}

pub fn act_with_context(
    root: &Path,
    action: Action,
    id: u64,
    write: bool,
    include_diff: bool,
    supplied_context: Option<&str>,
) -> Result<serde_json::Value> {
    if !include_diff && !write {
        bail!("preview reports require diffs; omission requires a write");
    }
    let root = workspace(root)?;
    let _lock = if write { Some(lock(&root)?) } else { None };
    let mut history = History::read(&root)?;
    let effective = if action == Action::Recover {
        let pending = history
            .pending
            .as_ref()
            .context("no interrupted transaction to recover")?;
        if pending.id != id {
            bail!("transaction {id} is not the pending transaction");
        }
        pending.action
    } else {
        history.ensure_ready()?;
        history.check_action(action, id)?;
        action
    };
    if let Some(supplied) = supplied_context {
        ensure!(
            matches!(action, Action::Apply | Action::Redo),
            "a transaction context basis can compact only a forward apply or redo; preview this reverse transition."
        );
        ensure!(
            supplied == transaction_context_basis(history.record(id)?),
            "stale or conflicting transaction context basis; review the current transaction."
        );
    }
    let changes = oriented(&history, effective, id)?;
    if action == Action::Apply && source_revision(&root)? != history.record(id)?.source_revision {
        bail!("project source changed after planning; create a fresh plan.");
    }
    let paths = changes
        .iter()
        .map(|c| target(&root, &c.path))
        .collect::<Result<Vec<_>>>()?;
    let guards = paths
        .iter()
        .map(|path| FileChange {
            path,
            original: "",
            updated: "lock",
        })
        .collect::<Vec<_>>();
    let _locks = if write {
        Some(CommitLocks::acquire(&guards)?)
    } else {
        None
    };
    check(&root, &changes, action == Action::Recover)?;
    let changes = if action == Action::Recover {
        changes
            .into_iter()
            .map(|c| {
                Ok(Change {
                    before: snapshot(&target(&root, &c.path)?)?,
                    after: c.before,
                    path: c.path,
                })
            })
            .collect::<Result<Vec<_>>>()?
    } else {
        changes
    };
    let mut report = serde_json::json!({ "transaction": id, "action": action, "applied": write,
        "changes": changes.iter().map(|c| {
            let (before, after) = (&c.before, &c.after);
            serde_json::json!({"path": c.path, "before_exists": before.is_some(), "after_exists": after.is_some(),
                "before_mode": before.as_ref().and_then(Snapshot::reported_mode), "after_mode": after.as_ref().and_then(Snapshot::reported_mode),
                "before_kind": before.as_ref().map(|s| s.kind), "after_kind": after.as_ref().map(|s| s.kind),
                "diff": crate::edit::unified_diff(before.as_ref().map_or("", |s| &s.content), after.as_ref().map_or("", |s| &s.content), &c.path.to_string_lossy())})
        }).collect::<Vec<_>>() });
    if let Some(supplied) = supplied_context {
        for change in report["changes"].as_array_mut().unwrap() {
            let object = change.as_object_mut().unwrap();
            let bytes = object["diff"].as_str().unwrap().len();
            object.remove("diff");
            object.insert("diff_bytes".into(), serde_json::json!(bytes));
        }
        report["context_basis"] = serde_json::json!(supplied);
        report["context_omitted"] = serde_json::json!(["changes[].diff"]);
    } else if !include_diff {
        for change in report["changes"].as_array_mut().unwrap() {
            change.as_object_mut().unwrap().remove("diff");
        }
        report["diffs_omitted"] = serde_json::json!(true);
    }
    if write {
        if action == Action::Recover {
            recover(&mut history)?;
        } else {
            transition(&mut history, action, id)?;
        }
    }
    Ok(report)
}

fn digest_part(digest: &mut Sha256, bytes: &[u8]) {
    digest.update((bytes.len() as u64).to_be_bytes());
    digest.update(bytes);
}

pub(crate) fn transaction_context_basis(record: &Record) -> String {
    let mut digest = Sha256::new();
    digest_part(&mut digest, b"fr-transaction-context-2");
    digest.update((record.changes.len() as u64).to_be_bytes());
    for change in &record.changes {
        digest_part(&mut digest, change.path.as_os_str().as_bytes());
        for snapshot in [&change.before, &change.after] {
            match snapshot {
                None => digest.update([0]),
                Some(snapshot) => {
                    digest.update([1]);
                    digest.update([match snapshot.kind {
                        SnapshotKind::Regular => 0,
                        SnapshotKind::Symlink => 1,
                    }]);
                    digest.update(snapshot.mode.to_be_bytes());
                    digest_part(&mut digest, snapshot.content.as_bytes());
                }
            }
        }
    }
    format!("frtb2:{}", hex::encode(digest.finalize()))
}

pub fn record_context_basis(root: &Path, id: u64) -> Result<String> {
    let history = History::read(root)?;
    let record = history.record(id)?;
    record.ensure_replayable()?;
    Ok(transaction_context_basis(record))
}

fn oriented(history: &History, action: Action, id: u64) -> Result<Vec<Change>> {
    let record = history.record(id)?;
    record.ensure_replayable()?;
    Ok(record
        .changes
        .iter()
        .map(|c| {
            if action == Action::Undo {
                Change {
                    path: c.path.clone(),
                    before: c.after.clone(),
                    after: c.before.clone(),
                }
            } else {
                c.clone()
            }
        })
        .collect())
}

fn check(root: &Path, changes: &[Change], recovery: bool) -> Result<()> {
    for change in changes {
        let current = snapshot(&target(root, &change.path)?)?;
        if !matches_snapshot(&current, &change.before, &change.after, recovery) {
            bail!(
                "{} conflicts with transaction snapshots; preserving current files",
                change.path.display()
            );
        }
    }
    Ok(())
}

pub fn matches_snapshot(
    current: &Option<Snapshot>,
    before: &Option<Snapshot>,
    after: &Option<Snapshot>,
    recovery: bool,
) -> bool {
    current == before || (recovery && current == after)
}

#[cfg(test)]
thread_local! {
    static FAULT: std::cell::Cell<Option<(usize, bool)>> = const { std::cell::Cell::new(None) };
}

#[cfg(test)]
fn fault() -> Result<()> {
    FAULT.with(|fault| match fault.take() {
        Some((0, true)) => std::process::exit(77),
        Some((0, false)) => Err(std::io::Error::other("injected storage failure").into()),
        Some((remaining, crash)) => {
            fault.set(Some((remaining - 1, crash)));
            Ok(())
        }
        None => Ok(()),
    })
}

fn recover(history: &mut History) -> Result<()> {
    let id = history
        .pending
        .as_ref()
        .context("no pending transaction")?
        .id;
    recover_inner(history).map_err(|cause| {
        HistoryFailure::new(
            history,
            id,
            Action::Recover,
            FailurePhase::Recovery,
            FailureOutcome::RecoveryIncomplete,
            cause,
            None,
        )
        .into()
    })
}

fn recover_inner(history: &mut History) -> Result<()> {
    let pending = history.pending.as_ref().context("no pending transaction")?;
    let changes = oriented(history, pending.action, pending.id)?;
    check(&history.root, &changes, true)?;
    let mut inverse = Vec::new();
    for change in changes.iter().rev() {
        let current = snapshot(&target(&history.root, &change.path)?)?;
        match crate::transaction_kernel::history_recovery_step(
            current == change.before,
            current == change.after,
        ) {
            0 => (),
            1 => inverse.push(Change {
                path: change.path.clone(),
                before: change.after.clone(),
                after: change.before.clone(),
            }),
            _ => bail!(
                "{} conflicts with transaction snapshots; preserving current files",
                change.path.display()
            ),
        }
    }
    install(&history.root, &inverse)?;
    host::step(host::Operation::RecoveryCheck, &history.root, || {
        check(&history.root, &changes, false)
    })?;
    for change in &changes {
        let path = target(&history.root, &change.path)?;
        sync_ancestors(
            &history.root,
            path.parent().context("target has no parent")?,
        )?;
    }
    history.pending = None;
    history.save()
}

fn transition(history: &mut History, action: Action, id: u64) -> Result<()> {
    history.ensure_ready()?;
    history.check_action(action, id)?;
    if action == Action::Apply
        && source_revision(&history.root)? != history.record(id)?.source_revision
    {
        bail!("project source changed after planning; create a fresh plan.");
    }
    let changes = oriented(history, action, id)?;
    check(&history.root, &changes, false)?;
    history.pending = Some(Pending { id, action });
    history.save().map_err(|cause| {
        HistoryFailure::new(
            history,
            id,
            action,
            FailurePhase::Preparation,
            FailureOutcome::Unchanged,
            cause,
            None,
        )
    })?;
    if let Err(cause) = install(&history.root, &changes) {
        let recovery = recover(history);
        let outcome = if recovery.is_ok() {
            FailureOutcome::RolledBack
        } else {
            FailureOutcome::RecoveryIncomplete
        };
        return Err(HistoryFailure::new(
            history,
            id,
            action,
            FailurePhase::Installation,
            outcome,
            cause,
            recovery.err().map(|error| format!("{error:#}")),
        )
        .into());
    }
    history.finish(action, id);
    history.save().map_err(|cause| {
        HistoryFailure::new(
            history,
            id,
            action,
            FailurePhase::Finalization,
            FailureOutcome::FinalizationUncertain,
            cause,
            None,
        )
        .into()
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    fn fixture(root: &Path) -> Vec<(PathBuf, String, String)> {
        [Some("before λ\n"), None, Some("")]
            .into_iter()
            .enumerate()
            .map(|(n, original)| {
                let path = root.join(format!("{n}.txt"));
                if let Some(text) = original {
                    fs::write(&path, text).unwrap();
                    fs::set_permissions(&path, fs::Permissions::from_mode(0o751)).unwrap();
                }
                (
                    path,
                    original.unwrap_or("").to_owned(),
                    format!("after {n} 名\n"),
                )
            })
            .collect()
    }

    fn save(root: &Path, fixture: &[(PathBuf, String, String)], apply: bool) -> u64 {
        let changes = fixture
            .iter()
            .map(|(path, original, updated)| FileChange {
                path,
                original,
                updated,
            })
            .collect::<Vec<_>>();
        record(root, &changes, apply, "fixture").unwrap().unwrap()
    }

    fn assert_before(root: &Path) {
        assert_eq!(
            snapshot(&root.join("0.txt")).unwrap(),
            Some(Snapshot {
                content: "before λ\n".to_owned(),
                mode: 0o751,
                kind: SnapshotKind::Regular,
            })
        );
        assert_eq!(snapshot(&root.join("1.txt")).unwrap(), None);
        assert_eq!(
            snapshot(&root.join("2.txt")).unwrap(),
            Some(Snapshot {
                content: String::new(),
                mode: 0o751,
                kind: SnapshotKind::Regular,
            })
        );
    }

    #[test]
    fn transaction_context_basis_binds_the_complete_before_and_after_snapshots() {
        let before = Some(Snapshot {
            content: "before\n".to_owned(),
            mode: 0o644,
            kind: SnapshotKind::Regular,
        });
        let record = |after: &str| Record {
            id: 1,
            status: Status::Planned,
            basis: "journal-basis".to_owned(),
            source_revision: "revision".to_owned(),
            validation: "reparse-strict".to_owned(),
            changes: vec![Change {
                path: PathBuf::from("src/lib.rs"),
                before: before.clone(),
                after: Some(Snapshot {
                    content: after.to_owned(),
                    mode: 0o644,
                    kind: SnapshotKind::Regular,
                }),
            }],
            compacted_paths: 0,
            compaction_digest: None,
            required_checks: None,
            check_evidence: Vec::new(),
        };
        let first = transaction_context_basis(&record("first\n"));
        let second = transaction_context_basis(&record("second\n"));
        assert!(first.starts_with("frtb2:"));
        assert_ne!(first, second);
    }

    #[test]
    fn apply_undo_redo_preserve_existence_content_and_modes() {
        let dir = tempfile::tempdir().unwrap();
        let files = fixture(dir.path());
        let id = save(dir.path(), &files, false);
        assert_before(dir.path());
        act(dir.path(), Action::Apply, id, false).unwrap();
        assert_before(dir.path());
        act(dir.path(), Action::Apply, id, true).unwrap();
        fs::write(dir.path().join("unrelated.txt"), "dirty").unwrap();
        act(dir.path(), Action::Undo, id, true).unwrap();
        assert_before(dir.path());
        act(dir.path(), Action::Redo, id, true).unwrap();
        for (path, _, after) in files {
            assert_eq!(fs::read_to_string(path).unwrap(), after);
        }
        assert_eq!(
            fs::read_to_string(dir.path().join("unrelated.txt")).unwrap(),
            "dirty"
        );
        assert_eq!(History::read(dir.path()).unwrap().applied, [id]);
    }

    #[test]
    fn later_content_mode_and_existence_changes_refuse_without_partial_writes() {
        for kind in 0..3 {
            let dir = tempfile::tempdir().unwrap();
            let files = fixture(dir.path());
            let id = save(dir.path(), &files, true);
            let path = dir.path().join("2.txt");
            match kind {
                0 => fs::write(&path, "user edit").unwrap(),
                1 => fs::set_permissions(&path, fs::Permissions::from_mode(0o700)).unwrap(),
                _ => fs::remove_file(&path).unwrap(),
            }
            let current = snapshot(&path).unwrap();
            assert!(act(dir.path(), Action::Undo, id, true).is_err());
            assert_eq!(snapshot(&path).unwrap(), current);
            assert_eq!(fs::read_to_string(&files[0].0).unwrap(), files[0].2);
            assert!(History::read(dir.path()).unwrap().pending.is_none());
        }
    }

    #[test]
    fn new_apply_abandons_redo_but_saving_a_plan_does_not() {
        let dir = tempfile::tempdir().unwrap();
        let files = fixture(dir.path());
        let first = save(dir.path(), &files, true);
        act(dir.path(), Action::Undo, first, true).unwrap();
        let second = save(dir.path(), &files, false);
        assert_eq!(History::read(dir.path()).unwrap().redo, [first]);
        act(dir.path(), Action::Apply, second, true).unwrap();
        assert!(act(dir.path(), Action::Redo, first, true).is_err());
        let history = History::read(dir.path()).unwrap();
        assert_eq!(history.record(first).unwrap().status, Status::Abandoned);
        assert_eq!(history.applied, [second]);
    }

    #[test]
    fn every_handled_write_failure_restores_the_starting_state() {
        for index in 0..3 {
            let dir = tempfile::tempdir().unwrap();
            let files = fixture(dir.path());
            let id = save(dir.path(), &files, false);
            FAULT.with(|fault| fault.set(Some((index, false))));
            assert!(act(dir.path(), Action::Apply, id, true).is_err());
            assert_before(dir.path());
            let history = History::read(dir.path()).unwrap();
            assert!(history.pending.is_none());
            assert_eq!(history.record(id).unwrap().status, Status::Planned);
        }
    }

    #[test]
    fn interrupted_process_recovers_apply_undo_and_redo_at_every_write_boundary() {
        const CHILD: &str = "FR_HISTORY_CRASH_ROOT";
        if let Ok(root) = std::env::var(CHILD) {
            let root = Path::new(&root);
            let index = std::env::var("FR_HISTORY_CRASH_INDEX")
                .unwrap()
                .parse()
                .unwrap();
            let action = match std::env::var("FR_HISTORY_CRASH_ACTION").unwrap().as_str() {
                "undo" => Action::Undo,
                "redo" => Action::Redo,
                _ => Action::Apply,
            };
            FAULT.with(|fault| fault.set(Some((index, true))));
            act(root, action, 1, true).unwrap();
            panic!("crash point did not run");
        }
        for action in [Action::Apply, Action::Undo, Action::Redo] {
            for index in 0..3 {
                let dir = tempfile::tempdir().unwrap();
                let files = fixture(dir.path());
                let id = save(dir.path(), &files, action != Action::Apply);
                if action == Action::Redo {
                    act(dir.path(), Action::Undo, id, true).unwrap();
                }
                let before = files
                    .iter()
                    .map(|(path, _, _)| snapshot(path).unwrap())
                    .collect::<Vec<_>>();
                let output = std::process::Command::new(std::env::current_exe().unwrap())
                    .args(["--exact", "history::tests::interrupted_process_recovers_apply_undo_and_redo_at_every_write_boundary", "--nocapture"])
                    .env(CHILD, dir.path()).env("FR_HISTORY_CRASH_INDEX", index.to_string())
                    .env("FR_HISTORY_CRASH_ACTION", format!("{action:?}").to_lowercase()).output().unwrap();
                assert_eq!(
                    output.status.code(),
                    Some(77),
                    "{}",
                    String::from_utf8_lossy(&output.stderr)
                );
                assert!(History::read(dir.path()).unwrap().pending.is_some());
                assert!(act(dir.path(), Action::Apply, id, true).is_err());
                act(dir.path(), Action::Recover, id, false).unwrap();
                let report =
                    act_with_diff(dir.path(), Action::Recover, id, true, index != 1).unwrap();
                if index == 1 {
                    assert_eq!(report["diffs_omitted"], true);
                    assert!(report["changes"]
                        .as_array()
                        .unwrap()
                        .iter()
                        .all(|c| c.get("diff").is_none()));
                }
                assert!(History::read(dir.path()).unwrap().pending.is_none());
                for ((path, _, _), expected) in files.iter().zip(before) {
                    assert_eq!(snapshot(path).unwrap(), expected);
                }
            }
        }
    }

    fn interrupted(root: &Path) -> u64 {
        let files = fixture(root);
        let id = save(root, &files, false);
        let mut history = History::read(root).unwrap();
        history.pending = Some(Pending {
            id,
            action: Action::Apply,
        });
        history.save().unwrap();
        install(&history.root, &history.record(id).unwrap().changes[..2]).unwrap();
        id
    }

    #[test]
    fn conflicting_recovery_preserves_all_files_and_can_retry_after_manual_repair() {
        let dir = tempfile::tempdir().unwrap();
        let id = interrupted(dir.path());
        let path = dir.path().join("1.txt");
        let expected = fs::read_to_string(&path).unwrap();
        fs::write(&path, "user change").unwrap();
        assert!(act(dir.path(), Action::Recover, id, true).is_err());
        assert_eq!(
            fs::read_to_string(dir.path().join("0.txt")).unwrap(),
            "after 0 名\n"
        );
        assert_eq!(fs::read_to_string(&path).unwrap(), "user change");
        fs::write(&path, expected).unwrap();
        act(dir.path(), Action::Recover, id, true).unwrap();
        assert_before(dir.path());
    }

    #[test]
    fn recovery_itself_can_fail_and_resume() {
        let dir = tempfile::tempdir().unwrap();
        let id = interrupted(dir.path());
        let preview = act(dir.path(), Action::Recover, id, false).unwrap();
        assert_eq!(preview["changes"][2]["diff"], "");
        assert_eq!(preview["changes"][1]["before_exists"], true);
        assert_eq!(preview["changes"][1]["after_exists"], false);
        FAULT.with(|fault| fault.set(Some((0, false))));
        assert!(act(dir.path(), Action::Recover, id, true).is_err());
        assert!(History::read(dir.path()).unwrap().pending.is_some());
        act(dir.path(), Action::Recover, id, true).unwrap();
        assert_before(dir.path());
    }

    #[test]
    fn saved_plan_refuses_changes_to_other_source_files() {
        let dir = tempfile::tempdir().unwrap();
        let files = fixture(dir.path());
        fs::write(dir.path().join("other.rs"), "fn before() {}\n").unwrap();
        let id = save(dir.path(), &files, false);
        fs::write(dir.path().join("other.rs"), "fn after() {}\n").unwrap();
        assert!(act(dir.path(), Action::Apply, id, false).is_err());
        assert!(act(dir.path(), Action::Apply, id, true).is_err());
        assert_before(dir.path());
    }

    #[test]
    fn unsupported_or_corrupt_history_never_writes_source() {
        let dir = tempfile::tempdir().unwrap();
        let files = fixture(dir.path());
        let id = save(dir.path(), &files, false);
        let path = dir.path().join(DIRECTORY).join("state.json");
        let original = fs::read_to_string(&path).unwrap();
        for mutation in ["version", "escape", "stack", "basis"] {
            let mut state: serde_json::Value = serde_json::from_str(&original).unwrap();
            match mutation {
                "version" => state["schema"] = 200.into(),
                "escape" => state["records"][0]["changes"][0]["path"] = "../outside".into(),
                "stack" => state["applied"] = serde_json::json!([id]),
                _ => state["records"][0]["basis"] = "invalid".into(),
            }
            fs::write(&path, serde_json::to_string(&state).unwrap()).unwrap();
            assert!(act(dir.path(), Action::Apply, id, true).is_err());
            assert_before(dir.path());
        }
    }

    #[test]
    fn reads_and_previews_do_not_create_history() {
        let dir = tempfile::tempdir().unwrap();
        assert!(History::read(dir.path()).unwrap().records.is_empty());
        assert!(act(dir.path(), Action::Apply, 1, false).is_err());
        assert!(!dir.path().join(DIRECTORY).exists());
    }

    #[test]
    fn saved_absent_file_does_not_overwrite_a_later_empty_file() {
        let dir = tempfile::tempdir().unwrap();
        let files = fixture(dir.path());
        let id = save(dir.path(), &files, false);
        fs::write(dir.path().join("1.txt"), "").unwrap();
        assert!(act(dir.path(), Action::Apply, id, true).is_err());
        assert_eq!(
            fs::read_to_string(dir.path().join("0.txt")).unwrap(),
            "before λ\n"
        );
        assert_eq!(fs::read_to_string(dir.path().join("1.txt")).unwrap(), "");
    }

    #[test]
    fn records_and_reverses_a_file_below_a_new_directory() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("new/nested/file.txt");
        let id = record(
            dir.path(),
            &[FileChange {
                path: &path,
                original: "",
                updated: "created\n",
            }],
            true,
            "fixture",
        )
        .unwrap()
        .unwrap();

        assert_eq!(fs::read_to_string(&path).unwrap(), "created\n");
        act(dir.path(), Action::Undo, id, true).unwrap();
        assert!(!path.exists());
        act(dir.path(), Action::Redo, id, true).unwrap();
        assert_eq!(fs::read_to_string(&path).unwrap(), "created\n");
    }

    #[test]
    fn symlink_and_outside_targets_refuse_before_writing() {
        let dir = tempfile::tempdir().unwrap();
        let outside = tempfile::tempdir().unwrap();
        let external = outside.path().join("source.txt");
        fs::write(&external, "original").unwrap();
        std::os::unix::fs::symlink(outside.path(), dir.path().join("alias")).unwrap();
        for path in [external.clone(), dir.path().join("alias/source.txt")] {
            assert!(record(
                dir.path(),
                &[FileChange {
                    path: &path,
                    original: "original",
                    updated: "updated"
                }],
                true,
                "fixture"
            )
            .is_err());
            assert_eq!(fs::read_to_string(&external).unwrap(), "original");
            assert!(History::read(dir.path()).unwrap().records.is_empty());
        }
    }
}
