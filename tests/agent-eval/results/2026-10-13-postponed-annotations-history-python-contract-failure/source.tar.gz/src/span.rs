//! Byte-native source positions.

use serde::{Deserialize, Serialize};
use std::fmt;

/// A half-open byte range `[start, end)` into a source file.
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash, Serialize, Deserialize)]
pub struct Span {
    pub start: usize,
    pub end: usize,
}

impl Span {
    pub fn new(start: usize, end: usize) -> Self {
        debug_assert!(
            start <= end,
            "span start {start} must not exceed end {end}."
        );
        Self { start, end }
    }

    pub fn len(&self) -> usize {
        self.end - self.start
    }

    pub fn is_empty(&self) -> bool {
        self.start == self.end
    }

    /// Does this span fully contain `other`?
    pub fn contains(&self, other: Span) -> bool {
        self.start <= other.start && other.end <= self.end
    }

    /// Does this span contain the given byte offset?
    pub fn contains_offset(&self, offset: usize) -> bool {
        self.start <= offset && offset < self.end
    }

    /// Do the two spans share any byte?
    pub fn overlaps(&self, other: Span) -> bool {
        self.start < other.end && other.start < self.end
    }

    /// Slice the source text this span refers to.
    pub fn text<'a>(&self, source: &'a str) -> &'a str {
        &source[self.start..self.end]
    }
}

impl From<tree_sitter::Node<'_>> for Span {
    fn from(node: tree_sitter::Node<'_>) -> Self {
        Span::new(node.start_byte(), node.end_byte())
    }
}

impl fmt::Display for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{}..{}", self.start, self.end)
    }
}

/// A 1-based line/column position derived from a byte offset.
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Serialize, Deserialize)]
pub struct LineCol {
    pub line: usize,
    pub col: usize,
}

impl fmt::Display for LineCol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{}:{}", self.line, self.col)
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub struct LineRange {
    pub start: LineCol,
    pub end: LineCol,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub struct TextLocation {
    pub span: Span,
    pub range: LineRange,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub struct DefinitionLocation {
    pub name: TextLocation,
    pub definition: TextLocation,
}

/// Maps byte offsets to line/column positions for one source file.
#[derive(Debug, Clone)]
pub struct LineIndex {
    /// Byte offset of the start of each line.
    line_starts: Vec<usize>,
    len: usize,
    ends_with_newline: bool,
}

impl LineIndex {
    pub fn new(source: &str) -> Self {
        let mut line_starts = vec![0];
        line_starts.extend(
            source
                .bytes()
                .enumerate()
                .filter(|(_, b)| *b == b'\n')
                .map(|(i, _)| i + 1),
        );
        let ends_with_newline = source.ends_with('\n');
        if ends_with_newline {
            // The offset just past the final newline is the end of the last line,
            // not the start of another one.
            line_starts.pop();
        }
        Self {
            line_starts,
            len: source.len(),
            ends_with_newline,
        }
    }

    /// Byte offset one past the end of a 0-based line, excluding its newline.
    fn line_end(&self, line: usize) -> usize {
        match self.line_starts.get(line + 1) {
            Some(next) => next - 1,
            None if self.ends_with_newline => self.len - 1,
            None => self.len,
        }
    }

    /// Convert a byte offset to a 1-based line/column.
    pub fn line_col(&self, offset: usize, source: &str) -> LineCol {
        let offset = offset.min(self.len);
        let line = self.line_of(offset);
        let line_start = self.line_starts[line];
        // Clamp to the line's end so a trailing newline does not report a column
        // past the last visible character.
        let mut col_end = offset.min(self.line_end(line));
        // And to a character boundary.
        while col_end > line_start && !source.is_char_boundary(col_end) {
            col_end -= 1;
        }
        let col = source[line_start..col_end].chars().count() + 1;
        LineCol {
            line: line + 1,
            col,
        }
    }

    pub fn locate(&self, span: Span, source: &str) -> TextLocation {
        TextLocation {
            span,
            range: LineRange {
                start: self.line_col(span.start, source),
                end: self.line_col(span.end, source),
            },
        }
    }

    /// 0-based line index containing `offset`.
    fn line_of(&self, offset: usize) -> usize {
        match self.line_starts.binary_search(&offset) {
            Ok(exact) => exact,
            Err(next) => next - 1,
        }
    }

    /// Byte offset of a 1-based line/column position.
    pub fn offset(&self, pos: LineCol, source: &str) -> Option<usize> {
        if pos.line == 0 || pos.line > self.line_starts.len() {
            return None;
        }
        let line_start = self.line_starts[pos.line - 1];
        let line_end = self.line_end(pos.line - 1);
        let line_text = &source[line_start..line_end];
        let col_offset = line_text
            .char_indices()
            .nth(pos.col.saturating_sub(1))
            .map(|(i, _)| i)
            .unwrap_or(line_text.len());
        Some(line_start + col_offset)
    }

    /// Byte span covering a whole 1-based line, excluding its newline.
    pub fn line_span(&self, line: usize) -> Option<Span> {
        if line == 0 || line > self.line_starts.len() {
            return None;
        }
        Some(Span::new(
            self.line_starts[line - 1],
            self.line_end(line - 1),
        ))
    }

    pub fn line_count(&self) -> usize {
        self.line_starts.len()
    }
}

/// Parse `path:line:col-line:col` into a path and two positions.
pub fn parse_range(spec: &str) -> anyhow::Result<(std::path::PathBuf, LineCol, LineCol)> {
    let shape = || anyhow::anyhow!("expected path:line:col-line:col, got '{spec}'.");
    let (head, end_col) = spec.rsplit_once(':').ok_or_else(shape)?;
    let (head, end_line) = head.rsplit_once('-').ok_or_else(shape)?;
    let (path, start_col) = head.rsplit_once(':').ok_or_else(shape)?;
    let (path, start_line) = path.rsplit_once(':').ok_or_else(shape)?;

    let start = LineCol {
        line: start_line.parse()?,
        col: start_col.parse()?,
    };
    let end = LineCol {
        line: end_line.parse()?,
        col: end_col.parse()?,
    };
    if (end.line, end.col) < (start.line, start.col) {
        anyhow::bail!(
            "the range's end ({end}) comes before its start ({start}); write it as \
             path:start_line:start_col-end_line:end_col."
        );
    }
    Ok((std::path::PathBuf::from(path), start, end))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn span_containment_and_overlap() {
        let outer = Span::new(0, 10);
        let inner = Span::new(2, 5);
        assert!(outer.contains(inner));
        assert!(!inner.contains(outer));
        assert!(outer.overlaps(inner));

        // Adjacent spans touch but do not overlap.
        let a = Span::new(0, 5);
        let b = Span::new(5, 10);
        assert!(!a.overlaps(b));
        assert!(!b.overlaps(a));
    }

    #[test]
    fn text_locations_pair_byte_spans_with_half_open_unicode_ranges() {
        let source = "first\n  λ名();\n";
        let start = source.find('λ').unwrap();
        let span = Span::new(start, start + "λ名".len());
        let location = LineIndex::new(source).locate(span, source);
        assert_eq!(location.span, span);
        assert_eq!(location.range.start, LineCol { line: 2, col: 3 });
        assert_eq!(location.range.end, LineCol { line: 2, col: 5 });
    }

    #[test]
    fn an_inverted_range_is_refused_with_both_ends_named() {
        let err = parse_range("src/main.py:8:20-8:5").unwrap_err().to_string();
        assert!(
            err.contains("end (8:5) comes before its start (8:20)"),
            "{err}"
        );
        assert!(
            err.contains("path:start_line:start_col-end_line:end_col"),
            "{err}"
        );
    }

    #[test]
    fn an_ordered_range_still_parses() {
        let (path, start, end) = parse_range("src/main.py:8:5-9:20").unwrap();
        assert_eq!(path, std::path::PathBuf::from("src/main.py"));
        assert_eq!(start, LineCol { line: 8, col: 5 });
        assert_eq!(end, LineCol { line: 9, col: 20 });
    }

    #[test]
    fn line_col_roundtrip() {
        let source = "fn main() {\n    let x = 1;\n}\n";
        let index = LineIndex::new(source);
        assert_eq!(index.line_count(), 3);

        let offset = source.find("let").unwrap();
        let pos = index.line_col(offset, source);
        assert_eq!(pos, LineCol { line: 2, col: 5 });
        assert_eq!(index.offset(pos, source), Some(offset));
    }

    #[test]
    fn line_col_survives_an_offset_inside_a_character() {
        // Callers compute offsets: `span.end - 1` names the last byte a region covers.
        let source = "x = \"𨉟\"\n";
        let index = LineIndex::new(source);
        let end = source.find('\n').expect("a newline");
        for offset in (end - 4)..=end {
            let pos = index.line_col(offset, source);
            assert_eq!(pos.line, 1, "offset {offset} is on line 1");
        }
    }

    #[test]
    fn line_col_counts_characters_not_bytes() {
        let source = "let名 = \"héllo\";\n";
        let index = LineIndex::new(source);
        let offset = source.find('=').unwrap();
        let pos = index.line_col(offset, source);
        // "let名 " is 5 characters, so '=' sits at column 6 despite the multi-byte char.
        assert_eq!(pos, LineCol { line: 1, col: 6 });
        assert_eq!(index.offset(pos, source), Some(offset));
    }

    #[test]
    fn offset_past_end_of_line_clamps() {
        let source = "ab\ncd\n";
        let index = LineIndex::new(source);
        let pos = LineCol { line: 1, col: 99 };
        assert_eq!(index.offset(pos, source), Some(2));
        assert_eq!(index.offset(LineCol { line: 9, col: 1 }, source), None);
    }

    #[test]
    fn line_span_excludes_newline() {
        let source = "alpha\nbeta\n";
        let index = LineIndex::new(source);
        // A trailing newline ends the last line; it does not begin a third one.
        assert_eq!(index.line_count(), 2);
        assert_eq!(index.line_span(1).unwrap().text(source), "alpha");
        assert_eq!(index.line_span(2).unwrap().text(source), "beta");
        assert_eq!(index.line_span(3), None);
    }

    #[test]
    fn end_of_file_offset_maps_to_end_of_last_line() {
        let source = "alpha\nbeta\n";
        let index = LineIndex::new(source);
        // Offset at EOF sits just past "beta", i.e.
        assert_eq!(
            index.line_col(source.len(), source),
            LineCol { line: 2, col: 5 }
        );
    }

    #[test]
    fn empty_source_has_one_line() {
        let index = LineIndex::new("");
        assert_eq!(index.line_count(), 1);
        assert_eq!(index.line_span(1).unwrap(), Span::new(0, 0));
        assert_eq!(index.line_col(0, ""), LineCol { line: 1, col: 1 });
    }

    #[test]
    fn file_without_trailing_newline() {
        let source = "one\ntwo";
        let index = LineIndex::new(source);
        assert_eq!(index.line_count(), 2);
        assert_eq!(index.line_span(2).unwrap().text(source), "two");
        let last = index.line_col(source.len(), source);
        assert_eq!(last, LineCol { line: 2, col: 4 });
    }
}
