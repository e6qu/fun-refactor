use super::{bounded_text, hash, Project};
use crate::model::{Symbol, SymbolKind};
use crate::parse::Parsers;
use crate::transpile::ir::{Function, Item, Module};
use anyhow::{ensure, Context, Result};
use clap::Args;
use serde_json::{json, Value};
use sha2::{Digest, Sha256};

pub const SCHEMA: &str = "fr-semantic-model-1";
const MAX_SEMANTIC_SOURCE_BYTES: usize = 262_144;

#[derive(Args)]
pub struct Options {
    #[command(flatten)]
    pub(super) provenance: super::semantic_origins::OriginOptions,
    #[arg(
        default_value = ".",
        help = "Indexed file path or revision-bound declaration handle."
    )]
    pub(super) target: String,
    #[arg(long, help = "Required when TARGET is a short project node ID.")]
    pub(super) revision: Option<String>,
    #[arg(
        long,
        help = "Select one unique declaration name inside a path target."
    )]
    pub(super) declaration: Option<String>,
    #[arg(
        long,
        help = "Return complete supported bodies and their detected patterns."
    )]
    pub(super) body: bool,
    #[arg(
        long,
        requires = "body",
        help = "List exact typed pointers for the selected authorable body."
    )]
    pub(super) pointers: bool,
    #[arg(
        long,
        requires = "body",
        help = "List copyable semantic-role locators for scalar intent targets."
    )]
    pub(super) locators: bool,
    #[arg(
        long,
        requires = "locators",
        help = "Return the scalar locator index without duplicating the semantic body."
    )]
    pub(super) locators_only: bool,
    #[arg(
        long,
        requires = "body",
        help = "Return locator rows for one exact semantic intent operation."
    )]
    pub(super) locator_op: Option<String>,
    #[arg(
        long,
        requires = "locator_op",
        help = "Return locator rows whose current scalar has this exact text value."
    )]
    pub(super) locator_from: Option<String>,
    #[arg(
        long,
        requires = "locator_from",
        help = "Build one exact scalar semantic intent using this requested value."
    )]
    pub(super) intent_to: Option<String>,
    #[arg(
        long,
        default_value_t = 256,
        help = "Maximum complete semantic nodes returned, from 1 through 4096."
    )]
    pub(super) nodes: usize,
    #[arg(
        long,
        help = "Include source carried by unsupported or fallback IR nodes."
    )]
    pub(super) unsupported_source: bool,
    #[arg(
        long,
        help = "Omit the generic project envelope after binding semantic identity."
    )]
    pub(super) minimal: bool,
}

pub fn semantic_section_fits(required: usize, budget: usize) -> bool {
    required <= budget
}

fn unique_declaration(index: &crate::index::Index, symbol: &Symbol) -> bool {
    let matches = index.symbols_written(&symbol.name, Some(&symbol.file));
    let unique = matches
        .iter()
        .filter(|candidate| {
            candidate.kind == symbol.kind
                && (symbol.kind != SymbolKind::Method || candidate.qualifier == symbol.qualifier)
        })
        .count()
        == 1;
    unique
        && symbol.container.is_none_or(|id| {
            index
                .symbol(id)
                .is_some_and(|container| unique_declaration(index, container))
        })
}

pub(super) fn selected_function(
    module: &Module,
    symbol: &Symbol,
    index: &crate::index::Index,
) -> Option<Function> {
    if !unique_declaration(index, symbol) {
        return None;
    }
    let record_matches = |name: &str| {
        symbol.qualifier.as_deref().is_none_or(|qualifier| {
            qualifier == name
                || qualifier.rsplit("::").next() == Some(name)
                || qualifier.rsplit('.').next() == Some(name)
        })
    };
    // Lowered functions have no declaration span. A name match is only usable
    // when unique; choosing the first match can return or edit another body.
    let mut matches = module.items.iter().filter_map(|item| match item {
        Item::Function(function)
            if function.name == symbol.name
                && (symbol.kind != SymbolKind::Method
                    || function.receiver.as_deref().is_none_or(record_matches)) =>
        {
            Some(function)
        }
        _ => None,
    });
    match symbol.kind {
        SymbolKind::Function => {
            let only = matches.next()?;
            matches.next().is_none().then(|| only.clone())
        }
        SymbolKind::Method => {
            let mut records = module.items.iter().filter_map(|item| match item {
                Item::Record(record) if record_matches(&record.name) => Some(record),
                _ => None,
            });
            let record = records.next();
            if records.next().is_some() {
                return None;
            }
            let mut methods = record
                .into_iter()
                .flat_map(|record| &record.methods)
                .filter(|method| method.name == symbol.name);
            if let Some(only) = methods.next() {
                return methods.next().is_none().then(|| only.clone());
            }
            let only = matches.next()?;
            let exact_receiver = only.receiver.is_some()
                || index
                    .symbols_written(&symbol.name, Some(&symbol.file))
                    .iter()
                    .filter(|candidate| candidate.kind.is_callable())
                    .count()
                    == 1;
            (matches.next().is_none() && exact_receiver).then(|| only.clone())
        }
        _ => None,
    }
}

fn selected_item(module: &Module, symbol: &Symbol, index: &crate::index::Index) -> Option<Item> {
    if !unique_declaration(index, symbol) {
        return None;
    }
    if matches!(symbol.kind, SymbolKind::Function | SymbolKind::Method) {
        return selected_function(module, symbol, index).map(Item::Function);
    }
    let mut matches = module
        .items
        .iter()
        .filter(|item| match (symbol.kind, item) {
            (
                SymbolKind::Class | SymbolKind::Struct | SymbolKind::Trait | SymbolKind::Interface,
                Item::Record(record),
            ) => record.name == symbol.name,
            (SymbolKind::Enum, Item::Sum(sum)) => sum.name == symbol.name,
            (SymbolKind::TypeAlias, Item::Newtype(newtype)) => newtype.name == symbol.name,
            (SymbolKind::Constant, Item::Constant(constant)) => constant.name == symbol.name,
            _ => false,
        });
    let only = matches.next()?;
    matches.next().is_none().then(|| only.clone())
}

fn omit_bodies(module: &mut Module) -> (usize, usize) {
    let mut bodies = 0usize;
    let mut statements = 0usize;
    module.doc.clear();
    module.sweep_notes.clear();
    module.items.retain_mut(|item| match item {
        Item::Function(function) => {
            bodies += usize::from(!function.body.is_empty());
            statements += function.body.len();
            function.doc.clear();
            function.body.clear();
            true
        }
        Item::Record(record) => {
            record.doc.clear();
            for field in &mut record.fields {
                field.doc.clear();
            }
            for method in &mut record.methods {
                bodies += usize::from(!method.body.is_empty());
                statements += method.body.len();
                method.doc.clear();
                method.body.clear();
            }
            true
        }
        Item::Test { doc, body, .. } => {
            bodies += usize::from(!body.is_empty());
            statements += body.len();
            doc.clear();
            body.clear();
            true
        }
        Item::Statement(_) => {
            statements += 1;
            false
        }
        Item::Constant(constant) => {
            constant.doc.clear();
            true
        }
        Item::Newtype(newtype) => {
            newtype.doc.clear();
            true
        }
        Item::Sum(sum) => {
            sum.doc.clear();
            for variant in &mut sum.variants {
                variant.doc.clear();
                for field in &mut variant.fields {
                    field.doc.clear();
                }
            }
            true
        }
        Item::Import { .. } | Item::Unsupported(_) => true,
    });
    (bodies, statements)
}

fn redact_sources(value: &mut Value, redacted: &mut usize) {
    match value {
        Value::Array(values) => {
            for value in values {
                redact_sources(value, redacted);
            }
        }
        Value::Object(object) => {
            if let Some(Value::String(source)) = object.remove("source") {
                object.insert("source_bytes".into(), json!(source.len()));
                object.insert(
                    "source_sha256".into(),
                    json!(hex::encode(Sha256::digest(source.as_bytes()))),
                );
                *redacted += 1;
            }
            if object.get("kind") == Some(&Value::String("import".into())) {
                if let Some(Value::Object(import)) = object.get_mut("value") {
                    if let Some(Value::String(text)) = import.remove("text") {
                        import.insert("source_bytes".into(), json!(text.len()));
                        import.insert(
                            "source_sha256".into(),
                            json!(hex::encode(Sha256::digest(text.as_bytes()))),
                        );
                        *redacted += 1;
                    }
                }
            }
            for value in object.values_mut() {
                redact_sources(value, redacted);
            }
        }
        _ => {}
    }
}

pub(super) fn semantic_nodes(value: &Value) -> usize {
    match value {
        Value::Array(values) => values.iter().map(semantic_nodes).sum(),
        Value::Object(object) => {
            usize::from(object.get("kind").is_some())
                + object.values().map(semantic_nodes).sum::<usize>()
        }
        _ => 0,
    }
}

fn patterns(value: &Value, pointer: &str, basis: &str, out: &mut Vec<Value>) {
    match value {
        Value::Array(values) => {
            for (index, value) in values.iter().enumerate() {
                patterns(value, &format!("{pointer}/{index}"), basis, out);
            }
        }
        Value::Object(object) => {
            if let Some(kind) = object.get("kind").and_then(Value::as_str) {
                let pattern =
                    match kind {
                        "comprehension" => {
                            let filtered =
                                object.get("value").and_then(Value::as_object).is_some_and(
                                    |value| !value.get("condition").is_none_or(Value::is_null),
                                );
                            Some(if filtered { "filter-map" } else { "map" })
                        }
                        "if-present" => Some("optional-branch"),
                        "while-present" => Some("optional-loop"),
                        "match-variants" => Some("variant-match"),
                        "propagate" => Some("failure-propagation"),
                        "defer" => Some("deferred-cleanup"),
                        "err-defer" => Some("failure-cleanup"),
                        "try" => Some("exception-region"),
                        "await" => Some("suspension"),
                        "lambda" => Some("higher-order-function"),
                        _ => None,
                    };
                if let Some(pattern) = pattern {
                    out.push(json!({
                        "pattern": pattern,
                        "node_kind": kind,
                        "address": format!("{basis}#{pointer}"),
                        "basis": "syntax-derived-ir-shape",
                        "behavior_proved": false
                    }));
                }
            }
            for (key, value) in object {
                let escaped = key.replace('~', "~0").replace('/', "~1");
                patterns(value, &format!("{pointer}/{escaped}"), basis, out);
            }
        }
        _ => {}
    }
}

impl Project<'_> {
    fn semantic_declaration_in_scope(&self, scope: usize, name: &str) -> Result<usize> {
        ensure!(
            matches!(self.nodes[scope].kind.as_str(), "file" | "directory"),
            "--declaration requires a file or directory path target."
        );
        let mut matches = self.nodes.iter().enumerate().filter_map(|(id, node)| {
            let symbol = node.symbol.and_then(|symbol| self.index.symbol(symbol))?;
            (self.within(id, scope)
                && symbol.name == name
                && matches!(
                    symbol.kind,
                    SymbolKind::Function
                        | SymbolKind::Method
                        | SymbolKind::Class
                        | SymbolKind::Struct
                        | SymbolKind::Trait
                        | SymbolKind::Interface
                        | SymbolKind::Enum
                        | SymbolKind::TypeAlias
                        | SymbolKind::Constant
                ))
            .then_some(id)
        });
        let selected = matches.next().with_context(|| {
            format!("no semantic declaration named '{name}' in the selected scope.")
        })?;
        ensure!(
            matches.next().is_none(),
            "semantic declaration name is ambiguous; select a revision-bound handle."
        );
        Ok(selected)
    }

    pub(super) fn semantic_declaration_handle(&self, target: &str, name: &str) -> Result<String> {
        ensure!(
            !target.starts_with("frp1:"),
            "--declaration requires a path target without --revision."
        );
        let scope = self.target(target)?;
        Ok(self.handle(self.semantic_declaration_in_scope(scope, name)?))
    }

    pub(super) fn semantic(&self, options: &Options) -> Result<Value> {
        ensure!(
            (1..=4096).contains(&options.nodes),
            "semantic node budget must be between 1 and 4096."
        );
        ensure!(
            options.locator_op.as_deref().is_none_or(|operation| {
                super::semantic_intent::OPERATION_NAMES.contains(&operation)
            }),
            "--locator-op must name a semantic intent operation."
        );
        ensure!(
            options.declaration.is_none()
                || !options.target.starts_with("frp1:") && options.revision.is_none(),
            "--declaration requires a path target without --revision."
        );
        let needs_authorable = options.pointers || options.locators || options.intent_to.is_some();
        let mut target = if options.target.starts_with("frp1:") || options.revision.is_some() {
            self.resolve_handle(
                &self.explicit_handle(&options.target, options.revision.as_deref())?,
            )?
        } else {
            self.target(&options.target)?
        };
        if let Some(name) = &options.declaration {
            target = self.semantic_declaration_in_scope(target, name)?;
        }
        let node = &self.nodes[target];
        ensure!(
            node.kind != "directory",
            "semantic queries require a file or declaration."
        );
        let path = self.root.join(&node.path);
        let file = self
            .index
            .file(&path)
            .context("semantic target is not indexed.")?;
        ensure!(
            crate::transpile::can_be_read(file.language),
            "{} has no semantic IR reader.",
            file.language
        );
        let source = self
            .sources
            .get(&path)
            .context("semantic source is unavailable.")?;
        ensure!(
            source.len() <= MAX_SEMANTIC_SOURCE_BYTES,
            "semantic source exceeds the 262144-byte analysis limit; select a smaller file or use structural project queries."
        );
        let parsed = Parsers::new().parse(file.language, source)?;
        ensure!(
            !parsed.has_errors(),
            "semantic source contains parser errors."
        );
        let mut module = crate::transpile::read_module(file.language, source, parsed.root())?;
        let mut body_identity = None;
        let mut authorable_body = None;
        let selected = if let Some(symbol) = node.symbol.and_then(|id| self.index.symbol(id)) {
            let item = selected_item(&module, symbol, self.index).with_context(|| {
                format!(
                    "the {} '{}' has no exact semantic IR item; select its file or request bounded source.",
                    symbol.kind.as_str(), symbol.name
                )
            })?;
            ensure!(
                !needs_authorable || matches!(item, Item::Function(_)),
                "semantic body pointers, locators and edit plans require one function or method declaration."
            );
            if let Item::Function(function) = &item {
                let body = super::semantic_change::SemanticBody {
                    schema: super::semantic_ir::BODY_SCHEMA.into(),
                    body: function.body.clone(),
                };
                let value = serde_json::to_value(&body)?;
                let nodes = semantic_nodes(&value);
                body_identity = Some(if !super::semantic_ir::source_free(&value) {
                    json!({"status":"unavailable-source-bearing","source_free":false})
                } else if body.body.len() > super::semantic_change::MAX_STATEMENTS
                    || nodes > super::semantic_change::MAX_NODES
                {
                    json!({"status":"unavailable-size","source_free":true,
                        "statements":body.body.len(),"semantic_nodes":nodes})
                } else {
                    let basis = super::semantic_change::body_basis(&body)?;
                    if needs_authorable {
                        authorable_body = Some(body.clone());
                    }
                    json!({"status":"available","source_free":true,
                        "schema":super::semantic_ir::BODY_SCHEMA,
                        "basis":basis,
                        "statements":body.body.len(),"semantic_nodes":nodes})
                });
            }
            module.items = vec![item];
            "declaration"
        } else {
            ensure!(
                !needs_authorable,
                "semantic body pointers, locators and edit plans require one function or method declaration."
            );
            "file"
        };
        let (omitted_bodies, omitted_statements) = if options.body {
            (0, 0)
        } else {
            omit_bodies(&mut module)
        };
        let mut model = serde_json::to_value(&module)?;
        let mut redacted = 0usize;
        if !options.unsupported_source {
            redact_sources(&mut model, &mut redacted);
        }
        let required = semantic_nodes(&model).max(1);
        ensure!(
            !needs_authorable
                || semantic_section_fits(required, options.nodes),
            "semantic body pointers, locators and edit plans require a complete body within the node budget."
        );
        let payload_hash = hash((&self.revision, self.handle(target), &model))?;
        let basis = format!("frsm1:{payload_hash}");
        let mut report = self.envelope("semantic");
        report["semantic_schema"] = json!(SCHEMA);
        report["semantic_basis"] = json!(basis);
        report["selection"] = json!({
            "kind": selected,
            "handle": self.handle(target),
            "path": bounded_text(&node.path.to_string_lossy(), 512),
            "language": file.language,
            "body_requested": options.body
        });
        if let Some(identity) = body_identity {
            report["body_identity"] = identity;
        }
        if options.pointers {
            report["body_pointers"] = if let Some(body) = &authorable_body {
                json!({
                    "schema":"fr-semantic-body-pointers-1",
                    "basis":report["body_identity"]["basis"],
                    "fields":["path","category","kind"],
                    "rows":super::semantic_change::body_pointers(body)?
                })
            } else {
                json!({"schema":"fr-semantic-body-pointers-1","status":"unavailable-body-identity"})
            };
        }
        if options.locators {
            report["body_locators"] = if let Some(body) = &authorable_body {
                let mut rows = super::semantic_intent::body_locators(body)?;
                if let Some(operation) = options.locator_op.as_deref() {
                    rows.retain(|row| row["operation"] == operation);
                }
                if let Some(before) = options.locator_from.as_deref() {
                    rows.retain(|row| match &row["from"] {
                        Value::String(value) => value == before,
                        Value::Bool(value) => before == value.to_string(),
                        _ => false,
                    });
                }
                json!({
                    "schema":"fr-semantic-body-locators-1",
                    "basis":report["body_identity"]["basis"],
                    "fields":["target","category","kind","operation","from"],
                    "rows":rows,
                    "complete":true,
                    "filter":{"operation":options.locator_op,"from":options.locator_from}
                })
            } else {
                json!({"schema":"fr-semantic-body-locators-1","status":"unavailable-body-identity"})
            };
        }
        if let Some(to) = options.intent_to.as_deref() {
            let body = authorable_body
                .as_ref()
                .context("semantic edit plan requires an available source-free body identity.")?;
            let operation = options.locator_op.as_deref().unwrap();
            let from = options.locator_from.as_deref().unwrap();
            let plan = super::semantic_intent::plan_unique(body, operation, from, to)?;
            report["edit_plan"] = json!({
                "schema":"fr-semantic-edit-plan-1",
                "status":"ready",
                "handle":report["selection"]["handle"],
                "operation":operation,
                "from":from,
                "to":to,
                "target":plan.target,
                "intent":plan.manifest,
                "intent_sha256":plan.applied.intent_sha256,
                "intent_basis":plan.applied.intent_basis,
                "input_basis":plan.applied.input_basis,
                "result_basis":plan.applied.result_basis,
                "source_free":true,
                "refinement_checked":true
            });
        }
        report["addressing"] = json!({
            "format": "SEMANTIC_BASIS#RFC6901_JSON_POINTER",
            "root": format!("{}#/model", report["semantic_basis"].as_str().unwrap())
        });
        report["node_budget"] = json!({
            "limit": options.nodes,
            "required": required,
            "unit": "tagged semantic nodes",
            "complete_subtrees_only": true
        });
        report["analysis_budget"] = json!({
            "source_bytes": source.len(),
            "maximum_source_bytes": MAX_SEMANTIC_SOURCE_BYTES
        });
        report["omitted"] = json!({
            "bodies": omitted_bodies,
            "top_level_statements": omitted_statements,
            "source_fields": redacted
        });
        report["source_policy"] = json!(if options.unsupported_source {
            "explicit-unsupported-source"
        } else {
            "source-free"
        });
        report["scope"] = json!(
            "Syntax-derived cross-language IR; types can be inferred from local evidence. Pattern rows do not prove behavior."
        );
        if semantic_section_fits(required, options.nodes) {
            let mut found = Vec::new();
            patterns(
                &model,
                "/model",
                report["semantic_basis"].as_str().unwrap(),
                &mut found,
            );
            report["status"] = json!("returned");
            report["model"] = model;
            report["patterns"] = json!(found);
        } else {
            report["status"] = json!("omitted-node-budget");
            report["model"] = Value::Null;
            report["patterns"] = json!([]);
        }
        if options.provenance.origins {
            report["origins"] =
                self.semantic_origins(target, parsed.root(), &report, &options.provenance)?;
        }
        if options.locators_only || options.intent_to.is_some() && !options.locators {
            report.as_object_mut().unwrap().remove("model");
            report.as_object_mut().unwrap().remove("patterns");
            report["content_omitted"] = json!(["model", "patterns"]);
        }
        Ok(report)
    }
}

pub(crate) fn minimize(command: &super::Command, report: &mut Value) {
    let super::Command::Semantic(options) = command else {
        return;
    };
    if !options.minimal {
        return;
    }
    let omitted = [
        "schema",
        "revision",
        "handle_prefix",
        "root",
        "coverage",
        "context_basis",
        "addressing",
        "analysis_budget",
        "scope",
    ];
    for field in omitted {
        report.as_object_mut().unwrap().remove(field);
    }
    report["report_omitted"] = json!(omitted);
}
