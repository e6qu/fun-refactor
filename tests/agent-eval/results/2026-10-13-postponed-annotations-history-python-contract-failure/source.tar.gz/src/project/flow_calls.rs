use super::*;

#[derive(Clone, Copy, PartialEq, Eq)]
pub(super) enum Kind {
    PositionalOnly,
    Either,
    KeywordOnly,
}

pub(super) struct Parameter<'t> {
    pub node: Node<'t>,
    pub kind: Kind,
    pub default: Option<Node<'t>>,
}

#[derive(Clone, Serialize)]
pub(super) struct ParameterSignature {
    name: String,
    kind: &'static str,
    site: Occurrence,
    default: Option<Occurrence>,
}

#[derive(Clone, Copy, PartialEq, Eq)]
enum Phase {
    Declaration,
    Call,
}

fn literal_default(node: Node<'_>, source: &str) -> bool {
    match node.kind() {
        "none" | "true" | "false" | "integer" | "float" => true,
        "string" => {
            let text = &source[node.byte_range()];
            let prefix = text.split(['\'', '"']).next().unwrap_or_default();
            !prefix.to_ascii_lowercase().contains('f')
                && !node
                    .named_children(&mut node.walk())
                    .any(|n| n.kind() == "interpolation")
        }
        "parenthesized_expression" => {
            let children: Vec<_> = node
                .named_children(&mut node.walk())
                .filter(|n| n.kind() != "comment")
                .collect();
            children.len() == 1 && literal_default(children[0], source)
        }
        "unary_operator" => {
            let operator = node.child_by_field_name("operator");
            let argument = node.child_by_field_name("argument");
            operator.is_some_and(|n| matches!(&source[n.byte_range()], "+" | "-"))
                && argument.is_some_and(|n| matches!(n.kind(), "integer" | "float"))
        }
        _ => false,
    }
}

pub(super) fn module_literal<'s>(node: Node<'_>, source: &'s str) -> Option<&'s str> {
    if node.kind() != "expression_statement" || node.named_child_count() != 1 {
        return None;
    }
    let assignment = node.named_child(0)?;
    if assignment.kind() != "assignment" || assignment.child_by_field_name("type").is_some() {
        return None;
    }
    let left = assignment.child_by_field_name("left")?;
    let right = assignment.child_by_field_name("right")?;
    let name = &source[left.byte_range()];
    (left.kind() == "identifier"
        && name.is_ascii()
        && !(name.starts_with("__") && name.ends_with("__"))
        && literal_default(right, source))
    .then_some(name)
}

pub(super) fn module_class<'s>(
    node: Node<'_>,
    source: &'s str,
    postponed: bool,
) -> Option<(&'s str, bool)> {
    if node.kind() != "class_definition" {
        return None;
    }
    let name_node = node.child_by_field_name("name")?;
    let body = node.child_by_field_name("body")?;
    let name = &source[name_node.byte_range()];
    if !name.is_ascii() || name.starts_with("__") && name.ends_with("__") {
        return None;
    }
    for child in node.named_children(&mut node.walk()) {
        if child == name_node || child == body || child.kind() == "comment" {
            continue;
        }
        if child.kind() != "argument_list"
            || child
                .named_children(&mut child.walk())
                .any(|n| n.kind() != "comment")
        {
            return None;
        }
    }
    let mut constructible = true;
    for child in body.named_children(&mut body.walk()) {
        if matches!(child.kind(), "comment" | "pass_statement")
            || module_literal(child, source).is_some()
        {
            continue;
        }
        if child.kind() == "expression_statement"
            && child.named_child_count() == 1
            && child
                .named_child(0)
                .is_some_and(|n| n.kind() == "string" && literal_default(n, source))
        {
            continue;
        }
        if child.kind() != "function_definition" || !definition_is_inert(child, source, postponed) {
            return None;
        }
        let method = child.child_by_field_name("name")?;
        let method = &source[method.byte_range()];
        if !method.is_ascii()
            || matches!(
                method,
                "__name__"
                    | "__class__"
                    | "__module__"
                    | "__qualname__"
                    | "__doc__"
                    | "__dict__"
                    | "__weakref__"
                    | "__slots__"
                    | "__classcell__"
                    | "__annotations__"
                    | "__annotate__"
                    | "__type_params__"
                    | "__firstlineno__"
                    | "__static_attributes__"
                    | "__mro__"
                    | "__bases__"
                    | "__base__"
                    | "__abstractmethods__"
            )
        {
            return None;
        }
        constructible &= !matches!(method, "__new__" | "__init__" | "__del__");
    }
    Some((name, constructible))
}

pub(super) fn module_instance<'s>(
    node: Node<'_>,
    source: &'s str,
    classes: &BTreeSet<&str>,
) -> Option<&'s str> {
    if node.kind() != "expression_statement" || node.named_child_count() != 1 {
        return None;
    }
    let assignment = node.named_child(0)?;
    if assignment.kind() != "assignment" || assignment.child_by_field_name("type").is_some() {
        return None;
    }
    let left = assignment.child_by_field_name("left")?;
    let right = assignment.child_by_field_name("right")?;
    let name = &source[left.byte_range()];
    let function = right.child_by_field_name("function")?;
    let arguments = right.child_by_field_name("arguments")?;
    (left.kind() == "identifier"
        && name.is_ascii()
        && !(name.starts_with("__") && name.ends_with("__"))
        && right.kind() == "call"
        && function.kind() == "identifier"
        && classes.contains(&source[function.byte_range()])
        && arguments
            .named_children(&mut arguments.walk())
            .all(|n| n.kind() == "comment"))
    .then_some(name)
}

pub(super) fn module_export_list(node: Node<'_>, source: &str) -> Option<BTreeSet<String>> {
    if node.kind() != "expression_statement" || node.named_child_count() != 1 {
        return None;
    }
    let assignment = node.named_child(0)?;
    let left = assignment.child_by_field_name("left")?;
    let right = assignment.child_by_field_name("right")?;
    if assignment.kind() != "assignment"
        || assignment.child_by_field_name("type").is_some()
        || left.kind() != "identifier"
        || &source[left.byte_range()] != "__all__"
        || !matches!(right.kind(), "list" | "tuple")
    {
        return None;
    }
    let mut names = BTreeSet::new();
    for (index, child) in right
        .named_children(&mut right.walk())
        .filter(|n| n.kind() != "comment")
        .enumerate()
    {
        let text = &source[child.byte_range()];
        let quote = text.chars().next()?;
        let name = text.strip_prefix(quote)?.strip_suffix(quote)?;
        if index >= 128
            || child.kind() != "string"
            || !matches!(quote, '\'' | '"')
            || name.is_empty()
            || !name
                .chars()
                .enumerate()
                .all(|(i, c)| c == '_' || c.is_ascii_alphabetic() || i > 0 && c.is_ascii_digit())
        {
            return None;
        }
        names.insert(name.to_owned());
    }
    Some(names)
}

pub(super) fn declared_exports(root: Node<'_>, source: &str) -> Option<BTreeSet<String>> {
    let mut exports = None;
    let mut pending = Vec::new();
    for node in root.named_children(&mut root.walk()) {
        if let Some(names) = module_export_list(node, source) {
            if exports.replace(names).is_some() {
                return None;
            }
        } else {
            pending.push(node);
        }
    }
    while let Some(node) = pending.pop() {
        if node.kind() == "identifier" && &source[node.byte_range()] == "__all__" {
            return None;
        }
        let deferred = matches!(node.kind(), "function_definition" | "lambda")
            .then(|| node.child_by_field_name("body"))
            .flatten();
        pending.extend(
            node.named_children(&mut node.walk())
                .filter(|child| Some(*child) != deferred),
        );
    }
    exports
}

pub(super) fn future_annotation_nodes(root: Node<'_>, source: &str) -> BTreeSet<usize> {
    let mut result = BTreeSet::new();
    let mut first = true;
    for node in root.named_children(&mut root.walk()) {
        if node.kind() == "comment" {
            continue;
        }
        if first && node.kind() == "expression_statement" && node.named_child_count() == 1 {
            let value = node.named_child(0).unwrap();
            let prefix = source[value.byte_range()]
                .split(['\'', '"'])
                .next()
                .unwrap_or_default()
                .to_ascii_lowercase();
            if value.kind() == "string" && literal_default(value, source) && !prefix.contains('b') {
                first = false;
                continue;
            }
        }
        first = false;
        if node.kind() != "future_import_statement" {
            break;
        }
        let names: Vec<_> = node
            .children_by_field_name("name", &mut node.walk())
            .collect();
        if names.len() != 1
            || names[0].kind() != "dotted_name"
            || &source[names[0].byte_range()] != "annotations"
        {
            return BTreeSet::new();
        }
        result.insert(node.start_byte());
    }
    result
}

pub(super) fn parameters<'t>(
    function: Node<'t>,
    source: &str,
    postponed: bool,
) -> Option<Vec<Parameter<'t>>> {
    parameter_contract(function, source, postponed, Phase::Call)
}

pub(super) fn definition_is_inert(function: Node<'_>, source: &str, postponed: bool) -> bool {
    parameter_contract(function, source, postponed, Phase::Declaration).is_some()
}

pub(super) fn generator_function(function: Node<'_>) -> bool {
    let mut pending: Vec<_> = function.child_by_field_name("body").into_iter().collect();
    while let Some(node) = pending.pop() {
        if node.kind() == "yield" {
            return true;
        }
        let deferred = if matches!(
            node.kind(),
            "function_definition" | "class_definition" | "lambda"
        ) {
            node.child_by_field_name("body")
        } else {
            None
        };
        pending.extend(
            node.named_children(&mut node.walk())
                .filter(|child| Some(*child) != deferred),
        );
    }
    false
}

fn parameter_contract<'t>(
    function: Node<'t>,
    source: &str,
    postponed: bool,
    phase: Phase,
) -> Option<Vec<Parameter<'t>>> {
    if function.child_by_field_name("type_parameters").is_some()
        || function
            .child_by_field_name("return_type")
            .is_some_and(|node| !postponed || !postponed_annotation(node))
    {
        return None;
    }
    let list = function.child_by_field_name("parameters")?;
    let mut result: Vec<Parameter<'t>> = Vec::new();
    let mut names = BTreeSet::new();
    let mut slash = false;
    let mut star = false;
    let mut bare_star = false;
    let mut variadic_keywords = false;
    let mut optional = false;
    for mut node in list.named_children(&mut list.walk()) {
        if matches!(node.kind(), "typed_parameter" | "typed_default_parameter")
            && (!postponed || !postponed_annotation(node.child_by_field_name("type")?))
        {
            return None;
        }
        if node.kind() == "typed_parameter" {
            node = node.named_child(0)?;
        }
        match node.kind() {
            "comment" => (),
            "identifier" | "default_parameter" | "typed_default_parameter"
                if !variadic_keywords =>
            {
                let (name, default) = if node.kind() != "identifier" {
                    let name = node.child_by_field_name("name")?;
                    let value = node.child_by_field_name("value")?;
                    if name.kind() != "identifier" || !literal_default(value, source) {
                        return None;
                    }
                    (name, Some(value))
                } else {
                    (node, None)
                };
                if !source[name.byte_range()].is_ascii()
                    || !names.insert(&source[name.byte_range()])
                    || !star && optional && default.is_none()
                {
                    return None;
                }
                optional |= default.is_some();
                result.push(Parameter {
                    node: name,
                    kind: if star {
                        Kind::KeywordOnly
                    } else {
                        Kind::Either
                    },
                    default,
                });
            }
            "positional_separator" if !slash && !star && !result.is_empty() => {
                slash = true;
                for parameter in &mut result {
                    parameter.kind = Kind::PositionalOnly;
                }
            }
            "keyword_separator" if !star => {
                star = true;
                bare_star = true;
            }
            "list_splat_pattern" if !star => {
                variadic_parameter(node, function, source, &mut names, phase)?;
                star = true;
            }
            "dictionary_splat_pattern" if !variadic_keywords => {
                variadic_parameter(node, function, source, &mut names, phase)?;
                variadic_keywords = true;
            }
            _ => return None,
        }
    }
    if bare_star && result.last().is_none_or(|p| p.kind != Kind::KeywordOnly) {
        return None;
    }
    Some(result)
}

fn postponed_annotation(node: Node<'_>) -> bool {
    let mut pending = vec![node];
    for _ in 0..128 {
        let Some(node) = pending.pop() else {
            return true;
        };
        if matches!(
            node.kind(),
            "await" | "yield" | "named_expression" | "splat_type" | "constrained_type"
        ) {
            return false;
        }
        pending.extend(node.named_children(&mut node.walk()));
        if pending.len() > 128 {
            return false;
        }
    }
    pending.is_empty()
}

fn variadic_parameter<'s>(
    node: Node<'_>,
    function: Node<'_>,
    source: &'s str,
    names: &mut BTreeSet<&'s str>,
    phase: Phase,
) -> Option<()> {
    let mut cursor = node.walk();
    let mut children = node.named_children(&mut cursor);
    let name = children.next()?;
    if name.kind() != "identifier" || children.next().is_some() {
        return None;
    }
    let text = &source[name.byte_range()];
    if !text.is_ascii() || !names.insert(text) {
        return None;
    }
    if phase == Phase::Declaration {
        return Some(());
    }
    let mut pending = vec![function.child_by_field_name("body")?];
    while let Some(child) = pending.pop() {
        if child.kind() == "identifier" && &source[child.byte_range()] == text {
            return None;
        }
        pending.extend(child.named_children(&mut child.walk()));
    }
    Some(())
}

pub(super) fn contract() -> Value {
    json!({"schema":"fr-call-binding",
        "parameters":"ASCII positional-only, positional-or-keyword and keyword-only slots; required or immutable literal defaults.",
        "evaluation":"Evaluate explicit values once in source order before binding.",
        "binding":"Bind positions, then exact keyword names; substitute in declaration order.",
        "invalid":"Missing, excess, duplicate or unknown arguments leave analysis incomplete; no TypeError model.",
        "boundary":"No evaluated/mutable defaults, unpostponed annotations, type parameters, used variadics, extra arguments, unpacking, async/generator calls, external-rule keywords or non-normalized names.",
        "definitions":"ASCII signatures and literal defaults defer bodies, including variadics. Annotations need a checked module-local future directive and at most 128 nodes. No annotation await, yield, assignment or type unpacking.",
        "initialization":"ASCII scalars, literal __all__, plain classes and unchanged empty construction are inert. Global reads, collisions and other effects stay unchecked.",
        "variadics":"Omit unused ASCII variadics whose names never occur in the body. Calls bind fixed slots; annotations follow definition rules.",
        "defaults":"Omitted slots use source-free immutable scalars; explicit arguments override defaults. Definition-time effects stay unchecked.",
        "implicit_exceptions":false})
}

impl<'a, 'p, 't> Analyzer<'a, 'p, 't> {
    pub(super) fn annotations_postponed(&self, file: &Path) -> bool {
        self.modules
            .is_some_and(|modules| modules.annotations_postponed(file))
    }

    pub(super) fn parameter_nodes(&self, function: Node<'t>) -> Option<Vec<Node<'t>>> {
        if self.solver.enabled {
            parameters(function, self.source, self.annotations_postponed(self.file))
                .map(|items| items.into_iter().map(|p| p.node).collect())
        } else {
            let list = function.child_by_field_name("parameters")?;
            let items: Vec<_> = list.named_children(&mut list.walk()).collect();
            items
                .iter()
                .all(|p| p.kind() == "identifier")
                .then_some(items)
        }
    }

    pub(super) fn call_arguments(
        &mut self,
        node: Node<'t>,
        env: &Environment,
    ) -> (Vec<Flow>, Vec<Option<String>>) {
        let mut values = Vec::new();
        let mut names = Vec::new();
        let mut keywords = false;
        if let Some(list) = node.child_by_field_name("arguments") {
            for arg in list.named_children(&mut list.walk()) {
                if arg.kind() == "comment" {
                    continue;
                }
                if self.solver.enabled && !self.normal {
                    break;
                }
                let (value, name) = if self.solver.enabled && arg.kind() == "keyword_argument" {
                    let (Some(name), Some(value)) = (
                        arg.child_by_field_name("name"),
                        arg.child_by_field_name("value"),
                    ) else {
                        self.cutoff("malformed-keyword-argument");
                        break;
                    };
                    if !self.text(name).is_ascii() {
                        self.cutoff("non-ascii-keyword-binding-unchecked");
                    }
                    keywords = true;
                    (value, Some(self.text(name).to_owned()))
                } else {
                    if matches!(arg.kind(), "list_splat" | "dictionary_splat") {
                        self.cutoff("argument-unpacking-unchecked");
                        break;
                    }
                    if keywords {
                        self.cutoff("positional-after-keyword");
                    }
                    (arg, None)
                };
                values.push(self.expression(value, env));
                names.push(name);
            }
        }
        (values, names)
    }

    pub(super) fn bind_arguments(
        &mut self,
        name: &str,
        function: Node<'t>,
        values: Vec<Flow>,
        names: &[Option<String>],
    ) -> Option<Vec<Flow>> {
        let source = self.contexts[name].1;
        let Some(parameters) = parameters(
            function,
            source,
            self.annotations_postponed(self.contexts[name].0),
        ) else {
            self.cutoff(format!("unsupported-parameter-contract:{name}"));
            return None;
        };
        let mut slots: Vec<Option<Flow>> = vec![None; parameters.len()];
        let mut position = 0;
        for (value, keyword) in values.into_iter().zip(names) {
            let slot = if let Some(keyword) = keyword {
                parameters.iter().position(|p| {
                    p.kind != Kind::PositionalOnly && &source[p.node.byte_range()] == keyword
                })
            } else {
                let next = parameters
                    .get(position)
                    .filter(|p| p.kind != Kind::KeywordOnly)
                    .map(|_| position);
                position += 1;
                next
            };
            let Some(slot) = slot else {
                self.cutoff(format!("invalid-call-binding:{name}"));
                return None;
            };
            if slots[slot].replace(value).is_some() {
                self.cutoff(format!("invalid-call-binding:{name}"));
                return None;
            }
        }
        for (slot, parameter) in slots.iter_mut().zip(&parameters) {
            if slot.is_none() && parameter.default.is_some() {
                *slot = Some(Flow::new());
            }
        }
        let result: Option<Vec<_>> = slots.into_iter().collect();
        if result.is_none() {
            self.cutoff(format!("invalid-call-binding:{name}"));
        }
        result
    }
}

pub(super) fn valid_call_syntax(node: Node<'_>, source: &str) -> bool {
    let Some(arguments) = node.child_by_field_name("arguments") else {
        return false;
    };
    if arguments.kind() != "argument_list" {
        return false;
    }
    let mut keywords = BTreeSet::new();
    let mut dictionary = false;
    for arg in arguments.named_children(&mut arguments.walk()) {
        match arg.kind() {
            "comment" => (),
            "keyword_argument" => {
                let Some(name) = arg.child_by_field_name("name") else {
                    return false;
                };
                let name = &source[name.byte_range()];
                if !name.is_ascii() || !keywords.insert(name) {
                    return false;
                }
            }
            "dictionary_splat" => dictionary = true,
            "list_splat" if !dictionary => (),
            _ if dictionary || !keywords.is_empty() => return false,
            _ => (),
        }
    }
    true
}

impl Analyzer<'_, '_, '_> {
    pub(super) fn parameter_signature(&self, function: Node<'_>) -> Vec<ParameterSignature> {
        parameters(function, self.source, self.annotations_postponed(self.file))
            .unwrap_or_default()
            .into_iter()
            .map(|parameter| ParameterSignature {
                name: self.text(parameter.node).to_owned(),
                kind: match parameter.kind {
                    Kind::PositionalOnly => "positional-only",
                    Kind::Either => "positional-or-keyword",
                    Kind::KeywordOnly => "keyword-only",
                },
                site: self.occurrence(parameter.node, "summary-parameter"),
                default: parameter
                    .default
                    .map(|node| self.occurrence(node, "parameter-default")),
            })
            .collect()
    }
}
