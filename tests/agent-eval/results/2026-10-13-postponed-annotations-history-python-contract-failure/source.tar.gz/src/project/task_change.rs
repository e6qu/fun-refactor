use super::{author, batch, task, Project};
use anyhow::{ensure, Context, Result};
use clap::Args;
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::fs;
use std::io::{self, Read};
use std::path::{Path, PathBuf};

const SCHEMA: &str = "fr-task-change-1";
const MAX_INPUT_BYTES: u64 = 65_536;

#[derive(Args)]
pub struct Options {
    #[arg(
        long,
        help = "Reviewed task-change manifest path, or - for standard input; at most 64 KiB."
    )]
    pub from: PathBuf,
    #[arg(
        long,
        default_value_t = 65_536,
        help = "Maximum UTF-8 diff bytes, from 0 through 65536."
    )]
    pub diff_bytes: usize,
    #[arg(
        long,
        default_value_t = 65_536,
        help = "Shared serialized query-report budget, from 256 through 1048576 bytes."
    )]
    pub report_bytes: usize,
    #[arg(long, help = "Execute the unchanged reviewed task change.")]
    pub write: bool,
    #[arg(
        long,
        requires = "write",
        help = "Complete task-change basis returned by preview."
    )]
    pub basis: Option<String>,
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct Manifest {
    schema: String,
    requests: Vec<batch::Request>,
    targets: Vec<Target>,
    postconditions: Option<author::BatchPostconditions>,
    checks: Vec<String>,
    #[serde(default)]
    acceptance_checks: Vec<String>,
    #[serde(default)]
    change_scope: Option<super::change_scope::Binding>,
    delivery: Delivery,
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct Target {
    id: String,
    handle: batch::Argument,
    op: task::AuthorOperation,
    from: Option<PathBuf>,
    #[serde(default)]
    fragment: Option<String>,
    #[serde(default)]
    scalar: Option<super::semantic_intent::ScalarRequest>,
    #[serde(default)]
    disclosed: Option<super::disclose::EditRequest>,
    #[serde(default)]
    disclosed_ir: Option<super::disclose::IrEditRequest>,
}

#[derive(Clone, Debug, Deserialize, Serialize)]
#[serde(deny_unknown_fields, rename_all = "kebab-case")]
pub(crate) struct Delivery {
    #[serde(default)]
    pub check_original: bool,
    #[serde(default)]
    pub compact_success: bool,
    #[serde(default)]
    pub exercise_reversal: bool,
    pub patch: Option<PathBuf>,
    #[serde(default = "default_check_output_bytes")]
    pub check_output_bytes: usize,
}

fn default_check_output_bytes() -> usize {
    4_096
}

fn read_manifest(root: &Path, path: &Path) -> Result<Vec<u8>> {
    let mut bytes = Vec::new();
    if path == Path::new("-") {
        io::stdin()
            .take(MAX_INPUT_BYTES + 1)
            .read_to_end(&mut bytes)
            .context("reading task-change manifest from standard input")?;
    } else {
        let path = root.join(path);
        ensure!(
            fs::symlink_metadata(&path)?.is_file(),
            "task-change manifest must be a regular file."
        );
        fs::File::open(&path)
            .with_context(|| format!("opening task-change manifest {}", path.display()))?
            .take(MAX_INPUT_BYTES + 1)
            .read_to_end(&mut bytes)?;
    }
    ensure!(
        bytes.len() as u64 <= MAX_INPUT_BYTES,
        "task-change manifest exceeds 64 KiB."
    );
    Ok(bytes)
}

fn batch_operation(operation: task::AuthorOperation) -> author::BatchOperation {
    match operation {
        task::AuthorOperation::ReplaceBody => author::BatchOperation::ReplaceBody,
        task::AuthorOperation::ReplaceBodySemantic => author::BatchOperation::ReplaceBodySemantic,
        task::AuthorOperation::EditBodySemantic => author::BatchOperation::EditBodySemantic,
        task::AuthorOperation::EditBodyIntent => author::BatchOperation::EditBodyIntent,
        task::AuthorOperation::EditBodyScalar => author::BatchOperation::EditBodyScalar,
        task::AuthorOperation::EditBodyDisclosed => author::BatchOperation::EditBodyDisclosed,
        task::AuthorOperation::EditBodyDisclosedIr => author::BatchOperation::EditBodyDisclosedIr,
        task::AuthorOperation::ReplaceDeclaration => author::BatchOperation::ReplaceDeclaration,
        task::AuthorOperation::InsertDeclaration => author::BatchOperation::InsertDeclaration,
        task::AuthorOperation::OrganizeImports => author::BatchOperation::OrganizeImports,
        task::AuthorOperation::Refactor => author::BatchOperation::Refactor,
    }
}

#[derive(Clone)]
pub(crate) struct Prepared {
    pub plan: author::Plan,
    pub report: Value,
    pub manifest_sha256: String,
    pub checks: crate::checks::Selection,
    pub acceptance_checks: Option<crate::workflow::AcceptanceRequest>,
    pub delivery: Delivery,
}

impl Project<'_> {
    pub(crate) fn task_change(&self, options: &Options) -> Result<Prepared> {
        let bytes = read_manifest(&self.root, &options.from)?;
        self.task_change_bytes(&bytes, options.diff_bytes, options.report_bytes)
    }

    pub(crate) fn task_change_bytes(
        &self,
        bytes: &[u8],
        diff_bytes: usize,
        report_bytes: usize,
    ) -> Result<Prepared> {
        let manifest: Manifest = serde_json::from_slice(bytes)
            .context("task-change input must be a task-change manifest.")?;
        let structural = manifest
            .targets
            .iter()
            .any(|target| target.op == task::AuthorOperation::Refactor);
        ensure!(
            !structural || manifest.change_scope.is_some(),
            "structural task changes require a fresh consumer scope binding"
        );
        ensure!(
            manifest.schema == SCHEMA,
            "task-change manifest schema must be {SCHEMA}."
        );
        ensure!(
            manifest.delivery.check_output_bytes <= 65_536,
            "task-change check output budget must be between 0 and 65536 bytes."
        );
        ensure!(
            !manifest.checks.is_empty(),
            "task change requires at least one declared check."
        );
        for target in &manifest.targets {
            let fragment_inputs =
                usize::from(target.from.is_some()) + usize::from(target.fragment.is_some());
            ensure!(
                fragment_inputs == usize::from(target.op.needs_fragment()),
                "task-change target '{}' must provide exactly one of 'from' or inline 'fragment' when its operation needs source, and neither otherwise.",
                target.id
            );
            if let Some(fragment) = &target.fragment {
                ensure!(
                    fragment.len() <= 65_536,
                    "task-change target '{}' inline fragment exceeds 64 KiB.",
                    target.id
                );
                ensure!(
                    !fragment.contains('\0'),
                    "task-change target '{}' inline fragment contains a NUL byte.",
                    target.id
                );
            }
            ensure!(
                matches!(target.op, task::AuthorOperation::EditBodyScalar)
                    == target.scalar.is_some(),
                "task-change target '{}' has an invalid scalar choice.",
                target.id
            );
            ensure!(
                matches!(target.op, task::AuthorOperation::EditBodyDisclosed)
                    == target.disclosed.is_some(),
                "task-change target '{}' has an invalid disclosed choice.",
                target.id
            );
            ensure!(
                matches!(target.op, task::AuthorOperation::EditBodyDisclosedIr)
                    == target.disclosed_ir.is_some(),
                "task-change target '{}' has an invalid disclosed_ir choice.",
                target.id
            );
            if let Some(disclosed) = &target.disclosed {
                ensure!(
                    super::disclose::edit_id_well_formed(&disclosed.edit),
                    "task-change target '{}' requires an exact returned edit ID.",
                    target.id
                );
            }
            if let Some(disclosed_ir) = &target.disclosed_ir {
                ensure!(
                    super::disclose::ir_edit_id_well_formed(&disclosed_ir.edit),
                    "task-change target '{}' requires an exact returned IR edit ID.",
                    target.id
                );
            }
        }

        let task_manifest = task::Manifest {
            schema: task::SCHEMA.to_owned(),
            requests: manifest.requests.clone(),
            targets: manifest
                .targets
                .iter()
                .map(|target| task::Target {
                    id: target.id.clone(),
                    handle: target.handle.clone(),
                    op: target.op,
                    scalar: target.scalar.clone(),
                    disclosed: target.disclosed.clone(),
                    disclosed_ir: target.disclosed_ir.clone(),
                })
                .collect(),
            checks: manifest.checks.clone(),
            delivery: Some(task::Delivery {
                exercise_reversal: manifest.delivery.exercise_reversal,
                patch: manifest.delivery.patch.clone(),
            }),
        };
        let mut task_report = self.task_manifest(task_manifest, report_bytes)?;
        let resolved = task_report["targets"]
            .as_array()
            .context("task-change targets must be an array")?;
        ensure!(
            resolved.len() == manifest.targets.len(),
            "task-change target resolution count changed."
        );
        let scope = manifest
            .change_scope
            .as_ref()
            .map(|binding| {
                let handles = resolved
                    .iter()
                    .map(|row| {
                        row["handle"]
                            .as_str()
                            .context("scope target has no handle")
                            .map(str::to_owned)
                    })
                    .collect::<Result<Vec<_>>>()?;
                let checks = manifest
                    .checks
                    .iter()
                    .chain(&manifest.acceptance_checks)
                    .cloned()
                    .collect::<Vec<_>>();
                super::change_scope::validate_bound(self, binding, &handles, &checks)
            })
            .transpose()?;
        let inline_root =
            tempfile::tempdir().context("creating inline task-change fragment directory")?;
        let operations = manifest
            .targets
            .iter()
            .zip(resolved)
            .enumerate()
            .map(|(index, (target, row))| {
                let from = if let Some(fragment) = &target.fragment {
                    let path = inline_root.path().join(format!("fragment-{index}"));
                    fs::write(&path, fragment).context("writing inline task-change fragment")?;
                    Some(path)
                } else {
                    target.from.clone()
                };
                Ok(author::BatchStep {
                    op: batch_operation(target.op),
                    handle: row["handle"]
                        .as_str()
                        .context("task-change target has no resolved handle")?
                        .to_owned(),
                    from,
                    scalar: target.scalar.clone(),
                    disclosed: target.disclosed.clone(),
                    disclosed_ir: target.disclosed_ir.clone(),
                })
            })
            .collect::<Result<Vec<_>>>()?;
        let plan = self.author_batch_manifest(
            author::BatchManifest {
                revision: task_report["revision"].as_str().map(str::to_owned),
                operations,
                postconditions: manifest.postconditions,
            },
            diff_bytes,
        )?;
        if let Some(scope) = &scope {
            let paths = scope["affected_paths"]
                .as_array()
                .context("scope has no affected paths")?;
            ensure!(
                plan.edits.paths().all(|path| path
                    .strip_prefix(&self.root)
                    .ok()
                    .is_some_and(|relative| paths.iter().any(|p| p.as_str() == relative.to_str()))),
                "task-change edits leave the reviewed consumer scope."
            );
        }
        let checks = crate::checks::select(&self.root, &manifest.checks)?
            .context("task change requires at least one declared check.")?;
        ensure!(
            manifest.acceptance_checks.len() <= 32,
            "task change accepts at most 32 acceptance checks."
        );
        let acceptance_checks = crate::checks::select(&self.root, &manifest.acceptance_checks)?
            .map(|selection| -> Result<_> {
                Ok(crate::workflow::AcceptanceRequest {
                    basis: selection.configuration_basis,
                    names: selection.checks,
                    toolchain_digest: crate::checks::evidence::toolchain_digest(&self.root)?,
                })
            })
            .transpose()?;
        let manifest_sha256 = hex::encode(Sha256::digest(bytes));
        for field in [
            "author_manifest_template",
            "workflow_manifest_template",
            "next",
        ] {
            task_report.as_object_mut().unwrap().remove(field);
        }
        let mut report = json!({
            "schema": SCHEMA,
            "manifest_sha256": manifest_sha256,
            "revision": task_report["revision"],
            "task_basis": task_report["task_basis"],
            "task_resolution_basis": task_report["task_resolution_basis"],
            "coverage": task_report["coverage"],
            "requests": task_report["requests"],
            "targets": task_report["targets"],
            "checks": task_report["checks"],
            "delivery": {
                "check_original": manifest.delivery.check_original,
                "compact_success": manifest.delivery.compact_success,
                "exercise_reversal": manifest.delivery.exercise_reversal,
                "patch": manifest.delivery.patch,
                "check_output_bytes": manifest.delivery.check_output_bytes,
            },
            "executed": false,
            "passed": Value::Null,
        });
        if let Some(scope) = scope {
            report["change_scope"] = scope;
        }
        if let Some(request) = &acceptance_checks {
            report["acceptance_checks"] = json!(request);
        }
        Ok(Prepared {
            plan,
            report,
            manifest_sha256,
            checks,
            acceptance_checks,
            delivery: manifest.delivery,
        })
    }
}

pub(crate) fn review_basis(report: &Value, exact_changes: &Value) -> Result<String> {
    Ok(format!(
        "frtc1:{}",
        hex::encode(Sha256::digest(serde_json::to_vec(&(
            "fr-task-change-review-1",
            report,
            exact_changes
        ))?))
    ))
}

pub fn task_change_mode(
    complete_review: bool,
    write: bool,
    basis_supplied: bool,
    basis_matches: bool,
) -> usize {
    match (complete_review, write, basis_supplied, basis_matches) {
        (true, false, false, _) => 0,
        (true, true, true, true) => 1,
        _ => 2,
    }
}

#[doc = "Finite draft/review/execute admission kernel mirrored by the agent runtime SDK."]
pub fn agent_session_step(
    state: usize,
    action: usize,
    preview_valid: bool,
    manifest_matches: bool,
    basis_matches: bool,
) -> usize {
    match (
        state,
        action,
        preview_valid,
        manifest_matches,
        basis_matches,
    ) {
        (0, 0, true, _, _) => 1,
        (1, 1, true, true, true) => 2,
        _ => 3,
    }
}
