//! Move a top-level definition to another file, updating whatever that language's own
//! resolution rules require.

use super::Refusal;
use crate::edit::{full_line_span, line_indent, Edit, EditSet};
use crate::index::Index;
use crate::lang::Language;
use crate::model::{anchor_slug as slug, Symbol, SymbolId, SymbolKind};
use crate::span::{LineIndex, Span};
use anyhow::Result;
use std::collections::{BTreeMap, BTreeSet, HashSet};
use std::path::{Path, PathBuf};

/// A move worked out but not applied.
#[derive(Debug)]
pub struct MovePlan {
    pub symbol: String,
    pub from: PathBuf,
    pub to: PathBuf,
    pub edits: EditSet,
    /// Files that gained an import, or, in Markdown, which has none, whose links now point at
    /// the new document.
    pub imports_added: Vec<PathBuf>,
    /// Things the move could not fix and a human must check.
    pub warnings: Vec<String>,
}

impl MovePlan {
    fn new(sym: &Symbol, destination: &Path) -> Self {
        MovePlan {
            symbol: sym.name.clone(),
            from: sym.file.clone(),
            to: destination.to_path_buf(),
            edits: EditSet::new(),
            imports_added: Vec::new(),
            warnings: Vec::new(),
        }
    }
}

/// Why a move is not a thing in this language, if it is not.
pub fn why_not_move(language: Language) -> Option<&'static str> {
    match language {
        // A document does not import another's elements, so a moved element has no
        // reference anywhere to update.
        Language::Html | Language::Xml => Some(
            "an element has no name that another document imports, so moving one \
             between files changes what each document *is* and not where a \
             definition lives",
        ),
        // Java ties a file's name to the public type inside it and imports by fully-qualified
        // name and not by path.
        Language::Java => Some(
            "a public type must live in a file named after it and imports name packages \
             and not paths, so moving one is a rename of the file and its package, \
             not a move of a definition",
        ),
        _ => None,
    }
}

/// Move `symbol` into `destination`.
pub fn to_file(index: &Index, symbol: SymbolId, destination: &Path) -> Result<MovePlan> {
    if let Some(language) = index.symbol(symbol).map(|s| s.language) {
        crate::capabilities::record(crate::capabilities::Capability::MoveToFile, language);
    }
    let sym = index
        .symbol(symbol)
        .ok_or_else(|| anyhow::anyhow!("unknown symbol"))?;

    if destination == sym.file {
        return Err(Refusal::Declined {
            detail: format!("'{}' is already in {}", sym.name, destination.display()),
        }
        .into());
    }

    let Some(dest_language) = crate::lang::detect(destination) else {
        return Err(Refusal::NotHere {
            operation: "move to file".into(),
            detail: format!(
                "the destination {} has no recognised language, so '{}' has nowhere to \
                 land in it",
                destination.display(),
                sym.name
            ),
        }
        .into());
    };
    if !interchangeable(sym.language, dest_language) {
        return Err(Refusal::NotHere {
            operation: "move to file".into(),
            detail: format!(
                "'{}' is {}, but the destination {} is {}; a move cannot change language",
                sym.name,
                sym.language,
                destination.display(),
                dest_language
            ),
        }
        .into());
    }

    if let Some(why) = why_not_move(sym.language) {
        return Err(Refusal::Unsupported {
            operation: "move to file".into(),
            language: sym.language,
            because: why,
        }
        .into());
    }

    match sym.language {
        Language::TypeScript | Language::Tsx | Language::Python => {
            move_by_relative_import(index, sym, destination)
        }
        Language::Rust => move_rust(index, sym, destination),
        Language::Go => move_go(index, sym, destination),
        Language::Hcl => move_hcl(index, sym, destination),
        Language::Css | Language::Scss | Language::Sass => move_css(index, sym, destination),
        Language::Markdown => move_markdown(index, sym, destination),
        Language::Zig => move_zig(index, sym, destination),
        Language::Lean => move_lean(index, sym, destination),
        Language::Bash => move_bash(index, sym, destination),
        Language::Yaml | Language::Helm => move_values_key(index, sym, destination),
        // A JSON key's path is its address, the same as a YAML key's, so the
        // same move carries one.
        Language::Json => move_values_key(index, sym, destination),
        // Java ties a file's name to the public type inside it and imports by fully-qualified
        // name and not by path.
        Language::Java => Err(Refusal::Unsupported {
            operation: "move to file".into(),
            language: Language::Java,
            because: "a public type must live in a file named after it and imports name \
                      packages and not paths, so moving one is a rename of the file \
                      and its package, not a move of a definition",
        }
        .into()),
        // An element carries its address in its position in one document.
        other @ (Language::Html | Language::Xml) => Err(Refusal::Unsupported {
            operation: "move to file".into(),
            language: other,
            because: "an element has no name that another document imports, so moving \
                      one between files changes what each document *is* and not \
                      where a definition lives",
        }
        .into()),
    }
}

/// May a symbol written in `from` land in a file of language `to`?
fn interchangeable(from: Language, to: Language) -> bool {
    from == to
        || matches!(
            (from, to),
            (Language::TypeScript, Language::Tsx)
                | (Language::Tsx, Language::TypeScript)
                | (Language::Css, Language::Scss)
                | (Language::Scss, Language::Css)
        )
}

// TypeScript and Python: resolution follows relative paths.

/// A file that exports `sym`'s name onward from the file that declares it.
fn re_exporting_files(index: &Index, sym: &Symbol) -> Vec<PathBuf> {
    let mut out: Vec<PathBuf> = index
        .files()
        .filter(|(path, info)| {
            info.imports.iter().any(|import| {
                import.re_export
                    && index
                        .resolve_import_path(path, &import.path)
                        .is_some_and(|target| target == sym.file)
                    // A star hands on whatever the file exports, so it hands on this too.
                    && (import.names.iter().any(|n| n.local == sym.name)
                        || re_exports_everything(info, import))
            })
        })
        .map(|(path, _)| path.clone())
        .collect();
    out.sort();
    out
}

/// Whether a re-export is a star: `export * from "./x"`.
fn re_exports_everything(info: &crate::index::FileInfo, import: &crate::model::Import) -> bool {
    import.alias.is_none()
        && !info
            .imports
            .iter()
            .any(|other| other.span == import.span && !other.names.is_empty())
}

/// Whether a re-export binds one name for the whole module: `export * as ns from "./x"`.
fn re_exports_under_one_name(import: &crate::model::Import) -> bool {
    import.re_export && import.alias.is_some() && import.names.is_empty()
}

/// Whether `file` still exports something once `moved` is out of it.
fn exports_anything_else(index: &Index, file: &Path, moved: SymbolId) -> bool {
    let Some(info) = index.file(file) else {
        return false;
    };
    info.symbols
        .iter()
        .filter_map(|id| index.symbol(*id))
        .any(|s| s.id != moved && s.exported && s.is_top_level())
        || info.imports.iter().any(|import| import.re_export)
}

/// Move a barrel's export of the symbol from the file it left to the file it landed in.
fn repoint_re_export(
    index: &Index,
    sym: &Symbol,
    barrel: &Path,
    destination: &Path,
    plan: &mut MovePlan,
) -> Result<()> {
    let Some(info) = index.file(barrel) else {
        return Ok(());
    };
    let source = crate::vfs::read_to_string(barrel)?;

    let points_at_the_source = |import: &crate::model::Import| {
        index.resolve_import_path(barrel, &import.path).as_deref() == Some(sym.file.as_path())
    };

    // `export * as ns from "./holder"` hands the whole module on under one name, and readers
    // write `ns.width`.
    if let Some(named) = info
        .imports
        .iter()
        .find(|i| re_exports_under_one_name(i) && points_at_the_source(i))
    {
        return Err(Refusal::Declined {
            detail: format!(
                "{} re-exports {} as `{}`, so readers write `{}.{}`. Moving '{}' out would \
             leave that name reaching a module it is no longer in, and no repointing of \
             one statement can follow it",
                barrel.display(),
                sym.file.display(),
                named.alias.as_deref().unwrap_or_default(),
                named.alias.as_deref().unwrap_or_default(),
                sym.name,
                sym.name
            ),
        }
        .into());
    }

    // A star hands on whatever the source exports, and the symbol is about to stop being one of
    // them.
    if let Some(star) = info
        .imports
        .iter()
        .find(|i| i.re_export && re_exports_everything(info, i) && points_at_the_source(i))
    {
        let already = info.imports.iter().any(|other| {
            other.re_export
                && other.span != star.span
                && index.resolve_import_path(barrel, &other.path).as_deref() == Some(destination)
        });
        let line = whole_lines(&source, star.span);
        // The symbol was the last thing the source exported, so the star has nothing left to
        // hand on.
        let replacement = match exports_anything_else(index, &sym.file, sym.id) {
            true => source[line.start..line.end].to_string(),
            false => String::new(),
        };
        if already {
            plan.edits.add(
                barrel.to_path_buf(),
                Edit::new(line, replacement, format!("what {} left behind", sym.name)),
            );
            return Ok(());
        }
        let module = relative_module(barrel, destination).ok_or_else(|| {
            anyhow::anyhow!(
                "cannot express {} as a module path from {}, so nothing can repoint the \
                 re-export of '{}'",
                destination.display(),
                barrel.display(),
                sym.name
            )
        })?;
        plan.edits.add(
            barrel.to_path_buf(),
            Edit::new(
                line,
                format!("{replacement}export {{ {} }} from '{module}';\n", sym.name),
                format!("re-export {} from its new home", sym.name),
            ),
        );
        return Ok(());
    }

    // The index records one entry per exported name, each carrying the span of the whole
    // statement it came from.
    let statement_spans: Vec<Span> = info
        .imports
        .iter()
        .filter(|import| {
            import.re_export
                && import.names.iter().any(|n| n.local == sym.name)
                && index.resolve_import_path(barrel, &import.path).as_deref()
                    == Some(sym.file.as_path())
        })
        .map(|import| import.span)
        .collect();

    let mut statements: Vec<(Span, String, Vec<crate::model::ImportedName>)> = Vec::new();
    for import in &info.imports {
        if !statement_spans.contains(&import.span) {
            continue;
        }
        match statements
            .iter_mut()
            .find(|(span, _, _)| *span == import.span)
        {
            Some((_, _, names)) => names.extend(import.names.iter().cloned()),
            None => statements.push((import.span, import.path.clone(), import.names.clone())),
        }
    }

    for (span, path, names) in statements {
        let mut kept: Vec<&crate::model::ImportedName> =
            names.iter().filter(|n| n.local != sym.name).collect();
        kept.sort_by_key(|n| n.span.start);
        kept.dedup_by_key(|n| n.span.start);

        let narrowed = match kept.is_empty() {
            true => String::new(),
            false => {
                let spelled: Vec<String> = kept
                    .iter()
                    .map(|n| n.span.text(&source).to_string())
                    .collect();
                format!("export {{ {} }} from '{path}';\n", spelled.join(", "))
            }
        };
        // Where the barrel is itself the destination, it declares the name now, and a file
        // does not re-export from itself.
        let onward = match barrel == destination {
            true => String::new(),
            false => {
                let module = relative_module(barrel, destination).ok_or_else(|| {
                    anyhow::anyhow!(
                        "cannot express {} as a module path from {}, so nothing can repoint \
                         the re-export of '{}'",
                        destination.display(),
                        barrel.display(),
                        sym.name
                    )
                })?;
                format!("export {{ {} }} from '{module}';\n", sym.name)
            }
        };

        plan.edits.add(
            barrel.to_path_buf(),
            Edit::new(
                whole_lines(&source, span),
                format!("{narrowed}{onward}"),
                format!("re-export {} from its new home", sym.name),
            ),
        );
    }
    Ok(())
}

/// Whether `file` already receives `name` by importing one of the barrels.
fn reaches_through_a_barrel(index: &Index, file: &Path, barrels: &[PathBuf], name: &str) -> bool {
    let Some(info) = index.file(file) else {
        return false;
    };
    info.imports.iter().any(|import| {
        import.names.iter().any(|n| n.local == name)
            && index
                .resolve_import_path(file, &import.path)
                .is_some_and(|target| barrels.contains(&target))
    })
}

fn move_by_relative_import(index: &Index, sym: &Symbol, destination: &Path) -> Result<MovePlan> {
    if sym.container.is_some() {
        return Err(Refusal::Declined {
            detail: format!(
                "'{}' is nested inside another definition; only a top-level symbol moves",
                sym.name
            ),
        }
        .into());
    }

    // A barrel exports the symbol from the file it is leaving: `export { width } from
    // "./holder"`.
    let barrels = re_exporting_files(index, sym);

    let source = crate::vfs::read_to_string(&sym.file)?;
    let removal = whole_lines(&source, sym.full_span);
    let moved_text = removal.text(&source).to_string();

    let mut plan = MovePlan::new(sym, destination);
    plan.edits.add(
        sym.file.clone(),
        Edit::new(
            removal_with_separator(&source, removal),
            "",
            format!("move {} out", sym.name),
        ),
    );

    for barrel in &barrels {
        repoint_re_export(index, sym, barrel, destination, &mut plan)?;
    }

    // Every file that referenced it now needs an import, including the file it came from, if
    // references remain there.
    let mut needs_import: BTreeSet<PathBuf> = BTreeSet::new();
    for reference in index.references_to(sym.id) {
        if reference.file == *destination
            || barrels.contains(&reference.file)
            || reaches_through_a_barrel(index, &reference.file, &barrels, &sym.name)
        {
            continue;
        }
        // A reference inside the moved span travels with it.
        if reference.file == sym.file && removal.contains(reference.span) {
            continue;
        }
        needs_import.insert(reference.file.clone());
    }

    // Code that moves has to keep working where it lands: it needs whatever it referenced.
    let used = names_used_in(sym.language, &source, removal)?;
    let (carried, imports_the_source_back) =
        carried_imports(index, sym, destination, &used, &source, &mut plan);

    // Both files would end up importing the other: the source needs the moved symbol back, and
    // the moved symbol needs names the source kept.
    let destination_reaches_back =
        imports_the_source_back || still_imports_from(index, destination, &sym.file, &sym.name);
    if sym.language == Language::Python
        && destination_reaches_back
        && needs_import.contains(&sym.file)
    {
        return Err(Refusal::Declined {
            detail: format!(
                "moving '{}' to {} would make the two files import each other: {} would \
             import '{}' from its new home, and {} would import back what '{}' still \
             uses. Python fails on that cycle at import time. Move the names '{}' uses \
             as well, or move it to a file neither imports.",
                sym.name,
                destination.display(),
                sym.file.display(),
                sym.name,
                destination.display(),
                sym.name,
                sym.name
            ),
        }
        .into());
    }
    let moved_text = if needs_import.is_empty() {
        moved_text
    } else {
        exported(sym.language, &moved_text)
    };
    // The imports the moved code needs go where imports go, not immediately above the code.
    if !carried.is_empty() {
        let existing = crate::vfs::read_to_string(destination).unwrap_or_default();
        let at = import_insertion_point_for(index, destination, &existing);
        plan.edits.add(
            destination.to_path_buf(),
            Edit::new(
                Span::new(at, at),
                carried.clone(),
                format!("what {} needs where it lands", sym.name),
            ),
        );
    }
    append_to_destination(
        &mut plan.edits,
        destination,
        &moved_text,
        format!("move {} in", sym.name),
    );

    // The destination may already have been importing it from here.
    if let Some(edit) = drop_local_import(index, destination, &sym.file, &sym.name)? {
        plan.edits.add(destination.to_path_buf(), edit);
    }

    for file in &needs_import {
        // The importer may already bind the name from the file it is leaving, under an alias
        // the rest of the file calls it by.
        if repoint_existing_imports(index, file, sym, destination, &mut plan.edits)? {
            plan.imports_added.push(file.clone());
            continue;
        }
        // `import mod` and `mod.foo()` reach the symbol through the module, and there is no
        // named import to repoint.
        if repoint_module_attribute_uses(index, file, sym, destination, &mut plan.edits)? {
            plan.imports_added.push(file.clone());
            continue;
        }
        let statement = import_statement(sym.language, file, destination, &sym.name)?;
        let target_source = crate::vfs::read_to_string(file).unwrap_or_default();
        let insert = import_insertion_point_for(index, file, &target_source);
        plan.edits.add(
            file.clone(),
            Edit::new(
                Span::new(insert, insert),
                statement,
                format!("import {} from its new home", sym.name),
            ),
        );
        plan.imports_added.push(file.clone());
    }

    Ok(plan)
}

/// Remove the destination's import of a name it is about to define itself.
fn drop_local_import(
    index: &Index,
    destination: &Path,
    from: &Path,
    name: &str,
) -> Result<Option<Edit>> {
    let Some(info) = index.file(destination) else {
        return Ok(None);
    };
    let Ok(source) = crate::vfs::read_to_string(destination) else {
        return Ok(None);
    };
    for import in import_statements(&info.imports) {
        if !import.names.iter().any(|n| n.local == name) {
            continue;
        }
        // Only the import that names the file the symbol is leaving.
        if !import_points_at(&import, destination, from) {
            continue;
        }
        let kept: Vec<&crate::model::ImportedName> =
            import.names.iter().filter(|n| n.local != name).collect();
        let replacement = match kept.is_empty() {
            true => String::new(),
            false => {
                let spelled: Vec<String> = kept
                    .iter()
                    .map(|n| n.span.text(&source).to_string())
                    .collect();
                match info.language {
                    Language::Python => {
                        format!("from {} import {}\n", import.path, spelled.join(", "))
                    }
                    _ => format!(
                        "import {{ {} }} from '{}';\n",
                        spelled.join(", "),
                        import.path
                    ),
                }
            }
        };
        let span = whole_lines(&source, import.span);
        return Ok(Some(Edit::new(
            span,
            replacement,
            format!("`{name}` is defined here now"),
        )));
    }
    Ok(None)
}

/// Whether an import statement written in `file` names `target`.
fn import_points_at(import: &ImportStatement, file: &Path, target: &Path) -> bool {
    repoint(&import.path, file, target)
        .map(|path| path == import.path)
        .unwrap_or(false)
        || import.path.ends_with(&stem(target))
}

/// Whether `destination` will still import from `from` once `name` stops coming from there.
fn still_imports_from(index: &Index, destination: &Path, from: &Path, name: &str) -> bool {
    let Some(info) = index.file(destination) else {
        return false;
    };
    import_statements(&info.imports).iter().any(|import| {
        import_points_at(import, destination, from)
            && import.names.iter().any(|imported| imported.local != name)
    })
}

/// A file's name without its extension, for matching a relative import against it.
fn stem(file: &Path) -> String {
    file.file_stem()
        .map(|s| s.to_string_lossy().to_string())
        .unwrap_or_default()
}

/// Every identifier the moved region names.
fn names_used_in(
    language: Language,
    source: &str,
    region: Span,
) -> Result<std::collections::HashSet<String>> {
    let parsed = crate::parse::Parsers::new().parse(language, source)?;
    let mut names = std::collections::HashSet::new();
    let mut stack = vec![parsed.root()];
    while let Some(node) = stack.pop() {
        let span = Span::from(node);
        if span.end <= region.start || span.start >= region.end {
            continue;
        }
        if node.kind().ends_with("identifier") {
            names.insert(span.text(source).to_string());
        }
        let mut cursor = node.walk();
        stack.extend(node.children(&mut cursor));
    }
    Ok(names)
}

/// The imports the moved text needs at the top of its new file.
fn carried_imports(
    index: &Index,
    sym: &Symbol,
    destination: &Path,
    used: &std::collections::HashSet<String>,
    source: &str,
    plan: &mut MovePlan,
) -> (String, bool) {
    let Some(info) = index.file(&sym.file) else {
        return (String::new(), false);
    };
    let mut statements: Vec<String> = Vec::new();
    // Whether the moved code has to reach back into the file it left, which is one half of an
    // import cycle.
    let mut imports_the_source_back = false;

    // Names the destination already binds.
    let bound_at_destination: std::collections::HashSet<String> = index
        .file(destination)
        .map(|dest| {
            import_statements(&dest.imports)
                .into_iter()
                .flat_map(|statement| {
                    let implicit =
                        crate::refactor::imports::implicit_binding(&statement.path, sym.language);
                    statement
                        .names
                        .iter()
                        .map(|n| n.local.clone())
                        .collect::<Vec<_>>()
                        .into_iter()
                        .chain(statement.alias.clone())
                        .chain(implicit)
                })
                .collect()
        })
        .unwrap_or_default();
    let used: std::collections::HashSet<String> = used
        .iter()
        .filter(|name| !bound_at_destination.contains(*name))
        .cloned()
        .collect();
    let used = &used;

    for statement in import_statements(&info.imports) {
        // `import os` binds `os` without naming it anywhere in the statement, and the moved
        // code reaches `os.path.basename` through that binding.
        let implicit = crate::refactor::imports::implicit_binding(&statement.path, sym.language);
        // `from __future__ import annotations` binds nothing and changes how the runtime reads
        // every annotation in the file.
        let governs_the_file = statement.path == "__future__";
        let binds_something_used = governs_the_file
            || statement.names.iter().any(|n| used.contains(&n.local))
            || statement.alias.as_ref().is_some_and(|a| used.contains(a))
            || implicit.as_deref().is_some_and(|b| used.contains(b));
        if !binds_something_used {
            continue;
        }
        // The moved code imported this from the very file it is landing in.
        if index
            .resolve_import_path(&sym.file, &statement.path)
            .as_deref()
            == Some(destination)
        {
            continue;
        }
        match repoint(&statement.path, &sym.file, destination) {
            Some(path) => statements.push(narrowed_import(
                sym.language,
                &statement,
                used,
                &path,
                source,
            )),
            None => plan.warnings.push(format!(
                "the moved code uses `{}`, imported from `{}`; the new file has no way to \
                 spell that path, so this dropped the import",
                statement
                    .names
                    .iter()
                    .map(|n| n.local.as_str())
                    .collect::<Vec<_>>()
                    .join(", "),
                statement.path
            )),
        }
    }

    // Names the source file defines that the moved code still needs.
    let mut wanted: Vec<&crate::model::Symbol> = info
        .symbols
        .iter()
        .filter_map(|id| index.symbol(*id))
        .filter(|s| s.id != sym.id && s.is_top_level() && used.contains(&s.name))
        .collect();
    wanted.sort_by(|a, b| a.name.cmp(&b.name));
    wanted.dedup_by(|a, b| a.name == b.name);

    if !wanted.is_empty() {
        let names: Vec<String> = wanted.iter().map(|s| s.name.clone()).collect();
        match back_import(sym.language, destination, &sym.file, &names) {
            Some(statement) => {
                statements.push(statement);
                for symbol in &wanted {
                    if let Some(edit) = export_edit(sym.language, &sym.file, symbol) {
                        plan.edits.add(sym.file.clone(), edit);
                    }
                }
                imports_the_source_back = true;
            }
            None => plan.warnings.push(format!(
                "the moved code uses {} from {}, and the new file has no way to spell an \
                 import back to it",
                names.join(", "),
                sym.file.display()
            )),
        }
    }

    if statements.is_empty() {
        return (String::new(), imports_the_source_back);
    }
    // `__future__` must be the first statement in the file, so it leads whatever
    // else came along.
    statements.sort_by_key(|s| !s.contains("__future__"));
    (
        format!("{}\n", statements.join("")),
        imports_the_source_back,
    )
}

/// The same module, named from the destination instead of the source.
fn repoint(path: &str, from: &Path, to: &Path) -> Option<String> {
    if !path.starts_with('.') {
        return Some(path.to_string());
    }
    let from_dir = from.parent()?;
    let target = crate::vfs::normalise(from_dir.join(path.trim_start_matches("./")));
    let stem_holder = target.clone();
    relative_module(to, &stem_holder.with_extension("ts")).or_else(|| Some(path.to_string()))
}

/// One import statement, with every name it binds.
struct ImportStatement {
    path: String,
    alias: Option<String>,
    names: Vec<crate::model::ImportedName>,
    span: Span,
}

fn import_statements(imports: &[crate::model::Import]) -> Vec<ImportStatement> {
    let mut grouped: Vec<ImportStatement> = Vec::new();
    for import in imports {
        match grouped.iter_mut().find(|g| g.span == import.span) {
            Some(existing) => {
                for name in &import.names {
                    if !existing.names.iter().any(|n| n.span == name.span) {
                        existing.names.push(name.clone());
                    }
                }
                if existing.alias.is_none() {
                    existing.alias = import.alias.clone();
                }
            }
            None => grouped.push(ImportStatement {
                path: import.path.clone(),
                alias: import.alias.clone(),
                names: import.names.clone(),
                span: import.span,
            }),
        }
    }
    for group in &mut grouped {
        group.names.sort_by_key(|n| n.span.start);
    }
    grouped
}

/// The import as the destination needs it: the new path, and only the names the moved code
/// uses.
fn narrowed_import(
    language: Language,
    import: &ImportStatement,
    used: &std::collections::HashSet<String>,
    path: &str,
    source: &str,
) -> String {
    let statement = import.span.text(source);
    let rewritten = |text: &str| {
        let replaced = text.replacen(&import.path, path, 1);
        if replaced.ends_with('\n') {
            replaced
        } else {
            format!("{replaced}\n")
        }
    };

    let keep: Vec<&crate::model::ImportedName> = import
        .names
        .iter()
        .filter(|n| used.contains(&n.local))
        .collect();
    if keep.is_empty() || keep.len() == import.names.len() {
        return rewritten(statement);
    }

    let spelled: Vec<String> = keep
        .iter()
        .map(|n| {
            let written = n.span.text(source);
            let before = source[..n.span.start].trim_end();
            if before.ends_with("type") && !written.starts_with("type") {
                format!("type {written}")
            } else {
                written.to_string()
            }
        })
        .collect();

    match language {
        Language::Python => format!("from {path} import {}\n", spelled.join(", ")),
        _ => format!("import {{ {} }} from '{path}';\n", spelled.join(", ")),
    }
}

/// An import in the destination naming symbols left behind in the source file.
fn back_import(language: Language, from: &Path, to: &Path, names: &[String]) -> Option<String> {
    let joined = names.join(", ");
    Some(match language {
        Language::TypeScript | Language::Tsx => {
            format!(
                "import {{ {joined} }} from '{}';\n",
                relative_module(from, to)?
            )
        }
        Language::Python => {
            format!("from {} import {joined}\n", python_module_path(from, to)?)
        }
        _ => return None,
    })
}

/// Make a symbol visible outside its file, if the language says so and it is not already.
fn export_edit(language: Language, file: &Path, symbol: &Symbol) -> Option<Edit> {
    if !matches!(language, Language::TypeScript | Language::Tsx) {
        return None;
    }
    let source = crate::vfs::read_to_string(file).ok()?;
    let line_start = whole_lines(&source, symbol.full_span).start;
    let rest = &source[line_start..];
    let lead = rest.len() - rest.trim_start().len();
    let start = line_start + lead;
    let word_len = source[start..]
        .find(|c: char| c.is_whitespace())
        .unwrap_or(source.len() - start);
    let word = &source[start..start + word_len];
    if word == "export" {
        return None;
    }
    Some(Edit::new(
        Span::new(start, start + word_len),
        format!("export {word}"),
        format!("export {} so the moved code can import it", symbol.name),
    ))
}

/// The moved text, exported.
fn exported(language: Language, text: &str) -> String {
    if !matches!(language, Language::TypeScript | Language::Tsx) {
        return text.to_string();
    }
    let body = text.trim_start_matches(['\n', '\r']);
    if body.trim_start().starts_with("export") {
        return text.to_string();
    }
    let lead = &text[..text.len() - body.len()];
    format!("{lead}export {body}")
}

/// The import statement `from` needs to see `name` defined in `to`.
fn repoint_existing_imports(
    index: &Index,
    file: &Path,
    sym: &Symbol,
    destination: &Path,
    edits: &mut EditSet,
) -> Result<bool> {
    let Some(info) = index.file(file) else {
        return Ok(false);
    };
    let module = match sym.language {
        Language::TypeScript | Language::Tsx => relative_module(file, destination),
        Language::Python => python_module_path(file, destination),
        _ => None,
    };
    let Some(module) = module else {
        return Ok(false);
    };
    let source = crate::vfs::read_to_string(file)?;
    let mut handled = false;
    for statement in import_statements(&info.imports) {
        if index.resolve_import_path(file, &statement.path).as_deref() != Some(sym.file.as_path()) {
            continue;
        }
        let (moving, staying): (
            Vec<&crate::model::ImportedName>,
            Vec<&crate::model::ImportedName>,
        ) = statement.names.iter().partition(|n| n.original == sym.name);
        if moving.is_empty() {
            continue;
        }
        let text = statement.span.text(&source);
        let type_import = text.trim_start().starts_with("import type");
        let moved_line = named_import(sym.language, type_import, &module, &moving);
        let replacement = match staying.is_empty() {
            true => moved_line,
            false => format!(
                "{}\n{moved_line}",
                named_import(sym.language, type_import, &statement.path, &staying)
            ),
        };
        edits.add(
            file.to_path_buf(),
            Edit::new(
                statement.span,
                replacement,
                format!("repoint the import of {}", sym.name),
            ),
        );
        handled = true;
    }
    Ok(handled)
}

/// Rewrite `mod.foo()` receivers when the module no longer holds the name.
fn repoint_module_attribute_uses(
    index: &Index,
    file: &Path,
    sym: &Symbol,
    destination: &Path,
    edits: &mut EditSet,
) -> Result<bool> {
    if sym.language != Language::Python {
        return Ok(false);
    }
    let Some(info) = index.file(file) else {
        return Ok(false);
    };
    let bindings: Vec<String> =
        info.imports
            .iter()
            .filter(|import| {
                import.names.is_empty()
                    && index.resolve_import_path(file, &import.path).as_deref()
                        == Some(sym.file.as_path())
            })
            .filter_map(|import| {
                import.alias.clone().or_else(|| {
                    crate::refactor::imports::implicit_binding(&import.path, sym.language)
                })
            })
            .collect();
    if bindings.is_empty() {
        return Ok(false);
    }
    let Some(module) = python_absolute_module(destination) else {
        return Ok(false);
    };
    let source = crate::vfs::read_to_string(file)?;
    let parsed = crate::parse::Parsers::new().parse(sym.language, &source)?;
    let mut handled = false;
    for reference in index.references_to(sym.id) {
        if reference.file != *file {
            continue;
        }
        let receiver_matches = reference
            .receiver
            .as_deref()
            .is_some_and(|r| bindings.iter().any(|b| b == r));
        if !receiver_matches {
            continue;
        }
        let Some(node) = parsed
            .root()
            .descendant_for_byte_range(reference.span.start, reference.span.end)
        else {
            continue;
        };
        let Some(attribute) = node.parent().filter(|p| p.kind() == "attribute") else {
            continue;
        };
        let Some(object) = attribute.child_by_field_name("object") else {
            continue;
        };
        edits.add(
            file.to_path_buf(),
            Edit::new(
                Span::from(object),
                module.clone(),
                format!("reach {} in its new module", sym.name),
            ),
        );
        handled = true;
    }
    if handled {
        let already = info.imports.iter().any(|import| {
            index.resolve_import_path(file, &import.path).as_deref() == Some(destination)
        });
        if !already {
            let at = import_insertion_point_for(index, file, &source);
            edits.add(
                file.to_path_buf(),
                Edit::new(
                    Span::new(at, at),
                    format!("import {module}\n"),
                    format!("import the module now holding {}", sym.name),
                ),
            );
        }
    }
    Ok(handled)
}

/// A named-import statement, each name keeping the alias the source gave it.
fn named_import(
    language: Language,
    type_import: bool,
    module: &str,
    names: &[&crate::model::ImportedName],
) -> String {
    let list = names
        .iter()
        .map(|n| match n.local == n.original {
            true => n.original.clone(),
            false => format!("{} as {}", n.original, n.local),
        })
        .collect::<Vec<_>>()
        .join(", ");
    match language {
        Language::Python => format!("from {module} import {list}"),
        _ => {
            let modifier = if type_import { "type " } else { "" };
            format!("import {modifier}{{ {list} }} from '{module}';")
        }
    }
}

fn import_statement(language: Language, from: &Path, to: &Path, name: &str) -> Result<String> {
    let unresolvable = || {
        anyhow::anyhow!(
            "cannot express {} as a module path from {}, so nothing can spell the \
             import {} needs after the move",
            to.display(),
            from.display(),
            name
        )
    };
    Ok(match language {
        Language::TypeScript | Language::Tsx => {
            let module = relative_module(from, to).ok_or_else(unresolvable)?;
            format!("import {{ {name} }} from '{module}';\n")
        }
        // Python spells a relative module with dots, not slashes.
        Language::Python => {
            let module = python_module_path(from, to).ok_or_else(unresolvable)?;
            format!("from {module} import {name}\n")
        }
        other => {
            return Err(Refusal::Declined {
                detail: format!(
                    "{other} does not move by relative import, so nothing can spell an import \
             statement for {name}"
                ),
            }
            .into())
        }
    })
}

/// A Python module path for `to`, as `from` has to write it.
fn python_module_path(from: &Path, to: &Path) -> Option<String> {
    match in_a_package(from.parent()?) {
        true => python_relative_module(from, to),
        false => python_absolute_module(to),
    }
}

/// Whether a directory is a Python package, which makes a relative import mean
/// anything from inside it.
fn in_a_package(dir: &Path) -> bool {
    crate::vfs::exists(dir.join("__init__.py"))
}

/// The dotted name Python knows `to` by, from wherever it is run.
fn python_absolute_module(to: &Path) -> Option<String> {
    let stem = to.file_stem()?.to_str()?;
    let mut parts = Vec::new();
    let mut dir = to.parent();
    while let Some(here) = dir {
        if !in_a_package(here) {
            break;
        }
        parts.push(here.file_name()?.to_str()?.to_string());
        dir = here.parent();
    }
    parts.reverse();
    parts.push(stem.to_string());
    Some(parts.join("."))
}

/// A Python relative module path for `to`, as seen from `from`.
fn python_relative_module(from: &Path, to: &Path) -> Option<String> {
    let from_dir = from.parent()?;
    let to_dir = to.parent()?;
    let stem = to.file_stem()?.to_str()?;

    let mut ups = 0;
    let mut probe = from_dir;
    loop {
        if let Ok(rest) = to_dir.strip_prefix(probe) {
            let mut module = ".".repeat(ups + 1);
            for part in rest.components() {
                module.push_str(part.as_os_str().to_str()?);
                module.push('.');
            }
            module.push_str(stem);
            return Some(module);
        }
        probe = probe.parent()?;
        ups += 1;
        if ups > 16 {
            return None;
        }
    }
}

/// A module path for `to`, expressed relative to `from`.
fn relative_module(from: &Path, to: &Path) -> Option<String> {
    let from_dir = from.parent()?;
    let stem = to.file_stem()?.to_str()?;
    let to_dir = to.parent()?;

    if from_dir == to_dir {
        return Some(format!("./{stem}"));
    }

    let mut ups = 0;
    let mut probe = from_dir;
    loop {
        if let Ok(rest) = to_dir.strip_prefix(probe) {
            let mut path = if ups == 0 {
                ".".to_string()
            } else {
                vec![".."; ups].join("/")
            };
            for part in rest.components() {
                path.push('/');
                path.push_str(part.as_os_str().to_str()?);
            }
            path.push('/');
            path.push_str(stem);
            return Some(path);
        }
        probe = probe.parent()?;
        ups += 1;
        if ups > 16 {
            return None;
        }
    }
}

/// Where a new import should go: after any existing leading imports.
fn import_insertion_point_for(index: &Index, file: &Path, source: &str) -> usize {
    let Some(info) = index.file(file) else {
        return import_insertion_point(source);
    };
    let Some(end) = info.imports.iter().map(|i| i.span.end).max() else {
        return import_insertion_point(source);
    };
    // Just past the line the last import ends on.
    match source[end..].find('\n') {
        Some(offset) => end + offset + 1,
        None => source.len(),
    }
}

fn import_insertion_point(source: &str) -> usize {
    let mut offset = 0;
    let mut last_import_end = 0;
    for line in source.split_inclusive('\n') {
        let trimmed = line.trim_start();
        if trimmed.starts_with("import ") || trimmed.starts_with("from ") {
            last_import_end = offset + line.len();
        } else if !trimmed.is_empty() && last_import_end > 0 {
            break;
        }
        offset += line.len();
    }
    match last_import_end {
        0 => after_the_prologue(source),
        end => end,
    }
}

/// Where a first import belongs in a file that has none.
fn after_the_prologue(source: &str) -> usize {
    let mut offset = 0;
    let mut lines = source.split_inclusive('\n').peekable();

    // A shebang, then whatever comments and blank lines follow it.
    if lines.peek().is_some_and(|l| l.starts_with("#!")) {
        offset += lines.next().map(str::len).unwrap_or(0);
    }
    while let Some(line) = lines.peek() {
        let trimmed = line.trim_start();
        let is_prologue = trimmed.is_empty()
            || trimmed.starts_with('#')
            || trimmed.starts_with("//")
            || trimmed.starts_with("/*")
            || trimmed.starts_with('*');
        if !is_prologue {
            break;
        }
        offset += line.len();
        lines.next();
    }

    // A module docstring: one string literal standing alone, which may run over
    // several lines.
    let rest = &source[offset..];
    for quote in ["\"\"\"", "'''", "\"", "'"] {
        let Some(after_open) = rest.strip_prefix(quote) else {
            continue;
        };
        let Some(closes) = after_open.find(quote) else {
            break;
        };
        let end = offset + quote.len() + closes + quote.len();
        // Past the line the docstring ends on, so the import starts its own.
        return match source[end..].find('\n') {
            Some(newline) => end + newline + 1,
            None => source.len(),
        };
    }
    offset
}

// Rust: resolution follows module paths.

/// A Rust file's position in a crate.
#[derive(Debug, Clone, PartialEq, Eq)]
struct CrateModule {
    src: PathBuf,
    path: Vec<String>,
}

impl CrateModule {
    /// The `use` prefix naming this module from anywhere in the crate.
    fn use_prefix(&self) -> String {
        let mut out = String::from("crate");
        for segment in &self.path {
            out.push_str("::");
            out.push_str(segment);
        }
        out
    }
}

fn move_rust(index: &Index, sym: &Symbol, destination: &Path) -> Result<MovePlan> {
    if sym.container.is_some() {
        return Err(Refusal::Declined {
            detail: format!(
                "'{}' is nested inside another definition; only a top-level item can moved",
                sym.name
            ),
        }
        .into());
    }

    let from_module = crate_module(&sym.file)?;
    let to_module = crate_module(destination)?;
    if from_module.src != to_module.src {
        // Not `Unsupported`: Rust moves between files perfectly well.
        return Err(Refusal::NotHere {
            operation: "move to file".into(),
            detail: format!(
                "{} and {} are under different crate roots ({} and {}); a move between \
                 crates needs a dependency edge this tool cannot add",
                sym.file.display(),
                destination.display(),
                from_module.src.display(),
                to_module.src.display()
            ),
        }
        .into());
    }

    if let Some(offender) = path_attribute_conflict(index, &to_module.src, destination) {
        return Err(Refusal::Declined {
            detail: format!(
                "{} contains a `#[path]` attribute, so a module's file location no longer \
             follows from its path; refusing to guess a `use` path for {}",
                offender.display(),
                destination.display()
            ),
        }
        .into());
    }

    check_module_is_declared(&to_module, destination)?;

    let source = crate::vfs::read_to_string(&sym.file)?;
    let removal = with_rust_attributes(&source, whole_lines(&source, sym.full_span));
    let moved_text = removal.text(&source).to_string();

    // Everything that still names the item, other than the copy that travels with it.
    let outside: Vec<&crate::model::Reference> = index
        .references_to(sym.id)
        .into_iter()
        .filter(|r| !(r.file == sym.file && removal.contains(r.span)))
        .collect();

    if !sym.exported && outside.iter().any(|r| r.file != *destination) {
        return Err(Refusal::Declined {
            detail: format!(
                "'{}' is private to {}; moving it into {} would put it out of reach of \
             {} use site(s). Make it `pub` (or `pub(crate)`) first.",
                sym.name,
                module_label(&from_module),
                module_label(&to_module),
                outside.iter().filter(|r| r.file != *destination).count()
            ),
        }
        .into());
    }

    let mut plan = MovePlan::new(sym, destination);
    plan.edits.add(
        sym.file.clone(),
        Edit::new(
            removal_with_separator(&source, removal),
            "",
            format!("move {} out", sym.name),
        ),
    );
    append_to_destination(
        &mut plan.edits,
        destination,
        &moved_text,
        format!("move {} in", sym.name),
    );

    // The destination must not keep importing what it now defines.
    if let Some(binding) = binding_import(index, destination, &sym.name) {
        drop_rust_binding(&mut plan.edits, &binding, &sym.name, destination)?;
    }

    let mut needs_use: BTreeSet<PathBuf> = BTreeSet::new();
    let mut unverified: Vec<String> = Vec::new();
    let mut parsed_files: std::collections::BTreeMap<PathBuf, (String, crate::parse::Parsed)> =
        Default::default();
    for reference in &outside {
        if reference.file == *destination {
            continue;
        }
        if !reference.confidence.is_safe_to_rewrite() {
            unverified.push(format!(
                "{} (resolves only '{}')",
                location(&reference.file, reference.span.start),
                reference.confidence.as_str()
            ));
            continue;
        }
        // A use written as a full path names the old module in its own bytes.
        let in_an_import = index.file(&reference.file).is_some_and(|info| {
            info.imports
                .iter()
                .any(|import| import.span.contains(reference.span))
        });
        if !in_an_import && sym.language == Language::Rust {
            let entry = parsed_files.entry(reference.file.clone());
            let loaded = match entry {
                std::collections::btree_map::Entry::Occupied(o) => Some(o.into_mut()),
                std::collections::btree_map::Entry::Vacant(v) => {
                    crate::vfs::read_to_string(&reference.file)
                        .ok()
                        .and_then(|text| {
                            crate::parse::Parsers::new()
                                .parse(sym.language, &text)
                                .ok()
                                .map(|parsed| v.insert((text, parsed)))
                        })
                }
            };
            let prefix_span = loaded.and_then(|(_, parsed)| {
                let node = parsed
                    .root()
                    .descendant_for_byte_range(reference.span.start, reference.span.end)?;
                let parent = node.parent()?;
                if !parent.kind().starts_with("scoped_") {
                    return None;
                }
                (parent.start_byte() < reference.span.start)
                    .then(|| Span::new(parent.start_byte(), reference.span.start))
            });
            if let Some(span) = prefix_span {
                if let Some(prefix) = reachable_prefix(&to_module, &reference.file) {
                    plan.edits.add(
                        reference.file.clone(),
                        Edit::new(
                            span,
                            format!("{prefix}::"),
                            format!("repoint the written path to {}", sym.name),
                        ),
                    );
                    continue;
                }
            }
        }
        needs_use.insert(reference.file.clone());
    }

    // A use site nothing can repoint is a use site left naming a definition that has gone.
    if !unverified.is_empty() {
        return Err(Refusal::Declined {
            detail: format!(
                "{1} site(s) using '{0}' did not resolve conclusively, so nothing can spell \
             the `use` each one needs: {2}. Moving it would leave them naming a \
             definition that is no longer there",
                sym.name,
                unverified.len(),
                unverified.join(", ")
            ),
        }
        .into());
    }

    for file in &needs_use {
        // `crate::` reaches the crate only from inside it.
        let statement = match reachable_prefix(&to_module, file) {
            Some(prefix) => format!("use {prefix}::{};", sym.name),
            None => {
                plan.warnings.push(format!(
                    "{}: it sits outside {} and Cargo.toml gives up no package name, so \
                     this wrote no `use` for '{}'",
                    file.display(),
                    to_module.src.display(),
                    sym.name
                ));
                continue;
            }
        };
        match binding_import(index, file, &sym.name) {
            Some(binding) => {
                repoint_rust_binding(&mut plan.edits, &binding, &sym.name, &statement)?
            }
            None => {
                let target_source = crate::vfs::read_to_string(file).unwrap_or_default();
                let at = rust_use_insertion_point(&target_source);
                plan.edits.add(
                    file.clone(),
                    Edit::new(
                        Span::new(at, at),
                        format!("{statement}\n"),
                        format!("import {} from its new home", sym.name),
                    ),
                );
            }
        }
        plan.imports_added.push(file.clone());
    }

    warn_about_carried_imports(index, sym, destination, removal, &source, &mut plan);
    carry_defined_dependencies(index, sym, destination, removal, &source, &mut plan);
    Ok(plan)
}

/// Where a Rust file sits in its crate.
fn reachable_prefix(to_module: &CrateModule, file: &Path) -> Option<String> {
    if file.starts_with(&to_module.src) {
        return Some(to_module.use_prefix());
    }
    let name = package_name(&to_module.src)?;
    Some(to_module.use_prefix().replacen("crate", &name, 1))
}

/// The package name from the Cargo.toml beside `src`, as a `use` path spells it.
fn package_name(src: &Path) -> Option<String> {
    let text = crate::vfs::read_to_string(src.parent()?.join("Cargo.toml")).ok()?;
    let mut in_package = false;
    for line in text.lines() {
        let line = line.trim();
        if let Some(header) = line.strip_prefix('[') {
            in_package = header.starts_with("package]");
            continue;
        }
        if !in_package {
            continue;
        }
        if let Some(rest) = line.strip_prefix("name") {
            let value = rest.trim_start().strip_prefix('=')?.trim();
            return Some(value.trim_matches('"').replace('-', "_"));
        }
    }
    None
}

fn crate_module(file: &Path) -> Result<CrateModule> {
    let mut src: Option<PathBuf> = None;
    for ancestor in file.ancestors().skip(1) {
        if ancestor.file_name().and_then(|n| n.to_str()) == Some("src") {
            src = Some(ancestor.to_path_buf());
            break;
        }
    }
    let Some(src) = src else {
        // Use `NotHere` here rather than `Unsupported`, because Rust supports moving to a file.
        return Err(Refusal::NotHere {
            operation: "move to file".into(),
            detail: format!(
                "{} is not under a `src/` directory, so its location yields no module \
                 path; move it to a file under `src/` that the module tree already \
                 declares",
                file.display()
            ),
        }
        .into());
    };

    if !crate::vfs::exists(src.join("lib.rs")) && !crate::vfs::exists(src.join("main.rs")) {
        return Err(Refusal::NotHere {
            operation: "move to file".into(),
            detail: format!(
                "{} has neither lib.rs nor main.rs, so there is no crate root to anchor a \
                 `use crate::…` path to",
                src.display()
            ),
        }
        .into());
    }

    let relative = file
        .strip_prefix(&src)
        .map_err(|_| anyhow::anyhow!("{} is not under {}", file.display(), src.display()))?;

    let mut path: Vec<String> = Vec::new();
    for component in relative.components() {
        let part = component
            .as_os_str()
            .to_str()
            .ok_or_else(|| anyhow::anyhow!("non-UTF-8 path component in {}", file.display()))?;
        path.push(part.to_string());
    }
    // The last component names the file.
    if let Some(last) = path.pop() {
        let stem = last.strip_suffix(".rs").unwrap_or(&last).to_string();
        if !matches!(stem.as_str(), "mod" | "lib" | "main") {
            path.push(stem);
        }
    }
    Ok(CrateModule { src, path })
}

fn module_label(module: &CrateModule) -> String {
    if module.path.is_empty() {
        "the crate root".to_string()
    } else {
        module.use_prefix()
    }
}

/// Is every module on the path to `module` declared with a `mod` statement?
fn check_module_is_declared(module: &CrateModule, destination: &Path) -> Result<()> {
    let root = if crate::vfs::exists(module.src.join("lib.rs")) {
        module.src.join("lib.rs")
    } else {
        module.src.join("main.rs")
    };

    let mut parent_file = root;
    let mut walked: Vec<String> = Vec::new();
    for segment in &module.path {
        let source = crate::vfs::read_to_string(&parent_file).unwrap_or_default();
        if !declares_module(&source, segment) {
            return Err(Refusal::Declined {
                detail: format!(
                    "{} does not declare `mod {};`, so {} is not part of the module tree and \
                 a `use` path to it would not compile. Add `mod {};` to {} and the move \
                 goes through",
                    parent_file.display(),
                    segment,
                    destination.display(),
                    segment,
                    parent_file.display()
                ),
            }
            .into());
        }
        walked.push(segment.clone());
        let dir: PathBuf = module.src.join(walked.join("/"));
        let flat = module.src.join(format!("{}.rs", walked.join("/")));
        parent_file = if crate::vfs::exists(&flat) {
            flat
        } else {
            dir.join("mod.rs")
        };
    }
    Ok(())
}

/// Does `source` contain a `mod <name>;` declaration at any nesting?
fn declares_module(source: &str, name: &str) -> bool {
    source.lines().any(|line| {
        let mut rest = line.trim_start();
        if let Some(after) = rest.strip_prefix("pub") {
            rest = after.trim_start();
            if rest.starts_with('(') {
                match rest.find(')') {
                    Some(close) => rest = rest[close + 1..].trim_start(),
                    None => return false,
                }
            }
        }
        let Some(after_mod) = rest.strip_prefix("mod ") else {
            return false;
        };
        after_mod.trim() == format!("{name};")
    })
}

/// The first `#[path]` declaration that changes the logical module represented by
/// `destination`. An unrelated remapped module does not make every conventional module in
/// the crate ambiguous.
fn path_attribute_conflict(index: &Index, src: &Path, destination: &Path) -> Option<PathBuf> {
    let parsers = crate::parse::Parsers::new();
    let mut found: Option<PathBuf> = None;
    for (path, info) in index.files() {
        if info.language != Language::Rust || !path.starts_with(src) {
            continue;
        }
        if found.as_ref().is_some_and(|best| best < path) {
            continue;
        }
        let Ok(text) = crate::vfs::read_to_string(path) else {
            continue;
        };
        // Parsing every file in the crate to answer this would cost more than the move does.
        if !text.contains("#[path") {
            continue;
        }
        let Ok(parsed) = parsers.parse(Language::Rust, &text) else {
            continue;
        };
        if remaps_destination(parsed.root(), &text, path, destination) {
            found = Some(path.clone());
        }
    }
    found
}

fn remaps_destination(
    root: tree_sitter::Node,
    source: &str,
    declaring_file: &Path,
    destination: &Path,
) -> bool {
    let mut stack = vec![root];
    while let Some(node) = stack.pop() {
        if node.kind() == "attribute_item" {
            let written = Span::from(node).text(source);
            let rest = written.trim_start_matches("#[").trim_start();
            if let Some(after) = rest.strip_prefix("path") {
                let value = after
                    .trim_start()
                    .strip_prefix('=')
                    .map(str::trim)
                    .and_then(|value| value.strip_suffix(']'))
                    .map(str::trim)
                    .and_then(|value| value.strip_prefix('"'))
                    .and_then(|value| value.strip_suffix('"'));
                let mut declaration = node.next_named_sibling();
                while declaration.is_some_and(|next| next.kind() == "attribute_item") {
                    declaration = declaration.and_then(|next| next.next_named_sibling());
                }
                if let (Some(relative), Some(declaration)) = (value, declaration) {
                    if declaration.kind() == "mod_item" {
                        let parent = declaring_file.parent().unwrap_or(Path::new(""));
                        let mapped = parent.join(relative);
                        let conventional = declaration
                            .child_by_field_name("name")
                            .map(|name| Span::from(name).text(source))
                            .is_some_and(|name| {
                                destination == parent.join(format!("{name}.rs"))
                                    || destination == parent.join(name).join("mod.rs")
                            });
                        if destination == mapped || conventional {
                            return true;
                        }
                    }
                }
            }
        }
        let mut cursor = node.walk();
        stack.extend(node.children(&mut cursor));
    }
    false
}

/// The import in `file` that binds `name`, described by the spans a rewrite needs.
struct Binding {
    file: PathBuf,
    /// The whole `use …;` statement.
    statement: Span,
    /// The span of `name` inside a `use a::{X, Y};` list, when that is the form.
    in_list: Option<Span>,
    /// How many names the list holds.
    list_len: usize,
    is_glob: bool,
}

fn binding_import(index: &Index, file: &Path, name: &str) -> Option<Binding> {
    let info = index.file(file)?;
    let mut listed: Option<&crate::model::Import> = None;
    for import in &info.imports {
        if import.is_glob {
            continue;
        }
        if import.names.iter().any(|n| n.local == name) {
            listed = Some(import);
            break;
        }
        let tail = import.path.rsplit("::").find(|s| !s.is_empty());
        if import.names.is_empty() && (tail == Some(name) || import.alias.as_deref() == Some(name))
        {
            return Some(Binding {
                file: file.to_path_buf(),
                statement: import.span,
                in_list: None,
                list_len: 0,
                is_glob: false,
            });
        }
    }

    // `use a::{X, Y};` produces one import record per name, and all of them share the statement
    // span.
    let import = listed?;
    let entry = import.names.iter().find(|n| n.local == name)?;
    let list_len = info
        .imports
        .iter()
        .filter(|other| other.span == import.span)
        .map(|other| other.names.len())
        .sum();
    Some(Binding {
        file: file.to_path_buf(),
        statement: import.span,
        in_list: Some(entry.span),
        list_len,
        is_glob: false,
    })
}

/// Point an existing binding at the item's new home.
fn repoint_rust_binding(
    edits: &mut EditSet,
    binding: &Binding,
    name: &str,
    statement: &str,
) -> Result<()> {
    if binding.is_glob {
        return Ok(());
    }
    match binding.in_list {
        // `use a::{X};` and `use a::X;` are both wholly replaceable.
        None => edits.add(
            binding.file.clone(),
            Edit::new(
                binding.statement,
                statement,
                format!("repoint use of {name}"),
            ),
        ),
        Some(_) if binding.list_len == 1 => edits.add(
            binding.file.clone(),
            Edit::new(
                binding.statement,
                statement,
                format!("repoint use of {name}"),
            ),
        ),
        // One of several: take the name out of the list and add a statement beside it.
        Some(span) => {
            let source = crate::vfs::read_to_string(&binding.file)?;
            edits.add(
                binding.file.clone(),
                Edit::new(
                    list_entry_span(&source, span),
                    "",
                    format!("drop {name} from its old import list"),
                ),
            );
            edits.add(
                binding.file.clone(),
                Edit::new(
                    Span::new(binding.statement.end, binding.statement.end),
                    format!("\n{statement}"),
                    format!("import {name} from its new home"),
                ),
            );
        }
    }
    Ok(())
}

/// Remove a binding that the destination file no longer needs, because it is about to
/// define the item itself.
fn drop_rust_binding(
    edits: &mut EditSet,
    binding: &Binding,
    name: &str,
    destination: &Path,
) -> Result<()> {
    let source = crate::vfs::read_to_string(destination).unwrap_or_default();
    match binding.in_list {
        Some(span) if binding.list_len > 1 => edits.add(
            binding.file.clone(),
            Edit::new(
                list_entry_span(&source, span),
                "",
                format!("{name} is defined here now"),
            ),
        ),
        _ => edits.add(
            binding.file.clone(),
            Edit::new(
                whole_lines(&source, binding.statement),
                "",
                format!("{name} is defined here now"),
            ),
        ),
    }
    Ok(())
}

/// A name inside a `use a::{X, Y};` list, plus the comma that joins it to its
/// neighbour, so that removing it leaves a well-formed list.
fn list_entry_span(source: &str, name: Span) -> Span {
    let bytes = source.as_bytes();
    let mut end = name.end;
    while end < bytes.len() && bytes[end] == b' ' {
        end += 1;
    }
    if end < bytes.len() && bytes[end] == b',' {
        end += 1;
        while end < bytes.len() && bytes[end] == b' ' {
            end += 1;
        }
        return Span::new(name.start, end);
    }
    // Last in the list: take the preceding comma instead.
    let mut start = name.start;
    while start > 0 && (bytes[start - 1] == b' ' || bytes[start - 1] == b',') {
        start -= 1;
        if bytes[start] == b',' {
            break;
        }
    }
    Span::new(start, name.end)
}

/// Where a new `use` should go: after the file's header and any existing `use` lines.
fn rust_use_insertion_point(source: &str) -> usize {
    let mut offset = 0;
    let mut point = 0;
    for line in source.split_inclusive('\n') {
        let trimmed = line.trim_start();
        let is_prelude = trimmed.starts_with("//!")
            || trimmed.starts_with("#![")
            || trimmed.starts_with("use ")
            || trimmed.starts_with("pub use ")
            || trimmed.starts_with("extern crate ");
        if is_prelude {
            point = offset + line.len();
        } else if !trimmed.is_empty() {
            break;
        }
        offset += line.len();
    }
    point
}

/// Widen a removal to swallow the attributes and doc comments written directly above
/// the item, which cannot legally stay behind without it.
fn with_rust_attributes(source: &str, span: Span) -> Span {
    let mut start = span.start;
    while start > 0 {
        let previous = full_line_span(source, start - 1);
        let trimmed = previous.text(source).trim_start();
        if trimmed.starts_with("#[") || trimmed.starts_with("///") || trimmed.starts_with("/**") {
            start = previous.start;
        } else {
            break;
        }
    }
    Span::new(start, span.end)
}

// Go: a package is a directory.

fn move_go(index: &Index, sym: &Symbol, destination: &Path) -> Result<MovePlan> {
    if sym.container.is_some() {
        return Err(Refusal::Declined {
            detail: format!(
                "'{}' is nested inside another definition; only a top-level declaration \
             moves",
                sym.name
            ),
        }
        .into());
    }

    let source_dir = sym
        .file
        .parent()
        .ok_or_else(|| anyhow::anyhow!("{} has no directory", sym.file.display()))?;
    let dest_dir = destination
        .parent()
        .ok_or_else(|| anyhow::anyhow!("{} has no directory", destination.display()))?;

    let source = crate::vfs::read_to_string(&sym.file)?;
    let removal = with_go_doc_comment(&source, whole_lines(&source, sym.full_span));
    let moved_text = removal.text(&source).to_string();

    let mut plan = MovePlan::new(sym, destination);
    // The declaration and the imports that leave with it are one hole in the source file.
    let erase = |plan: &mut MovePlan, pruned: Vec<Span>| {
        for span in erase_spans(&source, &[vec![removal], pruned].concat()) {
            plan.edits.add(
                sym.file.clone(),
                Edit::new(span, "", format!("move {} out", sym.name)),
            );
        }
    };

    if source_dir == dest_dir {
        // Same directory means same package: every reference already resolves, and
        // there is nothing whatsoever to update.
        let package = go_package(index, &sym.file).ok_or_else(|| {
            anyhow::anyhow!(
                "{} has no package clause, so the package of the move is unknown",
                sym.file.display()
            )
        })?;
        if let Some(existing) = go_package(index, destination) {
            if existing != package {
                return Err(Refusal::Declined {
                    detail: format!(
                        "{} declares package {} but {} declares package {}; two packages \
                     cannot share a directory",
                        sym.file.display(),
                        package,
                        destination.display(),
                        existing
                    ),
                }
                .into());
            }
        }
        let (carried, pruned) =
            go_carry_imports(index, sym, destination, removal, &source, &mut plan);
        erase(&mut plan, pruned);
        let header = if go_package(index, destination).is_none() {
            format!("package {package}\n\n{}", go_header_imports(&carried))
        } else {
            String::new()
        };
        append_to_destination(
            &mut plan.edits,
            destination,
            &format!("{header}{moved_text}"),
            format!("move {} in", sym.name),
        );
        carry_defined_dependencies(index, sym, destination, removal, &source, &mut plan);
        return Ok(plan);
    }

    // A different directory is a different package.
    if !sym.exported {
        return Err(Refusal::Declined {
            detail: format!(
                "'{}' is unexported, so nothing outside {} can name it; moving it to {} \
             would make it unreachable. Capitalise it first.",
                sym.name,
                crate::vfs::describe_dir(source_dir),
                crate::vfs::describe_dir(dest_dir)
            ),
        }
        .into());
    }

    let Some(package) =
        go_package(index, destination).or_else(|| go_package_of_dir(index, dest_dir))
    else {
        return Err(Refusal::Declined {
            detail: format!(
                "no .go file in {} declares a package, so the qualifier every use site \
             would need is unknown",
                crate::vfs::describe_dir(dest_dir)
            ),
        }
        .into());
    };
    let import_path = go_import_path(dest_dir).ok_or_else(|| {
        anyhow::anyhow!(
            "no go.mod above {}, so nothing yields the import path of package {}",
            crate::vfs::describe_dir(dest_dir),
            package
        )
    })?;

    let outside: Vec<&crate::model::Reference> = index
        .references_to(sym.id)
        .into_iter()
        .filter(|r| !(r.file == sym.file && removal.contains(r.span)))
        .collect();

    let stray: Vec<&&crate::model::Reference> = outside
        .iter()
        .filter(|r| r.file.parent() != Some(source_dir))
        .collect();
    if !stray.is_empty() {
        let mut message = format!(
            "{1} file(s) outside package {2} use '{0}'",
            sym.name,
            stray.len(),
            crate::vfs::describe_dir(source_dir)
        );
        for reference in &stray {
            message.push_str(&format!(
                "\n  {}",
                location(&reference.file, reference.span.start)
            ));
        }
        message.push_str(
            "\nNames alone cannot settle a requalified use; \
             this changed nothing.",
        );
        return Err(Refusal::Declined { detail: message }.into());
    }

    // The moved body may reach back to what the source package keeps: a bare `Shared()` moved
    // into another package names nothing there.
    let source_package = go_package(index, &sym.file).ok_or_else(|| {
        anyhow::anyhow!(
            "{} has no package clause, so nothing can qualify what the \
             moved code leaves behind.",
            sym.file.display()
        )
    })?;
    let (moved_text, reaches_back) = go_qualify_back_references(
        index,
        sym,
        removal,
        moved_text,
        &source_package,
        &mut plan.warnings,
    )?;
    let source_import = match reaches_back {
        true => {
            let path = go_import_path(source_dir).ok_or_else(|| {
                anyhow::anyhow!(
                    "no go.mod above {}, so the moved code cannot import what it \
                     left behind",
                    crate::vfs::describe_dir(source_dir)
                )
            })?;
            if go_package_imports(
                index,
                source_dir,
                &go_import_path(dest_dir).unwrap_or_default(),
            ) {
                return Err(Refusal::Declined {
                    detail: format!(
                        "moving '{}' to {} would make packages {} and {} import each \
                     other: the moved code reaches back into \"{}\", and {} already \
                     imports the destination. Go does not allow an import cycle.",
                        sym.name,
                        crate::vfs::describe_dir(dest_dir),
                        crate::vfs::describe_dir(source_dir),
                        crate::vfs::describe_dir(dest_dir),
                        path,
                        crate::vfs::describe_dir(source_dir)
                    ),
                }
                .into());
            }
            Some(path)
        }
        false => None,
    };

    let (carried, pruned) = go_carry_imports(index, sym, destination, removal, &source, &mut plan);
    erase(&mut plan, pruned);
    let destination_exists = go_package(index, destination).is_some();
    let header = match (destination_exists, &source_import) {
        (false, Some(path)) => format!(
            "package {package}\n\nimport \"{path}\"\n\n{}",
            go_header_imports(&carried)
        ),
        (false, None) => format!("package {package}\n\n{}", go_header_imports(&carried)),
        (true, _) => String::new(),
    };
    if let (true, Some(path)) = (destination_exists, &source_import) {
        let existing = crate::vfs::read_to_string(destination).unwrap_or_default();
        if !existing.contains(&format!("\"{path}\"")) {
            let at = go_import_insertion_point(index, destination).ok_or_else(|| {
                anyhow::anyhow!(
                    "{} has no package clause, so an import has nowhere to go in it",
                    destination.display()
                )
            })?;
            plan.edits.add(
                destination.to_path_buf(),
                Edit::new(
                    Span::new(at, at),
                    format!("\nimport \"{path}\"\n"),
                    format!("import what {} left behind", sym.name),
                ),
            );
        }
    }
    append_to_destination(
        &mut plan.edits,
        destination,
        &format!("{header}{moved_text}"),
        format!("move {} in", sym.name),
    );

    let mut needs_import: BTreeSet<PathBuf> = BTreeSet::new();
    for reference in &outside {
        if !reference.confidence.is_safe_to_rewrite() {
            plan.warnings.push(format!(
                "{}: '{}' resolves only '{}' here, so this left it unqualified",
                location(&reference.file, reference.span.start),
                sym.name,
                reference.confidence.as_str()
            ));
            continue;
        }
        plan.edits.add(
            reference.file.clone(),
            Edit::new(
                Span::new(reference.span.start, reference.span.start),
                format!("{package}."),
                format!("qualify {} with its new package", sym.name),
            ),
        );
        needs_import.insert(reference.file.clone());
    }

    // The source package would import the destination, and the destination already imports the
    // source.
    if !needs_import.is_empty() {
        if let Some(source_path) = go_import_path(source_dir) {
            if go_package_imports(index, dest_dir, &source_path) {
                return Err(Refusal::Declined {
                    detail: format!(
                        "moving '{}' to {} would make packages {} and {} import each other: \
                     {} already imports \"{}\", and moving '{}' makes \"{}\" import back. \
                     Go does not allow an import cycle. Move what '{}' uses as well, or \
                     move it to a package neither imports.",
                        sym.name,
                        crate::vfs::describe_dir(dest_dir),
                        crate::vfs::describe_dir(source_dir),
                        crate::vfs::describe_dir(dest_dir),
                        crate::vfs::describe_dir(dest_dir),
                        source_path,
                        sym.name,
                        source_path,
                        sym.name
                    ),
                }
                .into());
            }
        }
    }

    for file in &needs_import {
        let target_source = crate::vfs::read_to_string(file).unwrap_or_default();
        if target_source.contains(&format!("\"{import_path}\"")) {
            continue;
        }
        let at = go_import_insertion_point(index, file).ok_or_else(|| {
            anyhow::anyhow!(
                "{} has no package clause, so an import has nowhere to go in it",
                file.display()
            )
        })?;
        plan.edits.add(
            file.clone(),
            Edit::new(
                Span::new(at, at),
                format!("\nimport \"{import_path}\"\n"),
                format!("import package {package}"),
            ),
        );
        plan.imports_added.push(file.clone());
    }

    Ok(plan)
}

/// Qualify what the moved Go body still reads from the package it is leaving.
fn go_qualify_back_references(
    index: &Index,
    sym: &Symbol,
    removal: Span,
    moved_text: String,
    package: &str,
    warnings: &mut Vec<String>,
) -> Result<(String, bool)> {
    let Some(info) = index.file(&sym.file) else {
        return Ok((moved_text, false));
    };
    let kept: BTreeMap<crate::model::SymbolId, &Symbol> = info
        .symbols
        .iter()
        .filter_map(|id| index.symbol(*id))
        .filter(|s| s.id != sym.id && s.is_top_level() && !removal.contains(s.name_span))
        .map(|s| (s.id, s))
        .collect();

    let mut offsets: Vec<usize> = Vec::new();
    let mut qualified: BTreeSet<String> = BTreeSet::new();
    for reference in info.references.iter().map(|i| &index.references[*i]) {
        if !removal.contains(reference.span) || reference.receiver.is_some() {
            continue;
        }
        let Some(target) = reference.target.and_then(|id| kept.get(&id)) else {
            continue;
        };
        if !target.exported {
            return Err(Refusal::Declined {
                detail: format!(
                    "the moved code uses `{}`, which package {} does not export; a \
                 qualified `{}.{}` would not compile. Capitalise it or move it too.",
                    target.name, package, package, target.name
                ),
            }
            .into());
        }
        offsets.push(reference.span.start - removal.start);
        qualified.insert(target.name.clone());
    }

    let source_text = crate::vfs::read_to_string(&sym.file)?;
    if let Ok(used) = names_used_in(sym.language, &source_text, removal) {
        let unhandled: Vec<&str> = kept
            .values()
            .filter(|s| used.contains(&s.name) && !qualified.contains(&s.name))
            .map(|s| s.name.as_str())
            .collect();
        if !unhandled.is_empty() {
            warnings.push(format!(
                "the moved code may use {} from the package it left, and those \
                 mentions did not resolve firmly enough to qualify; check them by hand.",
                unhandled.join(", ")
            ));
        }
    }

    if offsets.is_empty() {
        return Ok((moved_text, false));
    }
    offsets.sort_unstable();
    offsets.dedup();
    let mut text = moved_text;
    for at in offsets.into_iter().rev() {
        text.insert_str(at, &format!("{package}."));
    }
    Ok((text, true))
}

/// Whether any file in `dir` imports `import_path`.
fn go_package_imports(index: &Index, dir: &Path, import_path: &str) -> bool {
    index
        .files()
        .filter(|(path, _)| path.parent() == Some(dir))
        .any(|(_, info)| info.imports.iter().any(|import| import.path == import_path))
}

/// The package a Go file declares.
fn go_package(index: &Index, file: &Path) -> Option<String> {
    let info = index.file(file)?;
    info.symbols
        .iter()
        .filter_map(|id| index.symbol(*id))
        .find(|s| s.kind == SymbolKind::Module && s.language == Language::Go)
        .map(|s| s.name.clone())
}

/// The package declared by the .go files of a directory.
fn go_package_of_dir(index: &Index, dir: &Path) -> Option<String> {
    index
        .files()
        .filter(|(path, info)| info.language == Language::Go && path.parent() == Some(dir))
        .find_map(|(path, _)| go_package(index, path))
}

/// The import path of `dir`, derived from the nearest go.mod above it.
fn go_import_path(dir: &Path) -> Option<String> {
    for ancestor in dir.ancestors() {
        let manifest = ancestor.join("go.mod");
        let Ok(text) = crate::vfs::read_to_string(&manifest) else {
            continue;
        };
        let module = text.lines().find_map(|line| {
            line.trim_start()
                .strip_prefix("module ")
                .map(|rest| rest.trim().to_string())
        })?;
        let relative = dir.strip_prefix(ancestor).ok()?;
        let mut parts = vec![module];
        for component in relative.components() {
            parts.push(component.as_os_str().to_str()?.to_string());
        }
        return Some(parts.join("/"));
    }
    None
}

/// Just after the package clause, where an extra `import` declaration is always legal.
fn go_import_insertion_point(index: &Index, file: &Path) -> Option<usize> {
    let info = index.file(file)?;
    let clause = info
        .symbols
        .iter()
        .filter_map(|id| index.symbol(*id))
        .find(|s| s.kind == SymbolKind::Module && s.language == Language::Go)?;
    let source = crate::vfs::read_to_string(file).ok()?;
    Some(full_line_span(&source, clause.full_span.start).end)
}

/// Carry the imports the moved Go code needs, and drop the ones that left with it.
#[must_use]
fn go_carry_imports(
    index: &Index,
    sym: &Symbol,
    destination: &Path,
    removal: Span,
    source: &str,
    plan: &mut MovePlan,
) -> (String, Vec<Span>) {
    let Some(info) = index.file(&sym.file) else {
        return (String::new(), Vec::new());
    };
    let existing = crate::vfs::read_to_string(destination).unwrap_or_default();
    let mut for_the_header = String::new();
    let mut pruned: Vec<Span> = Vec::new();

    for import in &info.imports {
        let Some(binding) = go_import_binding(import) else {
            continue;
        };
        let mut references = info
            .references
            .iter()
            .map(|i| &index.references[*i])
            .filter(|r| r.name == binding && !import.span.contains(r.span));
        let (mut moved, mut stayed) = (false, false);
        for reference in &mut references {
            match removal.contains(reference.span) {
                true => moved = true,
                false => stayed = true,
            }
        }
        if !moved {
            continue;
        }

        // The destination may already import it, under this path or any other spelling of the
        // same one.
        let already_there = index
            .file(destination)
            .is_some_and(|d| d.imports.iter().any(|i| i.path == import.path))
            || existing.contains(&format!("\"{}\"", import.path));
        if !already_there {
            let at = go_import_insertion_point(index, destination);
            let statement = match &import.alias {
                Some(alias) => format!("\nimport {alias} \"{}\"\n", import.path),
                None => format!("\nimport \"{}\"\n", import.path),
            };
            match at {
                Some(at) => {
                    plan.edits.add(
                        destination.to_path_buf(),
                        Edit::new(
                            Span::new(at, at),
                            statement,
                            format!("import what {} uses", sym.name),
                        ),
                    );
                    plan.imports_added.push(destination.to_path_buf());
                }
                // A destination with no package clause yet takes a whole file from the
                // caller, which puts the clause and the imports in together.
                None => {
                    for_the_header.push_str(statement.trim_start_matches('\n'));
                    plan.imports_added.push(destination.to_path_buf());
                }
            }
        }

        if !stayed {
            pruned.push(full_line_span(source, import.span.start));
        }
    }
    (for_the_header, pruned)
}

/// The carried imports as they go into a header, with the blank line that follows them.
fn go_header_imports(carried: &str) -> String {
    match carried.is_empty() {
        true => String::new(),
        false => format!("{carried}\n"),
    }
}

/// The name a Go import binds: its alias, or the package the path names.
fn go_import_binding(import: &crate::model::Import) -> Option<String> {
    // `import _ "embed"` binds nothing on purpose and is there for the side effect, so
    // nothing the moved code reads can have come through it.
    match import.alias.as_deref() {
        Some("_") | Some(".") => None,
        Some(alias) => Some(alias.to_string()),
        None => crate::refactor::imports::implicit_binding(&import.path, Language::Go),
    }
}

/// Widen a removal to swallow the `//` doc comment written directly above.
fn with_go_doc_comment(source: &str, span: Span) -> Span {
    let mut start = span.start;
    while start > 0 {
        let previous = full_line_span(source, start - 1);
        if previous.text(source).trim_start().starts_with("//") {
            start = previous.start;
        } else {
            break;
        }
    }
    Span::new(start, span.end)
}

// HCL / Terraform: a module is a directory.

fn move_hcl(index: &Index, sym: &Symbol, destination: &Path) -> Result<MovePlan> {
    let source_dir = sym.file.parent();
    if source_dir != destination.parent() {
        // Terraform moves within a directory; what this refuses is the pair of
        // directories, which is not a property of the language.
        return Err(Refusal::NotHere {
            operation: "move to file".into(),
            detail: format!(
                "Terraform's module is the directory, so moving '{}' from {} to {} changes \
                 its module. Every address that names it, and its state address, would \
                 break; `moved` blocks or `terraform state mv` are the tools for that",
                sym.name,
                sym.file.display(),
                destination.display()
            ),
        }
        .into());
    }

    let source_ext = sym.file.extension().and_then(|e| e.to_str()).unwrap_or("");
    let dest_ext = destination
        .extension()
        .and_then(|e| e.to_str())
        .unwrap_or("");
    if source_ext != dest_ext {
        return Err(Refusal::Declined {
            detail: format!(
                "{} and {} are different kinds of Terraform file (.{source_ext} and \
             .{dest_ext}); Terraform loads them by different rules",
                sym.file.display(),
                destination.display()
            ),
        }
        .into());
    }
    if sym.kind == SymbolKind::Key {
        return Err(Refusal::Declined {
            detail: format!(
                "'{}' is a value in a .tfvars file, not a declaration; which values file \
             Terraform loads follows from its name and the command line, so moving it \
             between files decides whether it applies at all",
                sym.name
            ),
        }
        .into());
    }

    let source = crate::vfs::read_to_string(&sym.file)?;
    let enclosing_locals = enclosing_locals_block(index, sym);

    if sym.container.is_some() && enclosing_locals.is_none() {
        return Err(Refusal::Declined {
            detail: format!(
                "'{}' is an argument of an enclosing block, not a declaration of its own; \
             only a whole block or a `locals` entry moves between files",
                sym.name
            ),
        }
        .into());
    }

    let removal = whole_lines(&source, sym.full_span);
    let moved_text = removal.text(&source).to_string();

    let mut plan = MovePlan::new(sym, destination);
    plan.edits.add(
        sym.file.clone(),
        Edit::new(
            removal_with_separator(&source, removal),
            "",
            format!("move {} out", sym.name),
        ),
    );

    match enclosing_locals {
        // A `locals` entry only means anything inside a `locals` block, so it goes into
        // the destination's block, or into one made for it.
        Some(_) => {
            let dest_source = crate::vfs::read_to_string(destination).unwrap_or_default();
            match locals_block_in(index, destination) {
                Some(block) => {
                    let close = dest_source[..block.end].rfind('}').ok_or_else(|| {
                        anyhow::anyhow!("malformed locals block in {}", destination.display())
                    })?;
                    let at = full_line_span(&dest_source, close).start;
                    plan.edits.add(
                        destination.to_path_buf(),
                        Edit::new(
                            Span::new(at, at),
                            moved_text.clone(),
                            format!("move {} in", sym.name),
                        ),
                    );
                }
                None => append_to_destination(
                    &mut plan.edits,
                    destination,
                    &format!("locals {{\n{moved_text}}}\n"),
                    format!("move {} in", sym.name),
                ),
            }
        }
        None => append_to_destination(
            &mut plan.edits,
            destination,
            &moved_text,
            format!("move {} in", sym.name),
        ),
    }

    Ok(plan)
}

/// The `locals` block a definition sits inside, if it is a `locals` entry.
fn enclosing_locals_block<'a>(index: &'a Index, sym: &Symbol) -> Option<&'a Symbol> {
    let container = index.symbol(sym.container?)?;
    (container.name == "locals" && container.kind == SymbolKind::Block).then_some(container)
}

/// The span of a `locals` block in `file`, if it has one.
fn locals_block_in(index: &Index, file: &Path) -> Option<Span> {
    let info = index.file(file)?;
    info.symbols
        .iter()
        .filter_map(|id| index.symbol(*id))
        .filter(|s| s.kind == SymbolKind::Block && s.name == "locals")
        .map(|s| s.full_span)
        .next_back()
}

// CSS: names are global; reachability is what breaks.

fn move_css(index: &Index, sym: &Symbol, destination: &Path) -> Result<MovePlan> {
    if sym.kind == SymbolKind::Property {
        return Err(Refusal::Declined {
            detail: format!(
                "'{}' is a custom property declared inside a rule, not a rule; a declaration \
             on its own is not valid at the top level of a stylesheet",
                sym.name
            ),
        }
        .into());
    }

    let source = crate::vfs::read_to_string(&sym.file)?;
    let rule = widen_to_rule(&source, sym)?;
    let removal = whole_lines(&source, rule);
    let moved_text = removal.text(&source).to_string();

    let mut plan = MovePlan::new(sym, destination);
    plan.edits.add(
        sym.file.clone(),
        Edit::new(
            removal_with_separator(&source, removal),
            "",
            format!("move the {} rule out", sym.name),
        ),
    );
    append_to_destination(
        &mut plan.edits,
        destination,
        &moved_text,
        format!("move the {} rule in", sym.name),
    );

    // Nothing to repoint: a CSS name is global.
    if !imports_reach(index, &sym.file, destination) {
        plan.warnings.push(format!(
            "{} does not reach {} through any @import, so the rules moved there will \
             stop applying wherever {} was loaded. Add an @import, or move the rule to \
             a stylesheet that is already loaded.",
            sym.file.display(),
            destination.display(),
            sym.file.display()
        ));
    }

    Ok(plan)
}

/// Widen a selector to the rule it heads.
fn widen_to_rule(source: &str, sym: &Symbol) -> Result<Span> {
    let parsed = crate::parse::Parsers::new().parse(sym.language, source)?;
    let Some(node) = parsed
        .root()
        .descendant_for_byte_range(sym.full_span.start, sym.full_span.end)
    else {
        return Err(Refusal::Declined {
            detail: format!(
                "cannot locate '{}' in {} after reparsing it",
                sym.name,
                sym.file.display()
            ),
        }
        .into());
    };

    let mut rule = node;
    loop {
        if matches!(rule.kind(), "rule_set" | "keyframes_statement") {
            break;
        }
        let Some(parent) = rule.parent() else {
            return Err(Refusal::Declined {
                detail: format!(
                    "'{}' is not part of a rule, so there is nothing to move",
                    sym.name
                ),
            }
            .into());
        };
        rule = parent;
    }

    if rule.parent().map(|p| p.kind()) != Some("stylesheet") {
        return Err(Refusal::Declined {
            detail: format!(
                "the rule for '{}' is nested inside a {}; moving it out of that context \
             would change when it applies",
                sym.name,
                rule.parent().map(|p| p.kind()).unwrap_or("block")
            ),
        }
        .into());
    }

    if rule.kind() == "rule_set" {
        let mut cursor = rule.walk();
        let selectors = rule
            .named_children(&mut cursor)
            .find(|c| c.kind() == "selectors");
        if let Some(selectors) = selectors {
            let mut inner = selectors.walk();
            let count = selectors
                .named_children(&mut inner)
                .filter(|c| !c.kind().contains("comment"))
                .count();
            if count > 1 {
                return Err(Refusal::Declined {
                    detail: format!(
                        "the rule for '{}' has {} selectors; moving one of them would have \
                     to duplicate the declaration block, which is a rewrite and not \
                     a move",
                        sym.name, count
                    ),
                }
                .into());
            }
        }
    }

    Ok(Span::from(rule))
}

/// Is `target` reachable from `origin` by following `@import`s?
fn imports_reach(index: &Index, origin: &Path, target: &Path) -> bool {
    let mut seen: HashSet<PathBuf> = HashSet::new();
    let mut queue = vec![origin.to_path_buf()];
    while let Some(file) = queue.pop() {
        if !seen.insert(file.clone()) {
            continue;
        }
        let Some(info) = index.file(&file) else {
            continue;
        };
        for import in &info.imports {
            let Some(dir) = file.parent() else { continue };
            let base = dir.join(import.path.trim_start_matches("./"));
            for candidate in [
                base.clone(),
                base.with_extension("css"),
                base.with_extension("scss"),
            ] {
                if candidate == target {
                    return true;
                }
                if index.file(&candidate).is_some() {
                    queue.push(candidate);
                }
            }
        }
    }
    false
}

// Markdown: a section is a heading and everything under it.

fn move_markdown(index: &Index, sym: &Symbol, destination: &Path) -> Result<MovePlan> {
    if sym.kind != SymbolKind::Heading {
        return Err(Refusal::Declined {
            detail: format!(
                "'{}' is {}, not a heading; a Markdown move takes a section, which is a \
             heading and the content under it",
                sym.name,
                sym.kind.with_article()
            ),
        }
        .into());
    }

    let source = crate::vfs::read_to_string(&sym.file)?;
    let headings = file_headings(index, &sym.file);
    let removal = section_span(&source, sym, &headings);

    // A link reference definition names a destination for the whole document, so one sitting
    // inside the last section is not part of that section.
    let definitions = link_definitions_within(index, &sym.file, &source, removal);
    let taken = spans_between(removal, &definitions);
    let mut moved_text: String = taken.iter().map(|span| span.text(&source)).collect();

    // Every anchor that travelled with the section, so this can repoint links to it.
    let moved_slugs: HashSet<String> = headings
        .iter()
        .filter(|h| removal.contains(h.full_span))
        .map(|h| slug(&h.name))
        .collect();
    let staying_slugs: HashSet<String> = headings
        .iter()
        .filter(|h| !removal.contains(h.full_span))
        .map(|h| slug(&h.name))
        .collect();

    let mut plan = MovePlan::new(sym, destination);

    // This copies a definition the moved text uses, so the section still reads as written.
    let (copied, left) = split_by_use(index, &definitions, &taken, &sym.file);
    for definition in &definitions {
        if copied.contains(&definition.name) {
            moved_text.push_str(definition.lines.text(&source));
        }
    }
    if !copied.is_empty() {
        plan.warnings.push(format!(
            "copied the link reference definition(s) {} into {}; the original stays in {}",
            copied.join(", "),
            destination.display(),
            sym.file.display()
        ));
    }
    if !left.is_empty() {
        plan.warnings.push(format!(
            "left the link reference definition(s) {} in {}; a definition serves the \
             whole document, not the section it sits under",
            left.join(", "),
            sym.file.display()
        ));
    }

    for span in &taken {
        plan.edits.add(
            sym.file.clone(),
            Edit::new(*span, "", format!("move the {} section out", sym.name)),
        );
    }
    append_to_destination(
        &mut plan.edits,
        destination,
        &moved_text,
        format!("move the {} section in", sym.name),
    );

    // Same-document anchors in the file the section left: they now point at nothing.
    let Some(from_dir) = sym.file.parent() else {
        return Err(Refusal::Declined {
            detail: format!("{} has no directory", sym.file.display()),
        }
        .into());
    };
    let Some(link) = relative_link(from_dir, destination) else {
        return Err(Refusal::Declined {
            detail: format!(
                "cannot express {} relative to {}",
                destination.display(),
                crate::vfs::describe_dir(from_dir)
            ),
        }
        .into());
    };

    // Read the destinations from the text and not from the index: a resolved reference spans
    // the fragment alone.
    if let Ok(text) = crate::vfs::read_to_string(&sym.file) {
        for span in link_destinations(&text) {
            let Some(anchor) = span.text(&text).strip_prefix('#') else {
                continue;
            };
            if taken.iter().any(|piece| piece.contains(span)) {
                // It travels with the section.
                if staying_slugs.contains(anchor) {
                    plan.warnings.push(format!(
                        "the moved section links to #{anchor}, which stays in {}; that \
                         link will not resolve from {}",
                        sym.file.display(),
                        destination.display()
                    ));
                }
                continue;
            }
            if !moved_slugs.contains(anchor) {
                continue;
            }
            plan.edits.add(
                sym.file.clone(),
                Edit::new(
                    span,
                    format!("{link}#{anchor}"),
                    format!("#{anchor} lives in {} now", destination.display()),
                ),
            );
        }
    }

    // Cross-document links written as `path/to/doc.md#anchor` elsewhere in the repo.
    let mut updated: BTreeSet<PathBuf> = BTreeSet::new();
    for (path, info) in index.files() {
        if info.language != Language::Markdown || path == &sym.file {
            continue;
        }
        let Ok(text) = crate::vfs::read_to_string(path) else {
            continue;
        };
        let Some(dir) = path.parent() else { continue };
        for span in link_destinations(&text) {
            let destination_text = span.text(&text);
            let Some((target, anchor)) = destination_text.rsplit_once('#') else {
                continue;
            };
            if target.is_empty() || !moved_slugs.contains(anchor) {
                continue;
            }
            if crate::vfs::normalise(dir.join(target)) != crate::vfs::normalise(&sym.file) {
                continue;
            }
            let Some(new_link) = relative_link(dir, destination) else {
                continue;
            };
            plan.edits.add(
                path.clone(),
                Edit::new(
                    span,
                    format!("{new_link}#{anchor}"),
                    format!("#{anchor} lives in {} now", destination.display()),
                ),
            );
            updated.insert(path.clone());
        }
    }
    plan.imports_added.extend(updated);

    Ok(plan)
}

/// A link reference definition and the whole lines it occupies.
struct LinkDefinition {
    id: SymbolId,
    name: String,
    lines: Span,
}

/// Every link reference definition whose text falls inside `region`, in source order.
fn link_definitions_within(
    index: &Index,
    file: &Path,
    source: &str,
    region: Span,
) -> Vec<LinkDefinition> {
    let Some(info) = index.file(file) else {
        return Vec::new();
    };
    let mut found: Vec<LinkDefinition> = info
        .symbols
        .iter()
        .filter_map(|id| index.symbol(*id))
        .filter(|s| s.kind == SymbolKind::LinkDef && region.contains(s.full_span))
        .map(|s| {
            let start = full_line_span(source, s.full_span.start).start;
            let last = s.full_span.end.saturating_sub(1).max(s.full_span.start);
            let end = full_line_span(source, last).end;
            LinkDefinition {
                id: s.id,
                name: s.name.clone(),
                lines: Span::new(start, end),
            }
        })
        .collect();
    found.sort_by_key(|d| d.lines.start);
    found
}

/// `region` with each definition's lines cut out of it, in source order.
fn spans_between(region: Span, definitions: &[LinkDefinition]) -> Vec<Span> {
    let mut out = Vec::new();
    let mut cursor = region.start;
    for definition in definitions {
        if definition.lines.start > cursor {
            out.push(Span::new(cursor, definition.lines.start));
        }
        cursor = cursor.max(definition.lines.end);
    }
    if cursor < region.end {
        out.push(Span::new(cursor, region.end));
    }
    out
}

/// Which definitions the moved text uses, and which it only sat above.
fn split_by_use(
    index: &Index,
    definitions: &[LinkDefinition],
    taken: &[Span],
    file: &Path,
) -> (Vec<String>, Vec<String>) {
    let mut copied = Vec::new();
    let mut left = Vec::new();
    for definition in definitions {
        let used = index.references_to(definition.id).iter().any(|reference| {
            reference.file == file && taken.iter().any(|piece| piece.contains(reference.span))
        });
        if used {
            copied.push(definition.name.clone());
        } else {
            left.push(definition.name.clone());
        }
    }
    (copied, left)
}

/// Every heading in a file, in source order.
fn file_headings<'a>(index: &'a Index, file: &Path) -> Vec<&'a Symbol> {
    let Some(info) = index.file(file) else {
        return Vec::new();
    };
    let mut headings: Vec<&Symbol> = info
        .symbols
        .iter()
        .filter_map(|id| index.symbol(*id))
        .filter(|s| s.kind == SymbolKind::Heading)
        .collect();
    headings.sort_by_key(|s| s.full_span.start);
    headings
}

/// A heading and the content under it, up to the next heading of the same or higher
/// level, which a reader means by "this section".
fn section_span(source: &str, heading: &Symbol, headings: &[&Symbol]) -> Span {
    let level = heading_level(source, heading);
    let start = full_line_span(source, heading.full_span.start).start;
    let mut end = source.len();
    for other in headings {
        if other.full_span.start <= heading.full_span.start {
            continue;
        }
        if heading_level(source, other) <= level {
            end = full_line_span(source, other.full_span.start).start;
            break;
        }
    }
    Span::new(start, end.max(heading.full_span.end))
}

/// 1 for `#` and for a `===` underline, 2 for `##` and `---`, and so on.
fn heading_level(source: &str, heading: &Symbol) -> usize {
    let text = heading.full_span.text(source);
    let hashes = text.trim_start().chars().take_while(|c| *c == '#').count();
    if hashes > 0 {
        return hashes;
    }
    match text.lines().nth(1).map(|l| l.trim_start().starts_with('=')) {
        Some(true) => 1,
        _ => 2,
    }
}

/// Every `link_destination` in a Markdown document.
fn link_destinations(source: &str) -> Vec<Span> {
    let Ok(parsed) = crate::parse::Parsers::new().parse(Language::Markdown, source) else {
        return Vec::new();
    };
    let mut out = Vec::new();
    // An inline link's destination lives in an inline sub-tree; only the destination
    // of a link reference definition is in the block tree.
    let mut stack: Vec<_> = parsed.roots().collect();
    while let Some(node) = stack.pop() {
        if node.kind() == "link_destination" {
            out.push(Span::from(node));
        }
        for i in (0..node.child_count()).rev() {
            if let Some(child) = node.child(i) {
                stack.push(child);
            }
        }
    }
    out.sort();
    out
}

/// A path for `to` as a Markdown link would write it from `from_dir`.
fn relative_link(from_dir: &Path, to: &Path) -> Option<String> {
    let mut ups = 0;
    let mut probe = from_dir;
    loop {
        if let Ok(rest) = to.strip_prefix(probe) {
            let mut parts: Vec<String> = vec!["..".to_string(); ups];
            for component in rest.components() {
                parts.push(component.as_os_str().to_str()?.to_string());
            }
            return Some(parts.join("/"));
        }
        probe = probe.parent()?;
        ups += 1;
        if ups > 16 {
            return None;
        }
    }
}

// Zig: a file is a namespace, reached through `@import`.

fn move_zig(index: &Index, sym: &Symbol, destination: &Path) -> Result<MovePlan> {
    if sym.container.is_some() {
        return Err(Refusal::Declined {
            detail: format!(
                "'{}' is nested inside another declaration; only a top-level declaration \
             moves",
                sym.name
            ),
        }
        .into());
    }
    if let Some(existing) = zig_top_level(index, destination)
        .into_iter()
        .find(|s| s.name == sym.name)
    {
        return Err(Refusal::NameCollision {
            existing: existing.name.clone(),
            file: destination.to_path_buf(),
        }
        .into());
    }

    let source = crate::vfs::read_to_string(&sym.file)?;
    // A `///` doc comment is `//`-prefixed, so the Go widening reads it too.
    let removal = with_go_doc_comment(&source, whole_lines(&source, sym.full_span));
    let moved_text = removal.text(&source).to_string();

    let outside: Vec<&crate::model::Reference> = index
        .references_to(sym.id)
        .into_iter()
        .filter(|r| !(r.file == sym.file && removal.contains(r.span)))
        .collect();

    // Zig's `pub` makes a declaration visible through an `@import`.
    if !sym.exported {
        let stranded = outside.iter().filter(|r| r.file != *destination).count();
        if stranded > 0 {
            return Err(Refusal::Declined {
                detail: format!(
                    "'{}' is not `pub`, so only {} can name it; moving it to {} would put it \
                 out of reach of {} use site(s). Mark it `pub` first.",
                    sym.name,
                    sym.file.display(),
                    destination.display(),
                    stranded
                ),
            }
            .into());
        }
    }

    let mut plan = MovePlan::new(sym, destination);
    plan.edits.add(
        sym.file.clone(),
        Edit::new(
            removal_with_separator(&source, removal),
            "",
            format!("move {} out", sym.name),
        ),
    );
    append_to_destination(
        &mut plan.edits,
        destination,
        &moved_text,
        format!("move {} in", sym.name),
    );

    // The destination may already have been calling it through the file it is leaving:
    // `holder.width(…)`.
    if let Some(namespace) = zig_import_binding(index, destination, &sym.file) {
        let text = crate::vfs::read_to_string(destination)?;
        let parsed = crate::parse::Parsers::new().parse(Language::Zig, &text)?;
        for reference in outside.iter().filter(|r| r.file == *destination) {
            let Some(qualifier) = zig_qualifier_span(&parsed, &text, reference.span, &namespace)
            else {
                continue;
            };
            plan.edits.add(
                destination.to_path_buf(),
                Edit::new(
                    qualifier,
                    "",
                    format!("`{}` is declared here now", sym.name),
                ),
            );
        }
    }

    let mut by_file: BTreeMap<PathBuf, Vec<&crate::model::Reference>> = BTreeMap::new();
    for reference in &outside {
        if reference.file == *destination {
            continue;
        }
        by_file
            .entry(reference.file.clone())
            .or_default()
            .push(reference);
    }

    for (file, references) in &by_file {
        let text = crate::vfs::read_to_string(file)?;
        let parsed = crate::parse::Parsers::new().parse(Language::Zig, &text)?;

        // Whatever this file already calls the destination, or what it would have to
        // start calling it.
        let existing = zig_import_binding(index, file, destination);
        let namespace = match &existing {
            Some(local) => local.clone(),
            None => {
                let Some(path) = zig_import_path(file, destination) else {
                    return Err(Refusal::NotHere {
                        operation: "move to file".into(),
                        detail: format!(
                            "{} would have to reach {} through a relative path that climbs \
                             above its own directory. Zig refuses an `@import` that leaves \
                             the module root, and the two paths do not say where that \
                             root sits, so nothing can spell an import for it",
                            file.display(),
                            destination.display()
                        ),
                    }
                    .into());
                };
                let local = zig_namespace_name(destination)?;
                if let Some(clash) = zig_top_level(index, file)
                    .into_iter()
                    .find(|s| s.name == local)
                {
                    return Err(Refusal::NameCollision {
                        existing: clash.name.clone(),
                        file: file.clone(),
                    }
                    .into());
                }
                let at = zig_import_insertion_point(&text);
                plan.edits.add(
                    file.clone(),
                    Edit::new(
                        Span::new(at, at),
                        format!("const {local} = @import(\"{path}\");\n"),
                        format!("import {} from its new home", sym.name),
                    ),
                );
                plan.imports_added.push(file.clone());
                local
            }
        };

        let mut repointed: Vec<Span> = Vec::new();
        for reference in references {
            match zig_qualifier(&parsed, reference.span) {
                // `other.thing`, the namespace the call went through, has to change.
                Some(object) => {
                    let qualifier = Span::from(object).text(&text);
                    let names_source = zig_import_binding_target(index, file, qualifier).as_deref()
                        == Some(&*sym.file);
                    if !names_source {
                        plan.warnings.push(format!(
                            "{}: `{qualifier}.{}` does not come through an `@import` of {}, \
                             so this left it alone",
                            location(file, reference.span.start),
                            sym.name,
                            sym.file.display()
                        ));
                        continue;
                    }
                    plan.edits.add(
                        file.clone(),
                        Edit::new(
                            Span::from(object),
                            namespace.clone(),
                            format!("{} lives in {} now", sym.name, destination.display()),
                        ),
                    );
                    repointed.push(Span::from(object));
                }
                // A bare `thing` only resolves inside the file that declares it.
                None if *file == sym.file => plan.edits.add(
                    file.clone(),
                    Edit::new(
                        Span::new(reference.span.start, reference.span.start),
                        format!("{namespace}."),
                        format!("{} lives in {} now", sym.name, destination.display()),
                    ),
                ),
                None => plan.warnings.push(format!(
                    "{}: `{}` carries no namespace in a file that does not declare it, which \
                     Zig cannot resolve either way; this left it alone",
                    location(file, reference.span.start),
                    sym.name
                )),
            }
        }

        // A namespace kept only for the declaration that left is dead weight.
        if let Some(old) = zig_import_binding(index, file, &sym.file) {
            let still_used = index.file(file).is_some_and(|info| {
                info.references
                    .iter()
                    .map(|i| &index.references[*i])
                    .any(|r| r.name == old && !repointed.contains(&r.span))
            });
            if !still_used {
                plan.warnings.push(format!(
                    "{} imports {} as `{old}` only for `{}`; that import may now be unused",
                    file.display(),
                    sym.file.display(),
                    sym.name
                ));
            }
        }
    }

    warn_about_carried_imports(index, sym, destination, removal, &source, &mut plan);
    carry_defined_dependencies(index, sym, destination, removal, &source, &mut plan);
    Ok(plan)
}

/// Top-level declarations of a Zig file.
fn zig_top_level<'a>(index: &'a Index, file: &Path) -> Vec<&'a Symbol> {
    let Some(info) = index.file(file) else {
        return Vec::new();
    };
    info.symbols
        .iter()
        .filter_map(|id| index.symbol(*id))
        .filter(|s| s.is_top_level())
        .collect()
}

/// The local name `file` binds the `@import` of `target` to, if it has one.
fn zig_qualifier_span(
    parsed: &crate::parse::Parsed,
    source: &str,
    member: Span,
    namespace: &str,
) -> Option<Span> {
    let node = parsed
        .root()
        .descendant_for_byte_range(member.start, member.end)?;
    let parent = node.parent()?;
    if parent.kind() != "field_expression" {
        return None;
    }
    let object = parent.child_by_field_name("object")?;
    if Span::from(object).text(source).trim() != namespace {
        return None;
    }
    Some(Span::new(object.start_byte(), member.start))
}

fn zig_import_binding(index: &Index, file: &Path, target: &Path) -> Option<String> {
    let info = index.file(file)?;
    info.imports.iter().find_map(|import| {
        (zig_import_file(file, &import.path).as_deref() == Some(target))
            .then(|| zig_import_local(import))
            .flatten()
    })
}

/// The file `local` names in `file`, if `local` binds an `@import` of a Zig source.
fn zig_import_binding_target(index: &Index, file: &Path, local: &str) -> Option<PathBuf> {
    let info = index.file(file)?;
    info.imports.iter().find_map(|import| {
        (zig_import_local(import).as_deref() == Some(local))
            .then(|| zig_import_file(file, &import.path))
            .flatten()
    })
}

fn zig_import_local(import: &crate::model::Import) -> Option<String> {
    import
        .names
        .first()
        .map(|n| n.local.clone())
        .or_else(|| import.alias.clone())
}

/// The workspace file an `@import` path names, or `None` for a package such as `std`.
fn zig_import_file(from: &Path, path: &str) -> Option<PathBuf> {
    if !path.ends_with(".zig") {
        return None;
    }
    Some(crate::vfs::normalise(from.parent()?.join(path)))
}

/// The path `from` would have to write to `@import` `to`.
fn zig_import_path(from: &Path, to: &Path) -> Option<String> {
    let rest = to.strip_prefix(from.parent()?).ok()?;
    let mut parts = Vec::new();
    for component in rest.components() {
        parts.push(component.as_os_str().to_str()?.to_string());
    }
    (!parts.is_empty()).then(|| parts.join("/"))
}

/// The identifier a new `@import` of `destination` binds.
fn zig_namespace_name(destination: &Path) -> Result<String> {
    let stem = destination
        .file_stem()
        .and_then(|s| s.to_str())
        .ok_or_else(|| anyhow::anyhow!("{} has no file name", destination.display()))?;
    let mut out = String::with_capacity(stem.len());
    for ch in stem.chars() {
        out.push(if ch.is_ascii_alphanumeric() || ch == '_' {
            ch
        } else {
            '_'
        });
    }
    if out.starts_with(|c: char| c.is_ascii_digit()) {
        out.insert(0, '_');
    }
    if out.is_empty() {
        return Err(Refusal::Declined {
            detail: format!(
                "{} has no file name that yields a Zig identifier",
                destination.display()
            ),
        }
        .into());
    }
    Ok(out)
}

/// The `object` of `object.member` when `span` is the member, or `None` when the use
/// is a bare identifier.
fn zig_qualifier<'a>(
    parsed: &'a crate::parse::Parsed,
    span: Span,
) -> Option<tree_sitter::Node<'a>> {
    let node = parsed
        .root()
        .descendant_for_byte_range(span.start, span.end)?;
    let parent = node.parent()?;
    if parent.kind() != "field_expression" {
        return None;
    }
    if parent.child_by_field_name("member").map(Span::from) != Some(Span::from(node)) {
        return None;
    }
    parent.child_by_field_name("object")
}

/// Where a new `@import` goes: after the file header and any `@import`s already there.
fn zig_import_insertion_point(source: &str) -> usize {
    let mut offset = 0;
    let mut point = 0;
    for line in source.split_inclusive('\n') {
        let trimmed = line.trim_start();
        let is_import = (trimmed.starts_with("const ") || trimmed.starts_with("pub const "))
            && trimmed.contains("@import(");
        if trimmed.starts_with("//") || is_import {
            point = offset + line.len();
        } else if !trimmed.is_empty() {
            break;
        }
        offset += line.len();
    }
    point
}

// Bash: there is no import, only `source`.

fn move_bash(index: &Index, sym: &Symbol, destination: &Path) -> Result<MovePlan> {
    use super::signature::{shell_reaches, shell_source_graph};

    if sym.kind != SymbolKind::Function {
        return Err(Refusal::Declined {
            detail: format!(
                "'{}' is {}; only a function moves between scripts. A variable's \
             value depends on when its assignment ran, so moving one changes what it \
             holds and not where it lives",
                sym.name,
                sym.kind.with_article()
            ),
        }
        .into());
    }
    if sym.container.is_some() {
        return Err(Refusal::Declined {
            detail: format!(
                "'{}' is defined inside another function or subshell; only a top-level \
             function moves",
                sym.name
            ),
        }
        .into());
    }
    if let Some(existing) = index
        .file(destination)
        .into_iter()
        .flat_map(|info| info.symbols.iter())
        .filter_map(|id| index.symbol(*id))
        .find(|s| s.name == sym.name && s.kind == SymbolKind::Function)
    {
        return Err(Refusal::NameCollision {
            existing: existing.name.clone(),
            file: destination.to_path_buf(),
        }
        .into());
    }

    let source = crate::vfs::read_to_string(&sym.file)?;
    let removal = with_shell_comment(&source, whole_lines(&source, sym.full_span));
    let moved_text = removal.text(&source).to_string();

    let (mut sources, opaque) = shell_source_graph(index);

    // Everything that still runs the name after the definition has left.
    let mut callers: BTreeMap<PathBuf, usize> = BTreeMap::new();
    for reference in &index.references {
        if reference.language != Language::Bash
            || reference.kind != crate::model::ReferenceKind::Call
            || reference.name != sym.name
            || reference.file == *destination
        {
            continue;
        }
        if reference.file == sym.file && removal.contains(reference.span) {
            continue;
        }
        *callers.entry(reference.file.clone()).or_default() += 1;
    }

    let mut plan = MovePlan::new(sym, destination);
    plan.edits.add(
        sym.file.clone(),
        Edit::new(
            removal_with_separator(&source, removal),
            "",
            format!("move {} out", sym.name),
        ),
    );
    append_to_destination(
        &mut plan.edits,
        destination,
        &moved_text,
        format!("move {} in", sym.name),
    );

    let mut sourced_anywhere = false;
    for (file, uses) in &callers {
        // A caller that computes what it sources could already have the function in
        // scope, or not; nothing in the text says which.
        if opaque.contains(file) {
            return Err(Refusal::Unknowable {
                detail: format!(
                    "{} runs `{}` and sources a path that is not a literal, so what is \
                     already in its scope cannot be known",
                    file.display(),
                    sym.name
                ),
            }
            .into());
        }
        // A caller that never sourced the defining file was never running this
        // function, so the move does not break it.
        if *file != sym.file && !shell_reaches(&sources, file, &sym.file) {
            plan.warnings.push(format!(
                "{} runs `{}` {uses} time(s) but never sources {}, so it already called \
                 something else; this left it alone",
                file.display(),
                sym.name,
                sym.file.display()
            ));
            continue;
        }
        if shell_reaches(&sources, file, destination) {
            continue;
        }

        let Some(dir) = file.parent() else {
            return Err(Refusal::Declined {
                detail: format!("{} is not inside a directory", file.display()),
            }
            .into());
        };
        let Some(path) = shell_source_path(dir, destination) else {
            return Err(Refusal::Declined {
                detail: format!(
                    "cannot express {} relative to {}",
                    destination.display(),
                    crate::vfs::describe_dir(dir)
                ),
            }
            .into());
        };
        let text = crate::vfs::read_to_string(file).unwrap_or_default();
        let at = shell_prelude_end(&text);
        plan.edits.add(
            file.clone(),
            Edit::new(
                Span::new(at, at),
                format!("source \"{path}\"\n"),
                format!("{} lives in {} now", sym.name, destination.display()),
            ),
        );
        plan.imports_added.push(file.clone());
        // A file that sources the destination now puts it in scope for whatever
        // sources *it*, so a later caller needs no second `source`.
        sources
            .entry(file.clone())
            .or_default()
            .push(crate::vfs::normalise(destination));
        sourced_anywhere = true;
    }

    if sourced_anywhere {
        plan.warnings.push(format!(
            "`source` resolves a relative path against the working directory, not the \
             script's own location, so the added lines only work when the scripts are run \
             from the right directory. Consider `source \"$(dirname \"${{BASH_SOURCE[0]}}\")/{}\"`.",
            destination
                .file_name()
                .and_then(|n| n.to_str())
                .unwrap_or("lib.sh")
        ));
    }

    Ok(plan)
}

/// Widen a removal to swallow the `#` comment block written directly above.
fn with_shell_comment(source: &str, span: Span) -> Span {
    let mut start = span.start;
    while start > 0 {
        let previous = full_line_span(source, start - 1);
        let trimmed = previous.text(source).trim_start();
        // The shebang belongs to the file, never to the definition below it.
        if !trimmed.starts_with('#') || trimmed.starts_with("#!") {
            break;
        }
        start = previous.start;
    }
    Span::new(start, span.end)
}

/// The path a `source` in `from_dir` has to write to reach `to`.
fn shell_source_path(from_dir: &Path, to: &Path) -> Option<String> {
    let link = relative_link(from_dir, to)?;
    Some(if link.starts_with('.') {
        link
    } else {
        format!("./{link}")
    })
}

/// Where a `source` line goes: after the shebang, the header comments and whatever the
/// script already sources.
fn shell_prelude_end(source: &str) -> usize {
    let mut offset = 0;
    let mut point = 0;
    for line in source.split_inclusive('\n') {
        let trimmed = line.trim_start();
        let is_prelude = trimmed.starts_with('#')
            || trimmed.starts_with("set ")
            || trimmed.starts_with("source ")
            || trimmed.starts_with(". ");
        if is_prelude {
            point = offset + line.len();
        } else if !trimmed.is_empty() {
            break;
        }
        offset += line.len();
    }
    point
}

// YAML and Helm: a values key carries its address in its path, which names no file.

fn move_values_key(index: &Index, sym: &Symbol, destination: &Path) -> Result<MovePlan> {
    if sym.kind != SymbolKind::Key {
        return Err(Refusal::Declined {
            detail: format!(
                "'{}' is {}; only a mapping key and the subtree under it can move between \
             values files. An anchor reaches within one document and does not \
             survive leaving it",
                sym.name,
                sym.kind.with_article()
            ),
        }
        .into());
    }
    if let Some(container) = sym.container.and_then(|id| index.symbol(id)) {
        return Err(Refusal::NotHere {
            operation: "move to file".into(),
            detail: format!(
                "'{}' is nested under `{}`, so its address is the whole path down to it. \
                 Appending it to the top level of {} would change that path and every \
                 reference with it; only a top-level key moves",
                sym.name,
                container.name,
                destination.display()
            ),
        }
        .into());
    }

    let source = crate::vfs::read_to_string(&sym.file)?;
    let indent = line_indent(&source, sym.full_span.start);
    if !indent.is_empty() {
        return Err(Refusal::Declined {
            detail: format!(
                "'{}' at {} is indented by {} column(s) although nothing encloses it, so what \
             mapping it belongs to cannot be told from the text; refusing to guess an \
             indentation for it in {}",
                sym.name,
                location(&sym.file, sym.full_span.start),
                indent.len(),
                destination.display()
            ),
        }
        .into());
    }

    // Appending to a file that holds several documents would land the key in the last one.
    for file in [&sym.file, &destination.to_path_buf()] {
        let text = crate::vfs::read_to_string(file).unwrap_or_default();
        let language = crate::lang::detect(file).unwrap_or(sym.language);
        if yaml_document_count(language, &text)? > 1 {
            return Err(Refusal::Declined {
                detail: format!(
                    "{} holds more than one document; which one a top-level key belongs to is \
                 not decidable from the key alone",
                    file.display()
                ),
            }
            .into());
        }
    }

    if let Some(existing) = index
        .file(destination)
        .into_iter()
        .flat_map(|info| info.symbols.iter())
        .filter_map(|id| index.symbol(*id))
        .find(|s| s.container.is_none() && s.kind == SymbolKind::Key && s.name == sym.name)
    {
        return Err(Refusal::NameCollision {
            existing: existing.name.clone(),
            file: destination.to_path_buf(),
        }
        .into());
    }

    // The destination's own top level must really be at column zero, or a key appended
    // there joins nothing.
    let destination_source = crate::vfs::read_to_string(destination).unwrap_or_default();
    for key in index
        .file(destination)
        .into_iter()
        .flat_map(|info| info.symbols.iter())
        .filter_map(|id| index.symbol(*id))
        .filter(|s| s.container.is_none() && s.kind == SymbolKind::Key)
    {
        let existing_indent = line_indent(&destination_source, key.full_span.start);
        if !existing_indent.is_empty() {
            return Err(Refusal::Declined {
                detail: format!(
                    "the top-level keys of {} are indented by {} column(s), so a key appended \
                 at column zero would not join the same mapping",
                    destination.display(),
                    existing_indent.len()
                ),
            }
            .into());
        }
    }

    let removal = with_yaml_comment(&source, whole_lines(&source, sym.full_span));
    let moved_text = removal.text(&source).to_string();

    let mut plan = MovePlan::new(sym, destination);
    plan.edits.add(
        sym.file.clone(),
        Edit::new(
            removal_with_separator(&source, removal),
            "",
            format!("move `{}` out", sym.name),
        ),
    );
    append_to_destination(
        &mut plan.edits,
        destination,
        &moved_text,
        format!("move `{}` in", sym.name),
    );

    // Nothing to repoint: `.Values.<key>` names a path, and a top-level key's path is the same
    // in every values file.
    let file_name = sym
        .file
        .file_name()
        .and_then(|n| n.to_str())
        .unwrap_or_default();
    if file_name.eq_ignore_ascii_case("values.yaml") {
        plan.warnings.push(format!(
            "`helm install` reads only values.yaml by default, so `{}` stays unset \
             unless the caller passes {} with `-f`",
            sym.name,
            destination.display()
        ));
    }
    if sym.file.parent() != destination.parent() {
        plan.warnings.push(format!(
            "{} is not in the same directory as {}; check that whatever loads the values \
             still finds it",
            destination.display(),
            sym.file.display()
        ));
    }

    Ok(plan)
}

/// How many documents a YAML file holds.
fn yaml_document_count(language: Language, source: &str) -> Result<usize> {
    if source.trim().is_empty() {
        return Ok(0);
    }
    let parsed = crate::parse::Parsers::new().parse(language, source)?;
    let root = parsed.root();
    let mut cursor = root.walk();
    let count = root
        .named_children(&mut cursor)
        .filter(|c| c.kind() == "document")
        .count();
    Ok(count)
}

/// Widen a removal to swallow the `#` comment block written directly above the key.
fn with_yaml_comment(source: &str, span: Span) -> Span {
    let mut start = span.start;
    while start > 0 {
        let previous = full_line_span(source, start - 1);
        if !previous.text(source).trim_start().starts_with('#') || previous.start == 0 {
            break;
        }
        start = previous.start;
    }
    Span::new(start, span.end)
}

// Shared machinery.

/// Take the whole line(s) a definition sits on.
fn whole_lines(source: &str, span: Span) -> Span {
    let start_line = full_line_span(source, span.start);
    let end_line = full_line_span(source, span.end.saturating_sub(1));
    Span::new(start_line.start, end_line.end.max(span.end))
}

/// What to erase when a declaration leaves a file: its own lines, and the blank ones that
/// separated it from its neighbour.
fn removal_with_separator(source: &str, removal: Span) -> Span {
    let before = blank_run(source, removal.start, Direction::Back);
    let after = blank_run(source, removal.end, Direction::Forward);
    if after == source.len() {
        return Span::new(before, after);
    }
    match before < removal.start && after > removal.end {
        true => Span::new(removal.start, after),
        false => removal,
    }
}

/// The erase spans for several declarations leaving one file, with the separators worked out
/// once between them.
fn erase_spans(source: &str, spans: &[Span]) -> Vec<Span> {
    let mut out: Vec<Span> = spans.to_vec();
    out.sort_by_key(|span| (span.start, span.end));
    loop {
        let widened: Vec<Span> = out
            .iter()
            .map(|span| removal_with_separator(source, *span))
            .collect();
        let mut merged: Vec<Span> = Vec::new();
        for span in widened {
            match merged.last_mut() {
                Some(last) if span.start <= last.end => last.end = last.end.max(span.end),
                _ => merged.push(span),
            }
        }
        if merged == out {
            return merged;
        }
        out = merged;
    }
}

enum Direction {
    Forward,
    Back,
}

/// How far the run of blank lines starting at `offset` reaches, in the direction given.
fn blank_run(source: &str, offset: usize, direction: Direction) -> usize {
    let mut at = offset;
    loop {
        let line = match direction {
            Direction::Forward if at < source.len() => full_line_span(source, at),
            Direction::Back if at > 0 => full_line_span(source, at - 1),
            _ => return at,
        };
        if !line.text(source).trim().is_empty() {
            return at;
        }
        at = match direction {
            Direction::Forward => line.end,
            Direction::Back => line.start,
        };
    }
}

/// Append `text` to a file that may not exist yet.
/// The module a Lean file is: `Geometry/Point.lean` is `Geometry.Point`, rooted at the
/// nearest lakefile or, with none above it, at the file's own directory.
fn lean_module_path(file: &Path) -> Option<String> {
    let dir = file.parent()?;
    let root = dir
        .ancestors()
        .find(|a| {
            ["lakefile.lean", "lakefile.toml", "lean-toolchain"]
                .iter()
                .any(|marker| crate::vfs::read_to_string(a.join(marker)).is_ok())
        })
        .unwrap_or(dir);
    let relative = file.strip_prefix(root).ok()?;
    let mut parts: Vec<String> = Vec::new();
    for component in relative.components() {
        parts.push(component.as_os_str().to_str()?.to_string());
    }
    let last = parts.last_mut()?;
    *last = last.strip_suffix(".lean")?.to_string();
    Some(parts.join("."))
}

/// Where an `import` goes: Lean takes them all before any other command.
fn lean_import_insertion_point(source: &str) -> usize {
    let mut at = 0;
    let mut after_last_import = 0;
    for line in source.split_inclusive('\n') {
        let trimmed = line.trim_start();
        if trimmed.starts_with("import ") {
            at += line.len();
            after_last_import = at;
        } else if trimmed.is_empty() || trimmed.starts_with("--") {
            at += line.len();
        } else {
            break;
        }
    }
    after_last_import
}

/// Lean: a file is a module. A top-level declaration keeps its name wherever it lands,
/// so a use site needs the import and nothing else.
fn move_lean(index: &Index, sym: &Symbol, destination: &Path) -> Result<MovePlan> {
    if sym.container.is_some() {
        return Err(Refusal::Declined {
            detail: format!(
                "'{}' is nested inside another declaration; only a top-level declaration \
                 moves between Lean modules",
                sym.name
            ),
        }
        .into());
    }
    let Some(module) = lean_module_path(destination) else {
        return Err(Refusal::Declined {
            detail: format!(
                "{} yields no module path, so nothing can spell the `import` a use site \
                 would need",
                destination.display()
            ),
        }
        .into());
    };

    let source = crate::vfs::read_to_string(&sym.file)?;
    let removal = whole_lines(&source, sym.full_span);
    let moved_text = removal.text(&source).to_string();

    let mut plan = MovePlan::new(sym, destination);
    plan.edits.add(
        sym.file.clone(),
        Edit::new(removal, String::new(), format!("{} moves out", sym.name)),
    );
    append_to_destination(
        &mut plan.edits,
        destination,
        moved_text.trim_end(),
        format!("{} lands here", sym.name),
    );

    // Every file still naming it needs the destination module.
    let mut needs_import: BTreeSet<PathBuf> = BTreeSet::new();
    for reference in index.references_to(sym.id) {
        if reference.file == sym.file && removal.contains(reference.span) {
            continue;
        }
        if reference.file != *destination {
            needs_import.insert(reference.file.clone());
        }
    }
    for file in needs_import {
        let text = crate::vfs::read_to_string(&file).unwrap_or_default();
        if text
            .lines()
            .any(|l| l.trim_start().strip_prefix("import ") == Some(module.as_str()))
        {
            continue;
        }
        let at = lean_import_insertion_point(&text);
        plan.edits.add(
            file.clone(),
            Edit::new(
                Span::new(at, at),
                format!("import {module}\n"),
                format!("{} lives in {module} now", sym.name),
            ),
        );
        plan.imports_added.push(file);
    }
    Ok(plan)
}

fn append_to_destination(
    edits: &mut EditSet,
    destination: &Path,
    text: &str,
    reason: impl Into<String>,
) {
    let existing = crate::vfs::read_to_string(destination).unwrap_or_default();
    let separator = if existing.is_empty() || existing.ends_with("\n\n") {
        ""
    } else if existing.ends_with('\n') {
        "\n"
    } else {
        "\n\n"
    };
    edits.add(
        destination.to_path_buf(),
        Edit::new(
            Span::new(existing.len(), existing.len()),
            format!("{separator}{text}"),
            reason,
        ),
    );
}

/// Report the imports the moved text depended on, in both directions.
fn warn_about_carried_imports(
    index: &Index,
    sym: &Symbol,
    destination: &Path,
    removal: Span,
    source: &str,
    plan: &mut MovePlan,
) {
    let Some(info) = index.file(&sym.file) else {
        return;
    };
    let moved_text = removal.text(source);

    for import in &info.imports {
        let bound: Vec<String> = if !import.names.is_empty() {
            import.names.iter().map(|n| n.local.clone()).collect()
        } else if let Some(alias) = &import.alias {
            vec![alias.clone()]
        } else {
            import
                .path
                .rsplit(['/', ':'])
                .find(|s| !s.is_empty())
                .map(|s| vec![s.to_string()])
                .unwrap_or_default()
        };

        for name in bound {
            if !mentions_word(moved_text, &name) {
                continue;
            }
            let still_used = info
                .references
                .iter()
                .map(|i| &index.references[*i])
                .any(|r| r.name == name && !removal.contains(r.span));
            if !still_used {
                plan.warnings.push(format!(
                    "{} imports '{}' only for the code this moves; the import may now \
                     be unused",
                    sym.file.display(),
                    import.path
                ));
            }
            let destination_has = index
                .file(destination)
                .is_some_and(|d| d.imports.iter().any(|i| i.path == import.path));
            if !destination_has {
                plan.warnings.push(format!(
                    "the moved code uses '{}' from '{}', which {} does not import",
                    name,
                    import.path,
                    destination.display()
                ));
            }
        }
    }
}

/// Names the source file *defines* that the moved code still uses.
fn carry_defined_dependencies(
    index: &Index,
    sym: &Symbol,
    destination: &Path,
    removal: Span,
    source: &str,
    plan: &mut MovePlan,
) {
    // A Go move inside one package keeps one scope, so no name changes.
    if sym.language == Language::Go && sym.file.parent() == destination.parent() {
        return;
    }
    let Some(info) = index.file(&sym.file) else {
        return;
    };
    let Ok(used) = names_used_in(sym.language, source, removal) else {
        return;
    };
    // Names the destination already binds need no second `use`: writing `use
    // crate::edit::full_line_span;` under an existing `use crate::edit::{full_line_span, …}` is
    // E0252, twice defined.
    let bound_at_destination: std::collections::HashSet<String> = index
        .file(destination)
        .map(|dest| {
            import_statements(&dest.imports)
                .into_iter()
                .flat_map(|statement| {
                    let implicit =
                        crate::refactor::imports::implicit_binding(&statement.path, sym.language);
                    statement
                        .names
                        .iter()
                        .map(|n| n.local.clone())
                        .collect::<Vec<_>>()
                        .into_iter()
                        .chain(statement.alias.clone())
                        .chain(implicit)
                })
                .collect()
        })
        .unwrap_or_default();
    let used: std::collections::HashSet<String> = used
        .iter()
        .filter(|name| !bound_at_destination.contains(*name))
        .cloned()
        .collect();

    let mut wanted: Vec<&Symbol> = info
        .symbols
        .iter()
        .filter_map(|id| index.symbol(*id))
        .filter(|s| s.id != sym.id && s.is_top_level() && used.contains(&s.name))
        .collect();
    wanted.sort_by(|a, b| a.name.cmp(&b.name));
    wanted.dedup_by(|a, b| a.name == b.name);
    if wanted.is_empty() {
        return;
    }
    let names: Vec<String> = wanted.iter().map(|s| s.name.clone()).collect();

    if sym.language == Language::Rust {
        if let (Ok(from), Ok(_)) = (crate_module(&sym.file), crate_module(destination)) {
            let joined = match names.len() {
                1 => names[0].clone(),
                _ => format!("{{{}}}", names.join(", ")),
            };
            let existing = crate::vfs::read_to_string(destination).unwrap_or_default();
            let at = rust_use_insertion_point(&existing);
            plan.edits.add(
                destination.to_path_buf(),
                Edit::new(
                    Span::new(at, at),
                    format!("use {}::{joined};\n", from.use_prefix()),
                    format!("what {} needs where it lands", sym.name),
                ),
            );
            // A private item is invisible from another module, so the `use` alone would not
            // compile.
            for symbol in &wanted {
                if let Some(edit) = rust_pub_edit(&sym.file, symbol) {
                    plan.edits.add(sym.file.clone(), edit);
                }
            }
            return;
        }
    }

    plan.warnings.push(format!(
        "the moved code uses {} defined in {}, and nothing can spell an import naming \
         {} from {}; add it by hand or the moved code will not compile",
        names.join(", "),
        sym.file.display(),
        if names.len() == 1 { "it" } else { "them" },
        destination.display()
    ));
}

/// Make a Rust item visible outside its module, if it is not already.
fn rust_pub_edit(file: &Path, symbol: &Symbol) -> Option<Edit> {
    let source = crate::vfs::read_to_string(file).ok()?;
    let line_start = whole_lines(&source, symbol.full_span).start;
    let rest = &source[line_start..];
    let lead = rest.len() - rest.trim_start().len();
    let start = line_start + lead;
    let word_len = source[start..]
        .find(|c: char| c.is_whitespace())
        .unwrap_or(source.len() - start);
    let word = &source[start..start + word_len];
    if word == "pub" || word.starts_with("pub(") {
        return None;
    }
    Some(Edit::new(
        Span::new(start, start + word_len),
        format!("pub {word}"),
        format!("make {} visible from its new caller", symbol.name),
    ))
}

/// Does `text` contain `word` as a whole identifier?
fn mentions_word(text: &str, word: &str) -> bool {
    if word.is_empty() {
        return false;
    }
    let boundary = |c: char| !c.is_alphanumeric() && c != '_';
    let mut from = 0;
    while let Some(found) = text[from..].find(word) {
        let start = from + found;
        let end = start + word.len();
        let before_ok = start == 0 || text[..start].chars().next_back().is_some_and(boundary);
        let after_ok = end == text.len() || text[end..].chars().next().is_some_and(boundary);
        if before_ok && after_ok {
            return true;
        }
        from = end;
    }
    false
}

/// `path:line:col`, for warnings that point a human at a file.
fn location(file: &Path, offset: usize) -> String {
    let Ok(source) = crate::vfs::read_to_string(file) else {
        return file.display().to_string();
    };
    let position = LineIndex::new(&source).line_col(offset, &source);
    format!("{}:{}", file.display(), position)
}

/// The symbols a move accepts, by what a move means in each language.
pub fn movable(index: &Index, file: &Path) -> Vec<SymbolId> {
    let Some(info) = index.file(file) else {
        return Vec::new();
    };
    info.symbols
        .iter()
        .filter_map(|id| index.symbol(*id))
        .filter(|s| match s.language {
            // Nothing, because `move` refuses for Java.
            Language::Java => false,
            // A Lean module is a file, and a top-level declaration moves between two.
            Language::Lean => {
                s.container.is_none()
                    && matches!(
                        s.kind,
                        SymbolKind::Function | SymbolKind::Struct | SymbolKind::Enum
                    )
            }
            Language::TypeScript | Language::Tsx | Language::Python => {
                s.container.is_none()
                    && matches!(
                        s.kind,
                        SymbolKind::Function | SymbolKind::Class | SymbolKind::Constant
                    )
            }
            Language::Rust | Language::Go => {
                s.container.is_none()
                    && matches!(
                        s.kind,
                        SymbolKind::Function
                            | SymbolKind::Struct
                            | SymbolKind::Enum
                            | SymbolKind::Trait
                            | SymbolKind::Interface
                            | SymbolKind::TypeAlias
                            | SymbolKind::Constant
                    )
            }
            // A `locals` entry has the `locals` block as its container and is movable all the
            // same.
            Language::Hcl => {
                matches!(
                    s.kind,
                    SymbolKind::Block | SymbolKind::Variable | SymbolKind::Module
                ) && (s.container.is_none() || enclosing_locals_block(index, s).is_some())
            }
            Language::Css | Language::Scss | Language::Sass => {
                matches!(s.kind, SymbolKind::Selector | SymbolKind::ElementId)
            }
            Language::Markdown => s.kind == SymbolKind::Heading,
            Language::Zig => {
                s.container.is_none()
                    && matches!(
                        s.kind,
                        SymbolKind::Function
                            | SymbolKind::Struct
                            | SymbolKind::Enum
                            | SymbolKind::TypeAlias
                            | SymbolKind::Constant
                            | SymbolKind::Variable
                    )
            }
            // A variable's value depends on when its assignment ran, so only a
            // function is a definition a move can carry.
            Language::Bash => s.container.is_none() && s.kind == SymbolKind::Function,
            // A nested key's path is its address; only a top-level key keeps the same
            // path in another file.
            Language::Yaml | Language::Helm | Language::Json => {
                s.container.is_none() && s.kind == SymbolKind::Key
            }
            Language::Html | Language::Xml => false,
        })
        .map(|s| s.id)
        .collect()
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::edit::apply_to_string;

    use crate::testing::workspace;

    fn apply(plan: &MovePlan, path: &Path) -> String {
        let original = crate::vfs::read_to_string(path).unwrap_or_default();
        match plan.edits.edits_for(path) {
            Some(edits) => apply_to_string(&original, edits).unwrap(),
            None => original,
        }
    }

    #[test]
    fn moves_a_function_between_python_modules() {
        let (tmp, index) = workspace(&[
            (
                "helpers.py",
                "def keep():\n    pass\n\ndef moved():\n    return 1\n",
            ),
            ("other.py", "def existing():\n    pass\n"),
        ]);
        let id = index.find_symbols("moved", None)[0].id;
        let dest = tmp.path().join("other.py");

        let plan = to_file(&index, id, &dest).unwrap();

        let from = apply(&plan, &tmp.path().join("helpers.py"));
        assert!(!from.contains("def moved"), "should be gone:\n{from}");
        assert!(from.contains("def keep"), "should remain:\n{from}");

        let to = apply(&plan, &dest);
        assert!(to.contains("def moved"), "should arrive:\n{to}");
        assert!(to.contains("def existing"), "should be preserved:\n{to}");
    }

    #[test]
    fn adds_an_import_where_the_symbol_is_still_used() {
        let (tmp, index) = workspace(&[
            ("lib.py", "def shared():\n    return 1\n"),
            (
                "app.py",
                "from lib import shared\n\ndef use():\n    return shared()\n",
            ),
            ("dest.py", "x = 1\n"),
        ]);
        let id = index.find_symbols("shared", None)[0].id;
        let dest = tmp.path().join("dest.py");
        let plan = to_file(&index, id, &dest).unwrap();

        assert!(
            plan.imports_added.iter().any(|p| p.ends_with("app.py")),
            "app.py uses it and must gain an import: {:?}",
            plan.imports_added
        );
        let app = apply(&plan, &tmp.path().join("app.py"));
        assert!(
            app.contains("from ./dest import shared")
                || app.contains("from .dest import shared")
                || app.contains("dest import shared"),
            "got:\n{app}"
        );
    }

    #[test]
    fn typescript_gets_a_named_import() {
        let (tmp, index) = workspace(&[
            ("a.ts", "export function moved() { return 1; }\n"),
            (
                "b.ts",
                "import { moved } from './a';\nexport const x = moved();\n",
            ),
            ("c.ts", "export const y = 2;\n"),
        ]);
        let id = index.find_symbols("moved", None)[0].id;
        let dest = tmp.path().join("c.ts");
        let plan = to_file(&index, id, &dest).unwrap();

        let b = apply(&plan, &tmp.path().join("b.ts"));
        assert!(b.contains("import { moved } from './c';"), "got:\n{b}");
    }

    #[test]
    fn refuses_languages_with_no_derivable_reachability() {
        // An element id is not a name another document imports, so there is nothing a
        // move could repoint and no reachability it could preserve.
        let (tmp, index) = workspace(&[
            ("a.html", "<div id=\"thing\">x</div>\n"),
            ("b.html", "<p>y</p>\n"),
        ]);
        let found = index.find_symbols("thing", None);
        assert!(!found.is_empty(), "the id must be extracted to be refused");
        let err = to_file(&index, found[0].id, &tmp.path().join("b.html")).unwrap_err();
        assert!(
            err.downcast_ref::<Refusal>()
                .is_some_and(|r| matches!(r, Refusal::Unsupported { .. })),
            "got: {err}"
        );
    }

    #[test]
    fn refuses_to_move_a_nested_symbol() {
        let (tmp, index) = workspace(&[
            ("a.py", "class C:\n    def method(self):\n        pass\n"),
            ("b.py", "x = 1\n"),
        ]);
        let id = index
            .find_symbols("method", None)
            .first()
            .expect("method extracted")
            .id;
        let err = to_file(&index, id, &tmp.path().join("b.py"))
            .unwrap_err()
            .to_string();
        assert!(err.contains("top-level"), "got: {err}");
    }

    #[test]
    fn refuses_a_move_to_the_same_file() {
        let (tmp, index) = workspace(&[("a.py", "def f():\n    pass\n")]);
        let id = index.find_symbols("f", None)[0].id;
        let err = to_file(&index, id, &tmp.path().join("a.py"))
            .unwrap_err()
            .to_string();
        assert!(err.contains("already in"), "got: {err}");
    }

    #[test]
    fn refuses_a_move_that_would_change_language() {
        let (tmp, index) = workspace(&[("a.py", "def f():\n    pass\n"), ("b.ts", "\n")]);
        let id = index.find_symbols("f", None)[0].id;
        let err = to_file(&index, id, &tmp.path().join("b.ts"))
            .unwrap_err()
            .to_string();
        assert!(err.contains("cannot change language"), "got: {err}");
    }

    #[test]
    fn relative_module_paths_are_computed_correctly() {
        assert_eq!(
            relative_module(Path::new("/w/src/a.ts"), Path::new("/w/src/b.ts")).as_deref(),
            Some("./b")
        );
        let nested = relative_module(Path::new("/w/src/deep/a.ts"), Path::new("/w/src/b.ts"));
        assert!(
            nested.as_deref().is_some_and(|m| m.contains("b")),
            "got {nested:?}"
        );
    }

    #[test]
    fn python_relative_modules_are_spelled_with_dots() {
        assert_eq!(
            python_relative_module(Path::new("/w/a.py"), Path::new("/w/b.py")).as_deref(),
            Some(".b")
        );
        assert_eq!(
            python_relative_module(Path::new("/w/a.py"), Path::new("/w/sub/b.py")).as_deref(),
            Some(".sub.b")
        );
        assert_eq!(
            python_relative_module(Path::new("/w/sub/a.py"), Path::new("/w/b.py")).as_deref(),
            Some("..b")
        );
    }

    #[test]
    fn import_insertion_lands_after_existing_imports() {
        let source = "import a from 'a';\nimport b from 'b';\n\nconst x = 1;\n";
        let at = import_insertion_point(source);
        assert_eq!(&source[..at], "import a from 'a';\nimport b from 'b';\n");
    }

    #[test]
    fn a_file_with_no_imports_gets_one_at_the_top() {
        assert_eq!(import_insertion_point("const x = 1;\n"), 0);
    }

    #[test]
    fn a_hole_between_two_declarations_keeps_one_separator() {
        let source = "package p\n\nfunc a() {}\n\nfunc b() {}\n";
        let removed = erase_spans(source, &[Span::new(11, 23)]);
        assert_eq!(removed, vec![Span::new(11, 24)]);
        assert_eq!(cut(source, &removed), "package p\n\nfunc b() {}\n");
    }

    #[test]
    fn a_hole_at_the_end_of_the_file_takes_the_blank_line_above_it() {
        let source = "package p\n\nfunc a() {}\n\nfunc b() {}\n";
        let removed = erase_spans(source, &[Span::new(24, 36)]);
        assert_eq!(cut(source, &removed), "package p\n\nfunc a() {}\n");
    }

    #[test]
    fn a_declaration_with_nothing_blank_above_it_keeps_the_line_below() {
        // The blank line is the only separator between what precedes and what follows, so it is
        // not a leftover.
        let source = "# What this file is.\nalpha: 1\n\n# Why beta exists.\nbeta: 2\n";
        let removed = erase_spans(source, &[Span::new(21, 30)]);
        assert_eq!(
            cut(source, &removed),
            "# What this file is.\n\n# Why beta exists.\nbeta: 2\n"
        );
    }

    #[test]
    fn two_holes_whose_separators_meet_are_one_hole() {
        // Claiming the blank run for each separately had two edits fighting over one line,
        // which the applier refuses.
        let source = "package p\n\nimport \"math\"\n\nfunc a() {}\n";
        let removed = erase_spans(source, &[Span::new(11, 25), Span::new(26, 38)]);
        assert_eq!(removed.len(), 1, "one hole: {removed:?}");
        assert_eq!(cut(source, &removed), "package p\n");
    }

    /// `source` with every span removed, for reading an assertion at a glance.
    fn cut(source: &str, spans: &[Span]) -> String {
        let mut out = source.to_string();
        for span in spans.iter().rev() {
            out.replace_range(span.start..span.end, "");
        }
        out
    }

    #[test]
    fn rust_use_insertion_lands_after_the_header_and_uses() {
        let source = "//! Docs.\nuse std::fmt;\n\nfn f() {}\n";
        let at = rust_use_insertion_point(source);
        assert_eq!(&source[..at], "//! Docs.\nuse std::fmt;\n");
        assert_eq!(rust_use_insertion_point("fn f() {}\n"), 0);
    }

    #[test]
    fn module_declarations_are_recognised_only_in_the_file_form() {
        assert!(declares_module("mod helpers;\n", "helpers"));
        assert!(declares_module("pub mod helpers;\n", "helpers"));
        assert!(declares_module("pub(crate) mod helpers;\n", "helpers"));
        assert!(!declares_module("mod helpers { }\n", "helpers"));
        assert!(!declares_module("mod other;\n", "helpers"));
    }

    #[test]
    fn slugs_follow_the_anchor_spelling() {
        assert_eq!(slug("Title One"), "title-one");
        assert_eq!(slug("  Getting Started!  "), "getting-started");
        assert_eq!(slug("C++ & Rust"), "c--rust");
    }

    #[test]
    fn relative_links_walk_up_and_down() {
        assert_eq!(
            relative_link(Path::new("/w/docs"), Path::new("/w/docs/a.md")).as_deref(),
            Some("a.md")
        );
        assert_eq!(
            relative_link(Path::new("/w/docs/deep"), Path::new("/w/docs/a.md")).as_deref(),
            Some("../a.md")
        );
    }

    #[test]
    fn whole_word_matching_ignores_substrings() {
        assert!(mentions_word("use fmt::Debug;", "fmt"));
        assert!(!mentions_word("format!(\"x\")", "fmt"));
    }
}
