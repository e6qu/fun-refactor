//! Cascading cleanup: remove a flag and everything that only existed to serve it.

use crate::edit::{Edit, EditSet};
use crate::index::Index;
use crate::lang::Language;
use crate::model::SymbolKind;
use crate::parse::{Parsed, Parsers};
use crate::refactor::Refusal;
#[cfg(feature = "cli")]
use crate::scan::{scan, ScanOptions};
use crate::span::{LineIndex, Span};
use anyhow::Result;
use std::collections::{BTreeMap, BTreeSet, HashSet};
use std::path::{Path, PathBuf};
use tree_sitter::Node;

/// Bound on rounds, so a rule that keeps finding work cannot spin forever.
const MAX_ROUNDS: usize = 12;

/// A cascade worked out but not applied.
#[derive(Debug)]
pub struct CascadePlan {
    pub flag: String,
    pub value: bool,
    pub edits: EditSet,
    /// What each round did, in order.
    pub rounds: Vec<RoundSummary>,
    /// Everything the cascade left behind, each named with the place it gave up.
    pub unfinished: Vec<String>,
}

/// One pass of the cascade.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct RoundSummary {
    pub description: String,
    pub files_touched: usize,
}

impl CascadePlan {
    pub fn is_empty(&self) -> bool {
        self.edits.is_empty()
    }
}

/// Does the collapse step know this language's conditionals?
pub fn supports_cascade(language: Language) -> bool {
    matches!(
        language,
        Language::Rust
            | Language::Go
            | Language::Zig
            | Language::TypeScript
            | Language::Tsx
            | Language::Python
            | Language::Bash
            | Language::Hcl
            | Language::Java
    )
}

/// Which declaration to remove, when the name alone does not say.
#[derive(Debug, Clone)]
pub enum FlagTarget {
    Named(String),
    /// A byte offset inside a file, as `fr delete` and `fr rename` already accept.
    At(PathBuf, usize),
}

/// Remove `flag`, assuming it always had `value`, and clean up what follows.
#[cfg(feature = "cli")]
pub fn remove_flag(root: &Path, flag: &str, value: bool) -> Result<CascadePlan> {
    remove_flag_for(root, &FlagTarget::Named(flag.to_string()), value)
}

/// [`remove_flag`], told which declaration is meant.
#[cfg(feature = "cli")]
pub fn remove_flag_for(root: &Path, target: &FlagTarget, value: bool) -> Result<CascadePlan> {
    let scanned = scan(root, &ScanOptions::default())?;

    let mut sources: BTreeMap<PathBuf, (Language, String)> = BTreeMap::new();
    for file in &scanned.files {
        let Ok(text) = crate::vfs::read_to_string(&file.path) else {
            continue;
        };
        sources.insert(file.path.clone(), (file.language, text));
    }
    remove_flag_in_for(sources, target, value)
}

/// [`remove_flag`] over sources already held in memory.
pub fn remove_flag_in(
    sources: BTreeMap<PathBuf, (Language, String)>,
    flag: &str,
    value: bool,
) -> Result<CascadePlan> {
    remove_flag_in_for(sources, &FlagTarget::Named(flag.to_string()), value)
}

/// [`remove_flag_in`], told which declaration is meant.
pub fn remove_flag_in_for(
    sources: BTreeMap<PathBuf, (Language, String)>,
    target: &FlagTarget,
    value: bool,
) -> Result<CascadePlan> {
    // Every language the workspace holds, because a cascade is not scoped to one file.
    for (language, _) in sources.values() {
        crate::capabilities::record(crate::capabilities::Capability::RemoveFlag, *language);
    }
    let mut sources = sources;

    let flag_name = {
        let snapshot: Vec<(PathBuf, Language, String)> = sources
            .iter()
            .map(|(p, (l, s))| (p.clone(), *l, s.clone()))
            .collect();
        let index = Index::build_from_sources(&snapshot)?;
        match target {
            FlagTarget::Named(name) => match index.symbols_written(name, None).first() {
                Some(symbol) => symbol.name.clone(),
                // Kept as written, so the refusal below names what the caller asked for.
                None => name.clone(),
            },
            FlagTarget::At(path, offset) => match index.definition_at(path, *offset) {
                Some(symbol) => symbol.name.clone(),
                None => {
                    return Err(Refusal::Declined {
                        detail: format!(
                            "no declaration at {}:{offset}; this changed nothing",
                            path.display()
                        ),
                    }
                    .into())
                }
            },
        }
    };
    let flag = &flag_name;
    // Keep the originals to diff against at the end.
    let originals = sources.clone();

    // Only symbols that had a use before any of this started can be *orphaned* by the cascade.
    let initially_used: HashSet<(String, PathBuf)> = {
        let snapshot: Vec<(PathBuf, Language, String)> = sources
            .iter()
            .map(|(p, (l, s))| (p.clone(), *l, s.clone()))
            .collect();
        let index = Index::build_from_sources(&snapshot)?;
        index
            .symbols
            .iter()
            .filter(|s| index.has_references(s.id))
            .map(|s| (s.name.clone(), s.file.clone()))
            .collect()
    };

    // Which imports were unused before any of this started.
    let already_dead_imports: HashSet<(PathBuf, Span)> = {
        let snapshot: Vec<(PathBuf, Language, String)> = sources
            .iter()
            .map(|(p, (l, s))| (p.clone(), *l, s.clone()))
            .collect();
        let index = Index::build_from_sources(&snapshot)?;
        sources
            .iter()
            .flat_map(|(path, (_, text))| {
                dead_import_spans(&index, path, text)
                    .into_iter()
                    .map(|(span, _)| (path.clone(), span))
            })
            .collect()
    };

    let mut rounds = Vec::new();
    let mut removed_definition = false;
    let mut unfinished = Vec::new();
    let mut flag_kind = SymbolKind::Constant;

    for round in 0..MAX_ROUNDS {
        let snapshot: Vec<(PathBuf, Language, String)> = sources
            .iter()
            .map(|(p, (l, s))| (p.clone(), *l, s.clone()))
            .collect();
        let index = Index::build_from_sources(&snapshot)?;

        // Round 1 substitutes the flag; later rounds only tidy what that exposed.
        let changes = if !removed_definition {
            match substitute_flag(&index, &sources, target, value)? {
                None if round == 0 => {
                    return Err(Refusal::Declined {
                        detail: format!("no symbol named '{flag}' to remove; this changed nothing"),
                    }
                    .into())
                }
                None => Vec::new(),
                Some((substituted, kind)) => {
                    flag_kind = kind;
                    removed_definition = true;
                    // An empty substitution means the flag stands and no use of it
                    // rewrote.
                    if !substituted.is_empty() {
                        rounds.push(RoundSummary {
                            description: format!("replaced uses of {flag} with {value}"),
                            files_touched: distinct_files(&substituted),
                        });
                    }
                    substituted
                }
            }
        } else {
            let simplified = simplify_constants(&sources, &originals)?;
            if !simplified.is_empty() {
                rounds.push(RoundSummary {
                    description: "collapsed conditionals whose test is now constant".into(),
                    files_touched: distinct_files(&simplified),
                });
                simplified
            } else {
                let orphans = remove_orphans(&index, &sources, flag, &initially_used)?;
                if !orphans.is_empty() {
                    rounds.push(RoundSummary {
                        description: "removed symbols nothing uses any more".into(),
                        files_touched: distinct_files(&orphans),
                    });
                    orphans
                } else {
                    let imports = remove_dead_imports(&index, &sources, &already_dead_imports)?;
                    if imports.is_empty() {
                        break;
                    }
                    rounds.push(RoundSummary {
                        description: "removed imports nothing uses any more".into(),
                        files_touched: distinct_files(&imports),
                    });
                    imports
                }
            }
        };

        if changes.is_empty() {
            break;
        }
        apply_in_memory(&mut sources, &changes)?;
    }

    unfinished.extend(remaining_uses(&sources, flag, flag_kind)?);
    unfinished.extend(unfinished_work(&sources, &originals)?);
    unfinished.extend(dangling_resource_uses(&sources, &originals)?);
    unfinished.extend(textual_mentions(&sources, flag)?);
    unfinished.sort();
    unfinished.dedup();

    // The result is the difference between what was on disk and what the cascade
    // arrived at, expressed as one replacement per changed file.
    let mut edits = EditSet::new();
    for (path, (_, final_text)) in &sources {
        let Some((_, original)) = originals.get(path) else {
            continue;
        };
        if original != final_text {
            edits.add(
                path.clone(),
                Edit::new(
                    Span::new(0, original.len()),
                    final_text.clone(),
                    format!("cascade from removing {flag}"),
                ),
            );
        }
    }

    // A cascade that changed nothing is a refusal, and reporting it as a plan of zero edits
    // would read as success.
    if edits.is_empty() {
        return Err(Refusal::Declined {
            detail: format!(
                "nothing about '{flag}' came out; this changed nothing:\n  {}",
                unfinished.join("\n  ")
            ),
        }
        .into());
    }

    Ok(CascadePlan {
        flag: flag.to_string(),
        value,
        edits,
        rounds,
        unfinished,
    })
}

/// A change to make to one file, as a byte range and its replacement.
type Change = (PathBuf, Span, String);

fn distinct_files(changes: &[Change]) -> usize {
    let mut paths: Vec<&PathBuf> = changes.iter().map(|(p, _, _)| p).collect();
    paths.sort();
    paths.dedup();
    paths.len()
}

/// Replace every use of the flag with a literal, and delete its definition.
fn substitute_flag(
    index: &Index,
    sources: &BTreeMap<PathBuf, (Language, String)>,
    target: &FlagTarget,
    value: bool,
) -> Result<Option<(Vec<Change>, SymbolKind)>> {
    let definition = match target {
        FlagTarget::At(path, offset) => match index.definition_at(path, *offset) {
            Some(symbol) => symbol,
            None => {
                return Err(Refusal::Declined {
                    detail: format!(
                        "no declaration at {}:{offset}; this changed nothing",
                        path.display()
                    ),
                }
                .into())
            }
        },
        FlagTarget::Named(name) => {
            let definitions = index.symbols_written(name, None);
            if definitions.is_empty() {
                return Ok(None);
            }
            if definitions.len() > 1 {
                let where_they_are: Vec<String> = definitions
                    .iter()
                    .map(|s| {
                        let line = sources
                            .get(&s.file)
                            .map(|(_, text)| {
                                LineIndex::new(text).line_col(s.full_span.start, text).line
                            })
                            .unwrap_or(0);
                        format!("{}:{line}", s.file.display())
                    })
                    .collect();
                return Err(Refusal::Declined {
                    detail: format!(
                        "'{name}' is defined {} times; say which one as `path:line:col`: {}",
                        definitions.len(),
                        where_they_are.join(", ")
                    ),
                }
                .into());
            }
            definitions[0]
        }
    };
    let flag = &definition.name;

    // The matrix asks `supports_cascade` and the command did not, so `n/a` was a claim with
    // nothing behind it.
    if !supports_cascade(definition.language) {
        return Err(crate::refactor::Refusal::Unsupported {
            operation: "removing a flag".into(),
            language: definition.language,
            because: "the cascade folds a constant into a language's conditionals, and \
                      this language has none for a flag to guard",
        }
        .into());
    }

    let literal = literal_for(definition.language, value);
    let parsers = Parsers::new();
    let mut trees: BTreeMap<PathBuf, Parsed> = BTreeMap::new();
    let mut changes = Vec::new();

    if let Some((language, source)) = sources.get(&definition.file) {
        let parsed = parsers.parse(*language, source)?;
        if let Some(what) = not_a_flag(definition, &parsed, source) {
            return Err(Refusal::Declined {
                detail: format!(
                    "'{flag}' is not a flag: it {what}. Removing a flag replaces every use of \
                 the name with `{literal}`, and that only reads correctly where the name \
                 held a boolean. This changed nothing."
                ),
            }
            .into());
        }
        trees.insert(definition.file.clone(), parsed);
    }

    // Nothing reads the name, so there is no flag to remove: no use to substitute, no
    // conditional to collapse, nothing to prune.
    if !index.has_references(definition.id) {
        // "Nothing reads it" is a claim about the whole workspace, and the weakly resolved
        // occurrences are the evidence against it.
        let weak = weak_occurrences(index, sources, definition);
        if !weak.is_empty() {
            return Err(Refusal::Declined {
                detail: format!(
                    "{0} declares '{flag}', and no use of it resolves firmly enough to \
                 rewrite. These name it and may read it:\n  {1}\nThis changed nothing.",
                    definition.file.display(),
                    weak.join("\n  ")
                ),
            }
            .into());
        }
        return Err(Refusal::Declined {
            detail: format!(
                "{0} declares '{flag}' and nothing reads it, so there is no flag to \
             remove. `fr delete` removes a declaration nothing uses. This changed nothing.",
                definition.file.display()
            ),
        }
        .into());
    }

    // A name means one thing throughout, so one use naming a type settles every other
    // use.
    if definition.language != Language::Hcl && definition.language != Language::Bash {
        for reference in index.references_to(definition.id) {
            let Some((language, source)) = sources.get(&reference.file) else {
                continue;
            };
            if !trees.contains_key(&reference.file) {
                trees.insert(reference.file.clone(), parsers.parse(*language, source)?);
            }
            let parsed = &trees[&reference.file];
            let names_a_type = parsed
                .root()
                .descendant_for_byte_range(reference.span.start, reference.span.end)
                .is_some_and(names_a_type);
            if names_a_type {
                let line = LineIndex::new(source)
                    .line_col(reference.span.start, source)
                    .line;
                return Err(Refusal::Declined {
                    detail: format!(
                        "'{flag}' is not a flag: it names a type at {}:{line}. Removing a flag \
                     replaces every use of the name with `{literal}`, and a boolean is not \
                     a type. This changed nothing.",
                        reference.file.display()
                    ),
                }
                .into());
            }
        }
    }

    let mut every_use_was_rewritten = true;
    for reference in index.references_to(definition.id) {
        let Some((language, source)) = sources.get(&reference.file) else {
            continue;
        };
        // A use we cannot place is a use we must not rewrite.
        if !reference.confidence.is_safe_to_rewrite() {
            every_use_was_rewritten = false;
            continue;
        }

        if !trees.contains_key(&reference.file) {
            trees.insert(reference.file.clone(), parsers.parse(*language, source)?);
        }
        let parsed = &trees[&reference.file];

        match use_site(*language, definition.kind, parsed, source, reference.span) {
            UseSite::Replace(span) => {
                changes.push((reference.file.clone(), span, literal.to_string()))
            }
            UseSite::Binds(_) => {}
            UseSite::Refuse(_) => every_use_was_rewritten = false,
        }
    }

    if every_use_was_rewritten {
        // The definition goes with whatever holds it and then with its whole line.
        let definition_span = match sources.get(&definition.file) {
            Some((language, source)) => {
                let widened = match parsers.parse(*language, source) {
                    Ok(parsed) => {
                        crate::refactor::delete::widen_for_delete(&parsed, source, definition)
                    }
                    Err(_) => definition.full_span,
                };
                crate::refactor::delete::deletion_span(source, widened)
            }
            None => definition.full_span,
        };
        changes.push((definition.file.clone(), definition_span, String::new()));
    }
    Ok(Some((changes, definition.kind)))
}

/// Occurrences of the flag's name that resolution could not tie to the declaration.
fn weak_occurrences(
    index: &Index,
    sources: &BTreeMap<PathBuf, (Language, String)>,
    definition: &crate::model::Symbol,
) -> Vec<String> {
    let mut out = Vec::new();
    for reference in index.unresolved_matching(definition.id) {
        // Resolved elsewhere, and firmly: a different thing that shares the name.
        if reference.target.is_some() && reference.confidence.is_safe_to_rewrite() {
            continue;
        }
        let Some((_, source)) = sources.get(&reference.file) else {
            continue;
        };
        out.push(describe(
            &reference.file,
            source,
            reference.span,
            &format!(
                "this names '{}', resolved only as '{}'",
                definition.name,
                reference.confidence.as_str()
            ),
        ));
    }
    out.sort();
    out.dedup();
    out
}

/// What the declaration says the named symbol holds, where that rules a flag out.
fn not_a_flag(symbol: &crate::model::Symbol, parsed: &Parsed, source: &str) -> Option<String> {
    // A `Field` is a struct member in Go and Rust and never a flag, but Java has no top level
    // below the type.
    let field_is_a_constant = symbol.language == Language::Java;
    let kind_can_hold_a_flag = matches!(
        symbol.kind,
        SymbolKind::Constant | SymbolKind::Variable | SymbolKind::Function
    ) || (field_is_a_constant && symbol.kind == SymbolKind::Field);
    if !kind_can_hold_a_flag {
        return Some(format!("is {}", symbol.kind.with_article()));
    }

    let declaration = parsed
        .root()
        .descendant_for_byte_range(symbol.full_span.start, symbol.full_span.end)?;

    // Terraform states a variable's type in an argument rather than a grammar field, so
    // read it on its own terms.
    if symbol.language == Language::Hcl {
        return hcl_not_a_flag(declaration, source);
    }

    // The exception made for Java fields is for `static final boolean`.
    if declaration.kind() == "enum_constant" {
        return Some("is an enum constant".into());
    }

    // The bound value first, because it is the stronger statement: `const NAME = "x"`
    // says what `NAME` holds without naming a type at all.
    if let Some(value) = crate::parse::declaration_value(declaration) {
        if let Some(what) = what_the_value_holds(value, source) {
            return Some(what);
        }
    }

    let stated = ["type", "return_type", "result"]
        .iter()
        .find_map(|field| declaration.child_by_field_name(field))
        .and_then(|node| crate::analysis::types::type_text(node, source))?;
    match is_a_boolean_type(&stated) {
        true => None,
        false => Some(format!("is declared `{stated}`")),
    }
}

/// What a bound expression holds, where that rules a boolean out.
fn what_the_value_holds(value: Node<'_>, source: &str) -> Option<String> {
    let held = match value.kind() {
        "true" | "false" | "boolean" | "boolean_literal" | "bool_lit" => return None,
        "string"
        | "string_literal"
        | "interpreted_string_literal"
        | "raw_string_literal"
        | "template_string"
        | "char_literal"
        | "character_literal"
        | "concatenated_string" => "a string",
        "integer"
        | "float"
        | "number"
        | "int_literal"
        | "float_literal"
        | "integer_literal"
        | "decimal_integer_literal"
        | "hex_integer_literal"
        | "decimal_floating_point_literal" => "a number",
        "object"
        | "array"
        | "dictionary"
        | "list"
        | "set"
        | "tuple"
        | "composite_literal"
        | "array_creation_expression"
        | "object_creation_expression" => "a collection",
        "struct_declaration"
        | "enum_declaration"
        | "union_declaration"
        | "error_set_declaration"
        | "slice_type"
        | "pointer_type"
        | "array_type"
        | "generic_type"
        | "builtin_type"
        | "type_identifier" => "a type",
        _ if binds_a_module(value, source) => "a module",
        _ => return None,
    };
    Some(format!("holds {held}"))
}

/// Whether an expression opens another file.
fn binds_a_module(value: Node<'_>, source: &str) -> bool {
    let callee = match value.kind() {
        "builtin_function" => value.named_child(0),
        "call_expression" => value.child_by_field_name("function"),
        _ => return false,
    };
    match callee {
        Some(callee) => matches!(
            Span::from(callee).text(source).trim(),
            "@import" | "require"
        ),
        None => false,
    }
}

/// How each language here spells the boolean type.
fn is_a_boolean_type(stated: &str) -> bool {
    matches!(stated.trim(), "bool" | "boolean" | "Bool" | "Boolean")
}

/// What a Terraform variable block says it holds.
fn hcl_not_a_flag(block: Node<'_>, source: &str) -> Option<String> {
    if let Some(stated) = hcl_block_argument(block, source, "type") {
        return match is_a_boolean_type(&stated) || stated == "any" {
            true => None,
            false => Some(format!("is declared `{stated}`")),
        };
    }
    // With no type written down, the default is the only statement of what it holds.
    let default = hcl_block_argument(block, source, "default")?;
    match default.as_str() {
        "true" | "false" => None,
        _ if default.starts_with('"') => Some("holds a string".into()),
        _ if default.parse::<f64>().is_ok() => Some("holds a number".into()),
        _ if default.starts_with('[') || default.starts_with('{') => {
            Some("holds a collection".into())
        }
        _ => None,
    }
}

/// One argument's value from inside a Terraform block, as written.
fn hcl_block_argument(block: Node<'_>, source: &str, name: &str) -> Option<String> {
    let mut walk = block.walk();
    let body = block
        .named_children(&mut walk)
        .find(|child| child.kind() == "body")?;
    let mut body_walk = body.walk();
    for attribute in body.named_children(&mut body_walk) {
        if attribute.kind() != "attribute" {
            continue;
        }
        let mut attribute_walk = attribute.walk();
        let mut children = attribute.named_children(&mut attribute_walk);
        let key = children.next()?;
        if Span::from(key).text(source).trim() != name {
            continue;
        }
        let value = children.next()?;
        return Some(Span::from(value).text(source).trim().to_string());
    }
    None
}

/// Occurrences of the flag's name that outlived the cascade.
fn remaining_uses(
    sources: &BTreeMap<PathBuf, (Language, String)>,
    flag: &str,
    kind: SymbolKind,
) -> Result<Vec<String>> {
    let parsers = Parsers::new();
    let mut out = Vec::new();

    let snapshot: Vec<(PathBuf, Language, String)> = sources
        .iter()
        .map(|(p, (l, s))| (p.clone(), *l, s.clone()))
        .collect();
    let index = Index::build_from_sources(&snapshot)?;
    let declarations: BTreeSet<(PathBuf, Span)> = index
        .find_symbols(flag, None)
        .into_iter()
        .map(|symbol| (symbol.file.clone(), symbol.name_span))
        .collect();

    for (path, (language, source)) in sources {
        if !source.contains(flag) {
            continue;
        }
        let parsed = parsers.parse(*language, source)?;
        for node in named_nodes(&parsed) {
            if node.child_count() != 0 || !is_name_token(node.kind()) {
                continue;
            }
            let span = Span::from(node);
            if span.text(source) != flag {
                continue;
            }
            if declarations.contains(&(path.clone(), span)) {
                out.push(describe(
                    path,
                    source,
                    span,
                    "the declaration stayed, because a use of it did",
                ));
                continue;
            }
            let reason = match use_site(*language, kind, &parsed, source, span) {
                UseSite::Refuse(reason) | UseSite::Binds(reason) => reason,
                // The tier is the reason: the reader deciding whether to rewrite
                // by hand needs to know how weak the evidence was.
                UseSite::Replace(_) => match index
                    .file(path)
                    .into_iter()
                    .flat_map(|info| info.references.iter())
                    .map(|idx| &index.references[*idx])
                    .find(|r| r.span == span)
                    .map(|r| r.confidence)
                {
                    Some(confidence) => format!(
                        "this use resolved to the flag only as '{}', too weakly to rewrite",
                        confidence.as_str()
                    ),
                    None => {
                        "this use of the flag did not resolve to it firmly enough to rewrite".into()
                    }
                },
            };
            out.push(describe(path, source, span, &reason));
        }
    }
    Ok(out)
}

/// Node kinds that spell a name a flag could be referred to by.
fn is_name_token(kind: &str) -> bool {
    kind.ends_with("identifier") || kind == "variable_name"
}

/// Where the flag's name survives as text after the cascade: strings, comments, YAML keys and
/// values, shell scripts.
fn textual_mentions(
    sources: &BTreeMap<PathBuf, (Language, String)>,
    flag: &str,
) -> Result<Vec<String>> {
    let parsers = Parsers::new();
    let mut mentions = Vec::new();
    for (path, (language, text)) in sources {
        if !text.contains(flag) {
            continue;
        }
        let parsed = parsers.parse(*language, text)?;
        for span in crate::mentions::string_and_comment_spans(&parsed) {
            let haystack = span.text(text);
            for (offset, _) in haystack.match_indices(flag) {
                if !crate::mentions::is_word_boundary(haystack, offset, flag.len()) {
                    continue;
                }
                mentions.push(describe(
                    path,
                    text,
                    Span::new(span.start + offset, span.start + offset + flag.len()),
                    &format!("'{flag}' is still mentioned here, in text no command edits"),
                ));
            }
        }
    }
    Ok(mentions)
}

/// A message about one place in one file, carrying its line number.
fn describe(path: &Path, source: &str, span: Span, message: &str) -> String {
    let line = LineIndex::new(source).line_col(span.start, source).line;
    format!("{}:{line}: {message}", path.display())
}

/// How a language spells a boolean literal.
fn literal_for(language: Language, value: bool) -> &'static str {
    match (language, value) {
        (Language::Python, true) => "True",
        (Language::Python, false) => "False",
        (_, true) => "true",
        (_, false) => "false",
    }
}

/// The bytes a use site's literal must replace.
enum UseSite {
    Replace(Span),
    /// The occurrence binds the name and never reads it, so no literal stands here.
    Binds(String),
    /// Rewriting this use would change what the code means.
    Refuse(String),
}

/// Widen a reference's span to whatever the literal has to stand in for.
fn use_site(
    language: Language,
    definition: SymbolKind,
    parsed: &Parsed,
    source: &str,
    span: Span,
) -> UseSite {
    match language {
        Language::Bash => bash_use_site(parsed, source, span),
        Language::Hcl => hcl_use_site(parsed, source, span),
        _ => general_use_site(definition, parsed, source, span),
    }
}

/// Where a boolean literal can stand, in a language that writes a use as the name.
fn general_use_site(definition: SymbolKind, parsed: &Parsed, source: &str, span: Span) -> UseSite {
    let Some(node) = parsed
        .root()
        .descendant_for_byte_range(span.start, span.end)
    else {
        return UseSite::Replace(span);
    };

    // Before anything about the value, because an import states nothing about one.
    if names_an_import(node) {
        return UseSite::Binds(format!(
            "an import here binds `{}`, which names the flag and does not read it",
            span.text(source)
        ));
    }

    let Some(parent) = node.parent() else {
        return UseSite::Replace(span);
    };

    if names_a_type(node) {
        return UseSite::Refuse(format!(
            "`{}` names a type here, and a boolean is not a type",
            span.text(source)
        ));
    }

    if let Some(call) = call_around(node) {
        // Only a call reads a function.
        return match definition == SymbolKind::Function {
            true => UseSite::Replace(Span::from(call)),
            false => UseSite::Refuse(format!(
                "`{}` calls the flag, and nothing can call a boolean",
                Span::from(call).text(source)
            )),
        };
    }

    // A flag a function holds, named without a call, means the function and not its
    // result.
    if definition == SymbolKind::Function {
        return UseSite::Refuse(format!(
            "`{}` names the flag's function without calling it",
            span.text(source)
        ));
    }

    if reads_into_the_value(node, parent) {
        return UseSite::Refuse(format!(
            "`{}` reads through the flag, and a boolean has nothing to read",
            Span::from(parent).text(source)
        ));
    }

    if let Some(whole) = qualified_use(node, parent) {
        return UseSite::Replace(whole);
    }

    UseSite::Replace(span)
}

/// The span of a use written as a member of something else, `Flags.SHINY`.
fn qualified_use(node: Node<'_>, parent: Node<'_>) -> Option<Span> {
    let member = match parent.kind() {
        "field_expression" | "field_access" | "selector_expression" => {
            parent.child_by_field_name("field")
        }
        "member_expression" => parent.child_by_field_name("property"),
        "attribute" => parent.child_by_field_name("attribute"),
        "scoped_identifier" => parent.child_by_field_name("name"),
        _ => return None,
    };
    if member != Some(node) {
        return None;
    }
    Some(Span::from(parent))
}

/// Is this node part of an import statement?
fn names_an_import(node: Node<'_>) -> bool {
    let mut current = Some(node);
    while let Some(here) = current {
        if here.kind().contains("import") || here.kind() == "use_declaration" {
            return true;
        }
        current = here.parent();
    }
    false
}

/// Whether a use of a name is a use of it as a type.
fn names_a_type(node: Node<'_>) -> bool {
    let mut current = node;
    for _ in 0..4 {
        let Some(parent) = current.parent() else {
            return false;
        };
        for field in ["type", "return_type", "result"] {
            if parent.child_by_field_name(field) == Some(current) {
                return true;
            }
        }
        // Zig writes a struct literal as the type followed by its fields and hangs the
        // type off no field at all.
        if parent.kind() == "struct_initializer" && parent.named_child(0) == Some(current) {
            return true;
        }
        // Keep climbing only while still inside something that spells a type.
        if !parent.kind().contains("type") {
            return false;
        }
        current = parent;
    }
    false
}

/// The call this reference is the target of, where it is one.
fn call_around(node: Node<'_>) -> Option<Node<'_>> {
    let parent = node.parent()?;
    if is_the_callee(node, parent) {
        return Some(parent);
    }
    // In `config.flag()` the reference names the member, and the call calls the member
    // access.
    if member_of(parent) == Some(node) {
        let grandparent = parent.parent()?;
        if is_the_callee(parent, grandparent) {
            return Some(grandparent);
        }
    }
    None
}

fn is_the_callee(node: Node<'_>, parent: Node<'_>) -> bool {
    let callee = match parent.kind() {
        "call_expression" | "call" => parent.child_by_field_name("function"),
        "method_invocation" => parent.child_by_field_name("name"),
        _ => return false,
    };
    callee == Some(node)
}

/// The member a name-access node reads, where the node is one.
fn member_of(node: Node<'_>) -> Option<Node<'_>> {
    match node.kind() {
        "field_expression" => node
            .child_by_field_name("member")
            .or_else(|| node.child_by_field_name("field")),
        "member_expression" => node.child_by_field_name("property"),
        "attribute" => node.child_by_field_name("attribute"),
        "field_access" => node.child_by_field_name("field"),
        "selector_expression" => node.child_by_field_name("field"),
        "scoped_identifier" | "scoped_type_identifier" => node.child_by_field_name("name"),
        _ => None,
    }
}

/// Whether the use reads a member of the flag.
fn reads_into_the_value(node: Node<'_>, parent: Node<'_>) -> bool {
    let base = match parent.kind() {
        "field_expression" => parent
            .child_by_field_name("object")
            .or_else(|| parent.child_by_field_name("value")),
        "member_expression" | "attribute" | "field_access" | "method_invocation" => {
            parent.child_by_field_name("object")
        }
        "selector_expression" => parent.child_by_field_name("operand"),
        "scoped_identifier" | "scoped_type_identifier" => parent.child_by_field_name("path"),
        _ => return false,
    };
    base == Some(node)
}

/// `$FLAG`, `${FLAG}` and `"$FLAG"` all stand for the value; anything more does not.
fn bash_use_site(parsed: &Parsed, source: &str, span: Span) -> UseSite {
    let Some(node) = parsed
        .root()
        .descendant_for_byte_range(span.start, span.end)
    else {
        return UseSite::Replace(span);
    };
    let Some(parent) = node.parent() else {
        return UseSite::Replace(span);
    };

    let expansion = match parent.kind() {
        "simple_expansion" => parent,
        "expansion" => {
            // `${FLAG:-default}`, `${#FLAG}` and `${FLAG[0]}` mean more than the value.
            if parent.child_by_field_name("operator").is_some() || parent.named_child_count() != 1 {
                return UseSite::Refuse(format!(
                    "`{}` is not a plain expansion of the flag",
                    Span::from(parent).text(source)
                ));
            }
            parent
        }
        _ => {
            if inside_expansion(node) {
                return UseSite::Refuse(
                    "the flag sits inside a compound expansion, which a literal cannot replace"
                        .into(),
                );
            }
            // An arithmetic `(( FLAG ))` or an assignment target names the variable
            // directly, with no sigil to keep.
            return UseSite::Replace(span);
        }
    };

    // `"$FLAG"` on its own is the quoted value.
    if let Some(string) = expansion.parent() {
        let quoted = format!("\"{}\"", Span::from(expansion).text(source));
        if string.kind() == "string" && Span::from(string).text(source) == quoted {
            return UseSite::Replace(Span::from(string));
        }
    }
    UseSite::Replace(Span::from(expansion))
}

/// Is this node wrapped in an expansion whose parent is not the expansion itself?
fn inside_expansion(node: Node<'_>) -> bool {
    let mut current = node.parent();
    for _ in 0..3 {
        let Some(parent) = current else { return false };
        if matches!(parent.kind(), "expansion" | "simple_expansion") {
            return true;
        }
        current = parent.parent();
    }
    false
}

/// `var.flag` is one expression written as two segments; the literal replaces both.
fn hcl_use_site(parsed: &Parsed, source: &str, span: Span) -> UseSite {
    let Some(node) = parsed
        .root()
        .descendant_for_byte_range(span.start, span.end)
    else {
        return UseSite::Replace(span);
    };
    let Some(get_attr) = node.parent().filter(|p| p.kind() == "get_attr") else {
        return UseSite::Replace(span);
    };
    let Some(expression) = get_attr.parent().filter(|p| p.kind() == "expression") else {
        return UseSite::Refuse("the flag does not appear as a `var.NAME` traversal".into());
    };

    let mut cursor = expression.walk();
    let parts: Vec<Node> = expression.named_children(&mut cursor).collect();
    let namespace = parts
        .first()
        .copied()
        .filter(|p| p.kind() == "variable_expr");
    let Some(namespace) = namespace else {
        return UseSite::Refuse("the flag does not appear as a `var.NAME` traversal".into());
    };
    // A longer traversal, `var.flag.attr`, `var.flag[0]`, reads *into* the value
    // instead of being it, and a boolean has nothing to read.
    if parts.len() != 2 || parts[1] != get_attr {
        return UseSite::Refuse(format!(
            "`{}` reads through the flag instead of using its value",
            Span::from(expression).text(source)
        ));
    }
    match Span::from(namespace).text(source) {
        "var" | "local" => UseSite::Replace(Span::from(expression)),
        other => UseSite::Refuse(format!("`{other}` is not a Terraform value namespace")),
    }
}

/// Collapse `if true { … } else { … }` to the branch that survives.
fn simplify_constants(
    sources: &BTreeMap<PathBuf, (Language, String)>,
    originals: &BTreeMap<PathBuf, (Language, String)>,
) -> Result<Vec<Change>> {
    let parsers = Parsers::new();
    let mut changes = Vec::new();

    let indexed = hcl_indexed_addresses(sources)?;

    for (path, (language, source)) in sources {
        if !supports_cascade(*language) {
            continue;
        }
        let parsed = parsers.parse(*language, source)?;
        let context = Context {
            original: originals.get(path).map(|(_, s)| s.as_str()).unwrap_or(""),
            indexed: &indexed,
        };
        let mut found = constant_conditionals(&parsed, source, *language, &context).changes;
        // One change per file per round: the first shifts every span after it, and the
        // next round re-parses.
        if let Some(change) = found.pop() {
            changes.push((path.clone(), change.0, change.1));
        }
    }
    Ok(changes)
}

/// What the collapse step needs to know beyond the file in front of it.
struct Context<'a> {
    /// The file as it stood before the cascade started.
    original: &'a str,
    /// Resource addresses read with an index or a splat, module-wide.
    indexed: &'a BTreeSet<String>,
}

/// What one file's collapse pass found: the rewrites, and the places it gave up.
#[derive(Debug, Default)]
struct Collapse {
    changes: Vec<(Span, String)>,
    refusals: Vec<(Span, String)>,
}

/// Conditionals whose test is a boolean literal, with their replacement text.
fn constant_conditionals(
    parsed: &Parsed,
    source: &str,
    language: Language,
    context: &Context<'_>,
) -> Collapse {
    match language {
        Language::Zig => zig_conditionals(parsed, source),
        Language::Bash => bash_conditionals(parsed, source),
        Language::Hcl => hcl_constants(parsed, source, context),
        _ => generic_conditionals(parsed, source),
    }
}

/// Every named node, outermost first.
fn named_nodes<'a>(parsed: &'a Parsed) -> Vec<Node<'a>> {
    let mut cursor = parsed.root().walk();
    let mut stack = vec![parsed.root()];
    let mut out = Vec::new();
    while let Some(node) = stack.pop() {
        stack.extend(node.named_children(&mut cursor));
        out.push(node);
    }
    out
}

/// The truth value a boolean literal spells, in any of the supported languages.
fn boolean_literal(text: &str) -> Option<bool> {
    // Java's `if` names its condition as the *parenthesised* expression, brackets and all, so
    // the literal arrives as `(true)`.
    let mut text = text.trim();
    while let Some(inner) = text.strip_prefix('(').and_then(|t| t.strip_suffix(')')) {
        text = inner.trim();
    }
    // A flag read under negation substitutes into `if !true` or `if not True`, which is as
    // constant as the literal itself.
    if let Some(rest) = text.strip_prefix('!') {
        return boolean_literal(rest).map(|truth| !truth);
    }
    if let Some(rest) = text
        .strip_prefix("not")
        .filter(|rest| rest.starts_with([' ', '\t', '(']))
    {
        return boolean_literal(rest).map(|truth| !truth);
    }
    match text {
        "true" | "True" => Some(true),
        "false" | "False" => Some(false),
        _ => None,
    }
}

/// Grammars that name an `if`'s three parts as fields: Rust, Go, TypeScript, Python.
fn generic_conditionals(parsed: &Parsed, source: &str) -> Collapse {
    let mut out = Collapse::default();

    for node in named_nodes(parsed) {
        if !node.kind().starts_with("if_") {
            continue;
        }
        let Some(condition) = node.child_by_field_name("condition") else {
            continue;
        };
        let Some(truth) = boolean_literal(Span::from(condition).text(source)) else {
            continue;
        };

        let Some(consequence) = node.child_by_field_name("consequence") else {
            continue;
        };
        let alternative = node.child_by_field_name("alternative");

        let kept = if truth {
            Some(consequence)
        } else {
            alternative.map(else_body)
        };

        let span = Span::from(node);
        let indent = crate::edit::line_indent(source, span.start);
        let replacement = match kept {
            // The surviving branch loses a level of nesting.
            Some(branch) => dedent_block(Span::from(branch), source, &indent),
            // A false `if` with no else leaves nothing behind.
            None => String::new(),
        };
        // A branch that always leaves takes the rest of its block with it.
        let span = match kept.filter(|branch| always_leaves(*branch)) {
            Some(_) => Span::new(span.start, trailing_end(node)),
            None => span,
        };
        out.changes.push((span, replacement));
    }
    out
}

/// Does this block always leave, so nothing after it can run?
fn always_leaves(block: Node<'_>) -> bool {
    // Go puts a `statement_list` between a block and its statements, so the
    // block's own last child is that wrapper and never the `return` inside it.
    let mut block = block;
    loop {
        let mut cursor = block.walk();
        let Some(last) = block.named_children(&mut cursor).last() else {
            return false;
        };
        if crate::refactor::is_statement_container(last.kind()) {
            block = last;
            continue;
        }
        // Rust spells a return as an expression, wrapped in a statement.
        let last = match last.kind() {
            "expression_statement" => last.named_child(0).unwrap_or(last),
            _ => last,
        };
        let kind = last.kind();
        return kind.starts_with("return")
            || kind.starts_with("break")
            || kind.starts_with("continue")
            || kind.starts_with("throw");
    }
}

/// Where this node's block ends, counting every sibling after it.
fn trailing_end(node: Node<'_>) -> usize {
    // Rust's `if` is an expression, wrapped in a statement.
    let mut node = node;
    while node
        .parent()
        .is_some_and(|p| p.kind() == "expression_statement")
    {
        node = node.parent().expect("just checked");
    }
    let mut end = node.end_byte();
    let mut next = node.next_named_sibling();
    while let Some(sibling) = next {
        end = sibling.end_byte();
        next = sibling.next_named_sibling();
    }
    end
}

/// The block an else clause wraps.
fn else_body(alternative: Node<'_>) -> Node<'_> {
    let mut cursor = alternative.walk();
    let inner = alternative
        .named_children(&mut cursor)
        .find(|c| c.kind().contains("block"));
    inner.unwrap_or(alternative)
}

/// Zig `if`s, in both the statement and the expression spelling.
fn zig_conditionals(parsed: &Parsed, source: &str) -> Collapse {
    let mut out = Collapse::default();

    for node in named_nodes(parsed) {
        if !matches!(node.kind(), "if_statement" | "if_expression") {
            continue;
        }
        let Some(condition) = node.child_by_field_name("condition") else {
            continue;
        };
        let Some(truth) = boolean_literal(Span::from(condition).text(source)) else {
            continue;
        };

        let mut cursor = node.walk();
        let children: Vec<Node> = node.children(&mut cursor).collect();

        if children.iter().any(|c| c.kind() == "payload") {
            out.refusals.push((
                Span::from(node),
                "this `if` captures its condition's payload, which a boolean has none of".into(),
            ));
            continue;
        }

        if node.kind() == "if_expression" {
            match zig_expression_branches(&children, truth) {
                Ok(kept) => out
                    .changes
                    .push((Span::from(node), Span::from(kept).text(source).to_string())),
                Err(reason) => out.refusals.push((Span::from(node), reason)),
            }
            continue;
        }

        let Some(body) = node.child_by_field_name("body") else {
            continue;
        };
        let alternative = children
            .iter()
            .find(|c| c.kind() == "else_clause")
            .and_then(|c| c.child_by_field_name("alternative"));

        let kept = if truth { Some(body) } else { alternative };
        let span = Span::from(node);
        let indent = crate::edit::line_indent(source, span.start);
        let terminated = span.text(source).trim_end().ends_with(';');
        let replacement = match kept {
            None => String::new(),
            Some(branch) => zig_branch_text(branch, source, &indent, terminated),
        };
        // A branch that always leaves takes the rest of its block with it.
        let span = match kept.filter(|branch| always_leaves(*branch)) {
            Some(_) => Span::new(span.start, trailing_end(node)),
            None => span,
        };
        out.changes.push((span, replacement));
    }
    out
}

/// The branch a constant `if` expression keeps.
fn zig_expression_branches<'a>(children: &[Node<'a>], truth: bool) -> Result<Node<'a>, String> {
    let close = children
        .iter()
        .position(|c| c.kind() == ")")
        .ok_or_else(|| "this `if` expression has no parenthesised condition".to_string())?;
    let otherwise = children
        .iter()
        .position(|c| c.kind() == "else")
        .ok_or_else(|| {
            "this `if` expression has no `else`, so it has no value to keep".to_string()
        })?;

    let consequence: Vec<&Node> = children[close + 1..otherwise]
        .iter()
        .filter(|c| c.is_named())
        .collect();
    let alternative: Vec<&Node> = children[otherwise + 1..]
        .iter()
        .filter(|c| c.is_named())
        .collect();

    let kept = if truth { &consequence } else { &alternative };
    match kept.as_slice() {
        [only] => Ok(**only),
        _ => Err("this `if` expression's branches are not single expressions".into()),
    }
}

/// A Zig branch as it reads once the `if` around it is gone.
fn zig_branch_text(branch: Node<'_>, source: &str, indent: &str, terminated: bool) -> String {
    if let Some(block) = zig_block(branch) {
        return dedent_block(Span::from(block), source, indent);
    }
    let text = Span::from(branch).text(source).trim();
    if terminated && !text.ends_with(';') {
        format!("{text};")
    } else {
        text.to_string()
    }
}

/// The block a branch wraps, if it is braced and unlabelled.
fn zig_block(node: Node<'_>) -> Option<Node<'_>> {
    if node.kind() == "block" {
        return Some(node);
    }
    if !matches!(node.kind(), "block_expression" | "labeled_statement") {
        return None;
    }
    let mut cursor = node.walk();
    let children: Vec<Node> = node.named_children(&mut cursor).collect();
    if children.iter().any(|c| c.kind() == "block_label") {
        return None;
    }
    children.into_iter().find(|c| c.kind() == "block")
}

/// Shell `if`s whose test provably succeeds or fails.
fn bash_conditionals(parsed: &Parsed, source: &str) -> Collapse {
    let mut out = Collapse::default();

    for node in named_nodes(parsed) {
        if node.kind() != "if_statement" {
            continue;
        }
        let Some(condition) = node.child_by_field_name("condition") else {
            continue;
        };
        let truth = match bash_truth(condition, source) {
            Ok(Some(truth)) => truth,
            Ok(None) => continue,
            Err(reason) => {
                out.refusals.push((Span::from(condition), reason));
                continue;
            }
        };

        let mut cursor = node.walk();
        let children: Vec<Node> = node.children(&mut cursor).collect();
        let has_elif = children.iter().any(|c| c.kind() == "elif_clause");
        if has_elif && !truth {
            out.refusals.push((
                Span::from(node),
                "this `if` is false but has an `elif`, and promoting an `elif` to an `if` is \
                 not a rewrite this can do"
                    .into(),
            ));
            continue;
        }

        let Some(parts) = bash_if_parts(&children, node) else {
            out.refusals.push((
                Span::from(node),
                "this `if` has no `then`, so nothing marks off its branches".into(),
            ));
            continue;
        };

        let kept = if truth { Some(parts.0) } else { parts.1 };
        let span = Span::from(node);
        let indent = crate::edit::line_indent(source, span.start);
        let replacement = match kept {
            None => String::new(),
            Some(branch) => dedent_to(branch.text(source), indent.as_str()),
        };
        out.changes.push((span, replacement));
    }
    out
}

/// A shell `if`'s two branches, delimited by its keywords.
fn bash_if_parts<'a>(children: &[Node<'a>], node: Node<'a>) -> Option<(Span, Option<Span>)> {
    let then_end = children
        .iter()
        .find(|c| c.kind() == "then")
        .map(|c| c.end_byte())?;
    let clause = children
        .iter()
        .find(|c| matches!(c.kind(), "else_clause" | "elif_clause"));
    let fi_start = children
        .iter()
        .find(|c| c.kind() == "fi")
        .map(|c| c.start_byte());

    let consequence_end = clause
        .map(|c| c.start_byte())
        .or(fi_start)
        .unwrap_or(node.end_byte());

    let alternative = children
        .iter()
        .find(|c| c.kind() == "else_clause")
        .and_then(|clause| {
            let mut cursor = clause.walk();
            let start = clause
                .children(&mut cursor)
                .find(|c| c.kind() == "else")
                .map(|c| c.end_byte())?;
            Some(Span::new(start, clause.end_byte()))
        });

    Some((Span::new(then_end, consequence_end), alternative))
}

/// Whether a shell condition provably succeeds.
fn bash_truth(condition: Node<'_>, source: &str) -> Result<Option<bool>, String> {
    let text = Span::from(condition).text(source).trim();
    if let Some(truth) = bash_evaluate(condition, source) {
        return Ok(Some(truth));
    }
    let mentions_literal = text
        .split(|c: char| !(c.is_alphanumeric() || c == '_'))
        .any(|word| word == "true" || word == "false");
    if !mentions_literal {
        return Ok(None);
    }
    if bash_single_operand(condition, source) {
        return Err(format!(
            "`{text}` asks whether one operand is a non-empty string, which `false` also is; \
             collapsing it would change what the script does"
        ));
    }
    Err(format!("`{text}` is not a provably constant shell test"))
}

/// The outcome of a shell condition, when the text alone decides it.
fn bash_evaluate(condition: Node<'_>, source: &str) -> Option<bool> {
    match condition.kind() {
        "command" => {
            let name = condition.child_by_field_name("name")?;
            let mut cursor = condition.walk();
            let arguments: Vec<Node> = condition
                .children_by_field_name("argument", &mut cursor)
                .collect();
            match Span::from(name).text(source) {
                "true" if arguments.is_empty() => Some(true),
                "false" if arguments.is_empty() => Some(false),
                "test" => bash_test(&arguments, source, false),
                _ => None,
            }
        }
        "test_command" => {
            let mut cursor = condition.walk();
            let children: Vec<Node> = condition.children(&mut cursor).collect();
            // `[[ … ]]` matches its right operand as a pattern; `[ … ]` does not.
            let patterned = children.first().is_some_and(|c| c.kind() == "[[");
            let inner = children.iter().find(|c| c.is_named())?;
            bash_test_expression(*inner, source, patterned)
        }
        _ => None,
    }
}

/// Does this condition test exactly one operand?
fn bash_single_operand(condition: Node<'_>, source: &str) -> bool {
    match condition.kind() {
        "test_command" => {
            let mut cursor = condition.walk();
            let named: Vec<Node> = condition.named_children(&mut cursor).collect();
            named.len() == 1 && bash_literal(named[0], source).is_some()
        }
        "command" => {
            let Some(name) = condition.child_by_field_name("name") else {
                return false;
            };
            if Span::from(name).text(source) != "test" {
                return false;
            }
            let mut cursor = condition.walk();
            let arguments: Vec<Node> = condition
                .children_by_field_name("argument", &mut cursor)
                .collect();
            arguments.len() == 1 && bash_literal(arguments[0], source).is_some()
        }
        _ => false,
    }
}

/// `test a = b` and `test -n a`, as a list of argument nodes.
fn bash_test(arguments: &[Node<'_>], source: &str, patterned: bool) -> Option<bool> {
    match arguments {
        [left, operator, right] => bash_compare(
            &bash_literal(*left, source)?,
            Span::from(*operator).text(source),
            &bash_literal(*right, source)?,
            patterned,
        ),
        [operator, operand] => bash_unary(
            Span::from(*operator).text(source),
            &bash_literal(*operand, source)?,
        ),
        _ => None,
    }
}

/// The expression inside `[ … ]` or `[[ … ]]`.
fn bash_test_expression(node: Node<'_>, source: &str, patterned: bool) -> Option<bool> {
    match node.kind() {
        "binary_expression" => bash_compare(
            &bash_literal(node.child_by_field_name("left")?, source)?,
            Span::from(node.child_by_field_name("operator")?).text(source),
            &bash_literal(node.child_by_field_name("right")?, source)?,
            patterned,
        ),
        "unary_expression" => {
            let mut cursor = node.walk();
            let children: Vec<Node> = node.children(&mut cursor).collect();
            let [operator, operand] = children.as_slice() else {
                return None;
            };
            bash_unary(
                Span::from(*operator).text(source),
                &bash_literal(*operand, source)?,
            )
        }
        _ => None,
    }
}

fn bash_compare(left: &str, operator: &str, right: &str, patterned: bool) -> Option<bool> {
    // Leave a pattern for a person: inside `[[ ]]` the right operand globs, and matching
    // one differs from string equality.
    if patterned && right.contains(['*', '?', '[']) {
        return None;
    }
    match operator {
        "=" | "==" => Some(left == right),
        "!=" => Some(left != right),
        _ => None,
    }
}

fn bash_unary(operator: &str, operand: &str) -> Option<bool> {
    match operator {
        "-n" => Some(!operand.is_empty()),
        "-z" => Some(operand.is_empty()),
        _ => None,
    }
}

/// The string a node denotes, when it denotes one without running anything.
fn bash_literal(node: Node<'_>, source: &str) -> Option<String> {
    match node.kind() {
        "word" | "number" => Some(Span::from(node).text(source).to_string()),
        "raw_string" => Some(Span::from(node).text(source).trim_matches('\'').to_string()),
        "string" => {
            let mut cursor = node.walk();
            let children: Vec<Node> = node.named_children(&mut cursor).collect();
            // An expansion or a command substitution inside the quotes is a value
            // only the shell knows.
            if children.iter().any(|c| c.kind() != "string_content") {
                return None;
            }
            Some(
                children
                    .iter()
                    .map(|c| Span::from(*c).text(source))
                    .collect::<String>(),
            )
        }
        _ => None,
    }
}

/// Terraform's flag is a boolean `variable`, and its conditionals are expressions.
fn hcl_constants(parsed: &Parsed, source: &str, context: &Context<'_>) -> Collapse {
    let mut out = Collapse::default();
    let before = hcl_arguments(context.original);

    let mut blocks = Vec::new();
    let mut attributes = Vec::new();
    let mut conditionals = Vec::new();

    for node in named_nodes(parsed) {
        match node.kind() {
            "conditional" => {
                let mut cursor = node.walk();
                let parts: Vec<Node> = node.named_children(&mut cursor).collect();
                let [condition, consequence, alternative] = parts.as_slice() else {
                    continue;
                };
                let Some(truth) = boolean_literal(Span::from(*condition).text(source)) else {
                    continue;
                };
                let kept = if truth { consequence } else { alternative };
                conditionals.push((
                    Span::from(node),
                    Span::from(*kept).text(source).trim().to_string(),
                ));
            }
            "attribute" => {
                let mut cursor = node.walk();
                let parts: Vec<Node> = node.named_children(&mut cursor).collect();
                let (Some(name), Some(value)) = (parts.first(), parts.get(1)) else {
                    continue;
                };
                let name = Span::from(*name).text(source);
                if !matches!(name, "count" | "for_each") {
                    continue;
                }
                let value = Span::from(*value).text(source).trim().to_string();
                let key = hcl_argument_key(node, source, name);
                if before.get(&key) == Some(&value) {
                    continue;
                }
                let Some(block) = enclosing_block(node) else {
                    continue;
                };
                match hcl_instance_count(name, &value) {
                    Some(0) => blocks.push((Span::from(block), String::new())),
                    Some(1) if name == "count" => {
                        match count_removable(block, node, source, context) {
                            Ok(()) => attributes.push((Span::from(node), String::new())),
                            Err(reason) => out.refusals.push((Span::from(node), reason)),
                        }
                    }
                    _ => {}
                }
            }
            _ => {}
        }
    }

    // Apply one per round, last first: the conditionals collapse before anything reads
    // the `count` they feed.
    out.changes.extend(blocks);
    out.changes.extend(attributes);
    out.changes.extend(conditionals);
    out
}

/// May this cascade delete a `count` of 1?
fn count_removable(
    block: Node<'_>,
    attribute: Node<'_>,
    source: &str,
    context: &Context<'_>,
) -> Result<(), String> {
    let body = Span::from(block).text(source);
    let argument = Span::from(attribute).text(source);
    if body.replace(argument, "").contains("count.index") {
        return Err(
            "`count.index` appears here, and it only exists while the resource has a `count`"
                .into(),
        );
    }

    let address = hcl_resource_address(block, source);
    if address
        .as_deref()
        .is_some_and(|a| context.indexed.contains(a))
    {
        return Err(format!(
            "something reads `{}` with an index, which only a resource with a `count` has",
            address.unwrap_or_default()
        ));
    }
    Ok(())
}

/// How many instances a literal `count` or `for_each` produces, when it is literal.
fn hcl_instance_count(name: &str, value: &str) -> Option<usize> {
    match name {
        "count" => value.parse::<usize>().ok(),
        // An empty collection is the only `for_each` whose size the text alone gives.
        "for_each" if value == "{}" || value == "[]" => Some(0),
        _ => None,
    }
}

/// `count` and `for_each` as they stood before the cascade, by block address.
fn hcl_arguments(source: &str) -> BTreeMap<String, String> {
    let mut out = BTreeMap::new();
    if source.is_empty() {
        return out;
    }
    let Ok(parsed) = Parsers::new().parse(Language::Hcl, source) else {
        return out;
    };
    for node in named_nodes(&parsed) {
        if node.kind() != "attribute" {
            continue;
        }
        let mut cursor = node.walk();
        let parts: Vec<Node> = node.named_children(&mut cursor).collect();
        let (Some(name), Some(value)) = (parts.first(), parts.get(1)) else {
            continue;
        };
        let name = Span::from(*name).text(source);
        if !matches!(name, "count" | "for_each") {
            continue;
        }
        out.insert(
            hcl_argument_key(node, source, name),
            Span::from(*value).text(source).trim().to_string(),
        );
    }
    out
}

/// An address that names one argument of one block, stable across the cascade.
fn hcl_argument_key(node: Node<'_>, source: &str, name: &str) -> String {
    let mut path = Vec::new();
    let mut current = node.parent();
    while let Some(parent) = current {
        if parent.kind() == "block" {
            path.push(hcl_block_address(parent, source));
        }
        current = parent.parent();
    }
    path.reverse();
    path.push(name.to_string());
    path.join("/")
}

/// A block's header, its type keyword and labels, as a dotted address.
fn hcl_block_address(block: Node<'_>, source: &str) -> String {
    let mut cursor = block.walk();
    let mut parts = Vec::new();
    for child in block.named_children(&mut cursor) {
        match child.kind() {
            "identifier" => parts.push(Span::from(child).text(source).to_string()),
            "string_lit" => parts.push(hcl_label(child, source)),
            _ => break,
        }
    }
    parts.join(".")
}

/// The text inside a label's quotes.
fn hcl_label(string_lit: Node<'_>, source: &str) -> String {
    let mut cursor = string_lit.walk();
    let inner = string_lit
        .named_children(&mut cursor)
        .find(|c| c.kind() == "template_literal")
        .map(|c| Span::from(c).text(source).to_string());
    inner.unwrap_or_default()
}

/// The block a node sits directly inside.
fn enclosing_block<'a>(node: Node<'a>) -> Option<Node<'a>> {
    let mut current = node.parent();
    while let Some(parent) = current {
        if parent.kind() == "block" {
            return Some(parent);
        }
        current = parent.parent();
    }
    None
}

/// The Terraform address a two-label block declares, as `type.name`.
fn hcl_resource_address(block: Node<'_>, source: &str) -> Option<String> {
    let mut cursor = block.walk();
    let labels: Vec<String> = block
        .named_children(&mut cursor)
        .take_while(|c| matches!(c.kind(), "identifier" | "string_lit"))
        .filter(|c| c.kind() == "string_lit")
        .map(|c| hcl_label(c, source))
        .collect();
    (labels.len() == 2).then(|| labels.join("."))
}

/// Terraform addresses, `type.name`, declared by the two-label blocks in a file.
fn hcl_addresses(parsed: &Parsed, source: &str) -> BTreeSet<String> {
    named_nodes(parsed)
        .into_iter()
        .filter(|n| n.kind() == "block")
        .filter_map(|n| hcl_resource_address(n, source))
        .collect()
}

/// Resource addresses read with an index or a splat, across the whole workspace.
fn hcl_indexed_addresses(
    sources: &BTreeMap<PathBuf, (Language, String)>,
) -> Result<BTreeSet<String>> {
    let parsers = Parsers::new();
    let mut out = BTreeSet::new();

    for (language, source) in sources.values() {
        if *language != Language::Hcl {
            continue;
        }
        let parsed = parsers.parse(*language, source)?;
        for node in named_nodes(&parsed) {
            if node.kind() != "expression" {
                continue;
            }
            let mut cursor = node.walk();
            let parts: Vec<Node> = node.named_children(&mut cursor).collect();
            let [root, step, subscript, ..] = parts.as_slice() else {
                continue;
            };
            if root.kind() != "variable_expr"
                || step.kind() != "get_attr"
                || !matches!(subscript.kind(), "index" | "splat")
            {
                continue;
            }
            out.insert(format!(
                "{}.{}",
                Span::from(*root).text(source),
                Span::from(*step).text(source).trim_start_matches('.')
            ));
        }
    }
    Ok(out)
}

/// Addresses still standing after the cascade deleted the resource they name.
fn dangling_resource_uses(
    sources: &BTreeMap<PathBuf, (Language, String)>,
    originals: &BTreeMap<PathBuf, (Language, String)>,
) -> Result<Vec<String>> {
    let parsers = Parsers::new();
    let mut before = BTreeSet::new();
    let mut after = BTreeSet::new();

    for (path, (language, source)) in originals {
        if *language != Language::Hcl {
            continue;
        }
        before.extend(hcl_addresses(&parsers.parse(*language, source)?, source));
        let current = sources.get(path).map(|(_, s)| s.as_str()).unwrap_or("");
        after.extend(hcl_addresses(&parsers.parse(*language, current)?, current));
    }

    let removed: BTreeSet<&String> = before.difference(&after).collect();
    if removed.is_empty() {
        return Ok(Vec::new());
    }

    let mut out = Vec::new();
    for (path, (language, source)) in sources {
        if *language != Language::Hcl {
            continue;
        }
        let parsed = parsers.parse(*language, source)?;
        for node in named_nodes(&parsed) {
            if node.kind() != "expression" {
                continue;
            }
            let mut cursor = node.walk();
            let parts: Vec<Node> = node.named_children(&mut cursor).collect();
            let (Some(root), Some(step)) = (parts.first(), parts.get(1)) else {
                continue;
            };
            if root.kind() != "variable_expr" || step.kind() != "get_attr" {
                continue;
            }
            let address = format!(
                "{}.{}",
                Span::from(*root).text(source),
                Span::from(*step).text(source).trim_start_matches('.')
            );
            if removed.contains(&address) {
                out.push(describe(
                    path,
                    source,
                    Span::from(node),
                    &format!("{address} no longer exists; this reference dangles"),
                ));
            }
        }
    }
    Ok(out)
}

/// Everything the cascade substituted into but could not finish collapsing.
fn unfinished_work(
    sources: &BTreeMap<PathBuf, (Language, String)>,
    originals: &BTreeMap<PathBuf, (Language, String)>,
) -> Result<Vec<String>> {
    let parsers = Parsers::new();
    let indexed = hcl_indexed_addresses(sources)?;
    let mut out = Vec::new();

    for (path, (language, source)) in sources {
        let original = originals.get(path).map(|(_, s)| s.as_str()).unwrap_or("");
        if original == source {
            continue;
        }
        if !supports_cascade(*language) {
            out.push(format!(
                "{}: the flag gave up its value, and nothing collapses {language} conditionals",
                path.display()
            ));
            continue;
        }
        let parsed = parsers.parse(*language, source)?;
        let context = Context {
            original,
            indexed: &indexed,
        };
        for (span, reason) in constant_conditionals(&parsed, source, *language, &context).refusals {
            out.push(describe(path, source, span, &reason));
        }
    }
    Ok(out)
}

/// Delete symbols that nothing references any more.
fn remove_orphans(
    index: &Index,
    sources: &BTreeMap<PathBuf, (Language, String)>,
    flag: &str,
    initially_used: &HashSet<(String, PathBuf)>,
) -> Result<Vec<Change>> {
    let mut changes = Vec::new();

    for symbol in &index.symbols {
        if symbol.name == flag || symbol.exported {
            continue;
        }
        // It has to have lost a use, not have none.
        if !initially_used.contains(&(symbol.name.clone(), symbol.file.clone())) {
            continue;
        }
        if !matches!(symbol.kind, SymbolKind::Function | SymbolKind::Constant) {
            continue;
        }
        // Entry points and anything still referenced stay.
        if index.has_references(symbol.id) {
            continue;
        }
        if symbol.name == "main" || symbol.name.starts_with("test") {
            continue;
        }
        if !sources.contains_key(&symbol.file) {
            continue;
        }
        changes.push((symbol.file.clone(), symbol.full_span, String::new()));
        // One per round: the next round re-indexes and finds whatever this exposed.
        break;
    }
    Ok(changes)
}

/// Imports the cascade's own edits left with nothing naming them.
fn remove_dead_imports(
    index: &Index,
    sources: &BTreeMap<PathBuf, (Language, String)>,
    already_dead: &HashSet<(PathBuf, Span)>,
) -> Result<Vec<Change>> {
    for (path, (_, text)) in sources {
        for (span, replacement) in dead_import_spans(index, path, text) {
            if already_dead.contains(&(path.clone(), span)) {
                continue;
            }
            // One per round: the next round re-indexes and finds whatever this exposed.
            return Ok(vec![(path.clone(), span, replacement)]);
        }
    }
    Ok(Vec::new())
}

/// What `fr imports` would make of this file's import statements, region by region.
fn dead_import_spans(index: &Index, path: &Path, source: &str) -> Vec<(Span, String)> {
    let Ok(plan) = crate::refactor::imports::plan_in(index, path, source) else {
        return Vec::new();
    };
    plan.replacements
}

/// The statements inside a block, moved out one indentation level.
fn dedent_block(block: Span, source: &str, indent: &str) -> String {
    let text = block.text(source);
    let trimmed = text.trim();
    let inner = if trimmed.starts_with('{') && trimmed.ends_with('}') {
        let lead = text.len() - text.trim_start().len();
        let trail = text.len() - text.trim_end().len();
        &source[block.start + lead + 1..block.end - trail - 1]
    } else {
        text
    };
    dedent_to(inner, indent)
}

/// Re-indent a run of lines so its shallowest line sits at `indent`.
fn dedent_to(text: &str, indent: &str) -> String {
    let lines: Vec<&str> = text
        .lines()
        .skip_while(|l| l.trim().is_empty())
        .collect::<Vec<_>>()
        .into_iter()
        .rev()
        .skip_while(|l| l.trim().is_empty())
        .collect::<Vec<_>>()
        .into_iter()
        .rev()
        .collect();

    let common = lines
        .iter()
        .filter(|l| !l.trim().is_empty())
        .map(|l| l.len() - l.trim_start().len())
        .min()
        .unwrap_or(0);

    let body = lines
        .iter()
        .map(|line| {
            if line.trim().is_empty() {
                String::new()
            } else {
                format!("{indent}{}", &line[common..])
            }
        })
        .collect::<Vec<_>>()
        .join("\n");

    body.trim_start().to_string()
}

/// Apply changes to the in-memory sources, tidying the lines they empty.
fn apply_in_memory(
    sources: &mut BTreeMap<PathBuf, (Language, String)>,
    changes: &[Change],
) -> Result<()> {
    let mut by_file: BTreeMap<&PathBuf, Vec<&Change>> = BTreeMap::new();
    for change in changes {
        by_file.entry(&change.0).or_default().push(change);
    }

    for (path, mut file_changes) in by_file {
        let Some((_, source)) = sources.get_mut(path) else {
            continue;
        };
        file_changes.sort_by_key(|(_, span, _)| span.start);

        // Overlapping changes have no defined result; keep the first of each pair.
        let mut applied: Vec<&Change> = Vec::new();
        for change in file_changes {
            if applied
                .last()
                .is_some_and(|(_, previous, _)| previous.overlaps(change.1))
            {
                continue;
            }
            applied.push(change);
        }

        let mut updated = source.clone();
        for (_, span, replacement) in applied.iter().rev() {
            // Deleting a statement should take its line, not leave a blank one.
            let range = if replacement.is_empty() {
                // A definition usually spans several lines, so the deletion covers all of them.
                let first = crate::edit::full_line_span(&updated, span.start);
                let last = crate::edit::full_line_span(
                    &updated,
                    span.end.saturating_sub(1).max(span.start),
                );
                let whole = Span::new(first.start, last.end.max(span.end));
                if whole.text(&updated).trim() == span.text(&updated).trim() {
                    widen_to_blank_separator(&updated, whole)
                } else {
                    *span
                }
            } else {
                *span
            };
            updated.replace_range(range.start..range.end, replacement);
        }
        *source = updated;
    }
    Ok(())
}

/// Extend a whole-line deletion over the blank line that separated it from its neighbour, so
/// removing a definition does not leave a widening gap behind.
fn widen_to_blank_separator(source: &str, line: Span) -> Span {
    let preceded_by_blank = line.start == 0 || {
        // Strip exactly the newline that ends the previous line, then look at that line.
        let before = &source[..line.start];
        let previous = before.strip_suffix('\n').unwrap_or(before);
        previous
            .rsplit('\n')
            .next()
            .is_none_or(|l| l.trim().is_empty())
    };
    if !preceded_by_blank {
        return line;
    }

    let rest = &source[line.end..];
    let Some(next_end) = rest.find('\n').map(|i| line.end + i + 1) else {
        return line;
    };
    if source[line.end..next_end].trim().is_empty() {
        Span::new(line.start, next_end)
    } else {
        line
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn collapse(language: Language, source: &str) -> Collapse {
        collapse_against(language, source, "")
    }

    fn collapse_against(language: Language, source: &str, original: &str) -> Collapse {
        let parsed = Parsers::new().parse(language, source).unwrap();
        let indexed = BTreeSet::new();
        let context = Context {
            original,
            indexed: &indexed,
        };
        constant_conditionals(&parsed, source, language, &context)
    }

    #[test]
    fn a_deletion_takes_the_blank_line_that_separated_it() {
        let source = "a\n\nDELETED\n\nb\n";
        let line = crate::edit::full_line_span(source, source.find("DELETED").unwrap());
        let widened = widen_to_blank_separator(source, line);
        assert_eq!(widened.text(source), "DELETED\n\n");
    }

    #[test]
    fn a_deletion_leaves_a_separator_that_belongs_to_the_survivor() {
        // No blank line before it, so the blank after belongs to what remains.
        let source = "a\nDELETED\n\nb\n";
        let line = crate::edit::full_line_span(source, source.find("DELETED").unwrap());
        let widened = widen_to_blank_separator(source, line);
        assert_eq!(widened.text(source), "DELETED\n");
    }

    #[test]
    fn boolean_literals_use_each_language_spelling() {
        assert_eq!(literal_for(Language::Rust, true), "true");
        assert_eq!(literal_for(Language::Python, true), "True");
        assert_eq!(literal_for(Language::Python, false), "False");
        assert_eq!(literal_for(Language::Go, false), "false");
    }

    #[test]
    fn a_constant_conditional_is_recognised() {
        let source = "fn f() {\n    if true {\n        go();\n    }\n}\n";
        let found = collapse(Language::Rust, source).changes;
        assert_eq!(found.len(), 1);
        assert!(found[0].1.contains("go();"), "got {:?}", found[0].1);
    }

    #[test]
    fn a_negated_constant_conditional_is_still_constant() {
        let source = "fn f() {\n    if !true {\n        go();\n    }\n}\n";
        let found = collapse(Language::Rust, source).changes;
        assert_eq!(found.len(), 1, "got {found:?}");
        assert!(found[0].1.trim().is_empty(), "got {:?}", found[0].1);

        let source = "fn f() {\n    if !false {\n        go();\n    }\n}\n";
        let found = collapse(Language::Rust, source).changes;
        assert_eq!(found.len(), 1, "got {found:?}");
        assert!(found[0].1.contains("go();"), "got {:?}", found[0].1);
    }

    #[test]
    fn a_python_not_of_a_constant_is_still_constant() {
        let source = "def f():\n    if not True:\n        go()\n    stay()\n";
        let found = collapse(Language::Python, source).changes;
        assert_eq!(found.len(), 1, "got {found:?}");
        assert!(found[0].1.trim().is_empty(), "got {:?}", found[0].1);
    }

    #[test]
    fn a_negation_of_something_unprovable_is_left_alone() {
        let source = "fn f() {\n    if !ready {\n        go();\n    }\n}\n";
        assert!(collapse(Language::Rust, source).changes.is_empty());
        // `notable` begins with `not` and is a name, so it must not read as a negation.
        let source = "def f():\n    if notable:\n        go()\n";
        assert!(collapse(Language::Python, source).changes.is_empty());
    }

    #[test]
    fn a_variable_condition_is_left_alone() {
        let source = "fn f() {\n    if ready {\n        go();\n    }\n}\n";
        assert!(collapse(Language::Rust, source).changes.is_empty());
    }

    #[test]
    fn a_false_conditional_without_an_else_collapses_to_nothing() {
        let source = "fn f() {\n    if false {\n        go();\n    }\n}\n";
        let found = collapse(Language::Rust, source).changes;
        assert_eq!(found.len(), 1);
        assert!(found[0].1.trim().is_empty(), "got {:?}", found[0].1);
    }

    #[test]
    fn a_false_conditional_keeps_the_else_branch() {
        let source =
            "fn f() {\n    if false {\n        go();\n    } else {\n        wait();\n    }\n}\n";
        let found = collapse(Language::Rust, source).changes;
        assert_eq!(found.len(), 1);
        assert!(found[0].1.contains("wait();"), "got {:?}", found[0].1);
        assert!(!found[0].1.contains("go();"), "got {:?}", found[0].1);
    }

    #[test]
    fn dedenting_keeps_the_nesting_inside_a_branch() {
        let text = "\n        if x {\n            deep();\n        }\n    ";
        assert_eq!(dedent_to(text, ""), "if x {\n    deep();\n}");
    }

    #[test]
    fn a_zig_statement_conditional_uses_the_body_field() {
        let source = "pub fn f() void {\n    if (true) {\n        go();\n    }\n}\n";
        let found = collapse(Language::Zig, source).changes;
        assert_eq!(found.len(), 1, "got {found:?}");
        assert_eq!(found[0].1, "go();");
    }

    #[test]
    fn a_zig_expression_conditional_collapses_to_a_branch() {
        let source = "pub fn f() u8 {\n    const x = if (false) 1 else 2;\n    return x;\n}\n";
        let found = collapse(Language::Zig, source).changes;
        assert_eq!(found.len(), 1, "got {found:?}");
        assert_eq!(found[0].1, "2");
    }

    #[test]
    fn a_zig_unbraced_branch_keeps_its_semicolon() {
        let source = "pub fn f() void {\n    if (true) go();\n}\n";
        let found = collapse(Language::Zig, source).changes;
        assert_eq!(found[0].1, "go();");
    }

    #[test]
    fn a_zig_payload_capture_is_refused() {
        let source = "pub fn f() void {\n    if (true) |v| {\n        go(v);\n    }\n}\n";
        let refusals = collapse(Language::Zig, source).refusals;
        assert_eq!(refusals.len(), 1, "got {refusals:?}");
        assert!(refusals[0].1.contains("payload"), "got {refusals:?}");
    }

    #[test]
    fn a_bash_literal_command_is_provable() {
        let source = "if true; then\n  go\nelse\n  wait\nfi\n";
        let found = collapse(Language::Bash, source).changes;
        assert_eq!(found.len(), 1, "got {found:?}");
        assert_eq!(found[0].1, "go");
    }

    #[test]
    fn a_bash_string_comparison_is_provable() {
        let source = "if [ true = true ]; then\n  go\nfi\n";
        assert_eq!(collapse(Language::Bash, source).changes[0].1, "go");
        let source = "if [ false = true ]; then\n  go\nelse\n  wait\nfi\n";
        assert_eq!(collapse(Language::Bash, source).changes[0].1, "wait");
    }

    #[test]
    fn a_bash_test_against_a_variable_is_refused() {
        let source = "if [ true = \"$OTHER\" ]; then\n  go\nfi\n";
        let refusals = collapse(Language::Bash, source).refusals;
        assert_eq!(refusals.len(), 1, "got {refusals:?}");
        assert!(refusals[0].1.contains("not a provably constant shell test"));
    }

    #[test]
    fn a_bash_condition_with_no_literal_is_not_this_refactorings_business() {
        let source = "if [ -f /etc/hosts ]; then\n  go\nfi\n";
        let result = collapse(Language::Bash, source);
        assert!(result.changes.is_empty());
        assert!(result.refusals.is_empty(), "got {:?}", result.refusals);
    }

    #[test]
    fn an_hcl_conditional_collapses_to_a_branch() {
        let source = "resource \"a\" \"b\" {\n  x = true ? \"yes\" : \"no\"\n}\n";
        let found = collapse(Language::Hcl, source).changes;
        assert_eq!(found.len(), 1, "got {found:?}");
        assert_eq!(found[0].1, "\"yes\"");
    }

    #[test]
    fn a_count_the_author_wrote_is_left_alone() {
        // Remove only a `count` this cascade produced. One that stood before belongs to
        // the author.
        let source = "resource \"a\" \"b\" {\n  count = 1\n}\n";
        assert!(collapse_against(Language::Hcl, source, source)
            .changes
            .is_empty());
        assert_eq!(collapse(Language::Hcl, source).changes.len(), 1);
    }

    #[test]
    fn a_count_that_count_index_depends_on_is_refused() {
        let source = "resource \"a\" \"b\" {\n  count = 1\n  n = count.index\n}\n";
        let result = collapse(Language::Hcl, source);
        assert!(result.changes.is_empty(), "got {:?}", result.changes);
        assert!(
            result.refusals[0].1.contains("count.index"),
            "got {:?}",
            result.refusals
        );
    }

    #[test]
    fn an_else_if_branch_does_not_gain_a_stray_semicolon() {
        let source =
            "pub fn f(x: bool) void {\n    if (true) {\n        a();\n    } else if (x) {\n        b();\n    }\n}\n";
        let found = collapse(Language::Zig, source).changes;
        assert_eq!(found[0].1, "a();");

        let source =
            "pub fn f(x: bool) void {\n    if (false) {\n        a();\n    } else if (x) {\n        b();\n    }\n}\n";
        let found = collapse(Language::Zig, source).changes;
        assert!(!found[0].1.ends_with(';'), "got {:?}", found[0].1);
        assert!(found[0].1.starts_with("if (x)"), "got {:?}", found[0].1);
    }
}
