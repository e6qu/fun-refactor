//! Code intelligence over the resolved index: call graphs, entry points and flow.

pub mod call_graph;
pub mod duplicates;
pub mod entrypoints;
pub mod flags;
pub mod flow;
pub mod impact;
pub mod paths;
pub mod provenance;
pub mod stitch;
pub mod types;
