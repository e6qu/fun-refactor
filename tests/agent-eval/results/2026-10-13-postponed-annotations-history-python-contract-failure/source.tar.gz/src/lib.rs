//! fun-refactor, multi-language refactoring and code intelligence on tree-sitter.

pub mod analysis;
#[cfg(feature = "cli")]
pub mod cache;
pub mod capabilities;
#[cfg(feature = "cli")]
pub mod checks;
#[cfg(feature = "cli")]
pub mod cli;
pub mod formal_kernel;
pub mod vfs;
#[cfg(feature = "cli")]
pub mod workflow;
// The C the grammars call, which `wasm32-unknown-unknown` does not supply.
#[cfg(all(target_arch = "wasm32", feature = "wasm"))]
extern crate fun_refactor_wasm_libc;

pub mod application_ir;
#[cfg(feature = "cli")]
pub mod audit;
pub mod edit;
pub mod extract;
#[path = "project/framework_kernel.rs"]
pub mod framework_kernel;
#[cfg(feature = "cli")]
pub mod git;
pub mod git_patch;
pub mod helm;
#[cfg(feature = "cli")]
pub mod history;
pub mod index;
pub mod lang;
#[cfg(feature = "wasm")]
mod memory_history;
pub mod mentions;
pub mod model;
pub mod navigate;
pub mod openapi;
pub mod parse;
#[cfg(feature = "cli")]
pub mod project;
pub mod recipe;
pub mod refactor;
#[cfg(feature = "cli")]
pub mod scan;
pub mod span;
#[cfg(feature = "cli")]
pub mod spec;
#[path = "project/surface_kernel.rs"]
pub mod surface_kernel;
#[cfg(test)]
pub mod testing;
pub mod transaction_kernel;
pub mod translate;
pub mod transpile;
#[cfg(feature = "wasm")]
pub mod wasm;
