use super::{absent, checked, checkout, common, directory, line, ownership, preparation, Proposal};
use crate::git::worktree::RecoverOptions;
use anyhow::{ensure, Context, Result};
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};
use std::collections::{BTreeMap, BTreeSet};
use std::fs;
use std::os::unix::fs::MetadataExt;
use std::path::{Path, PathBuf};

pub(super) struct Capture {
    pub(super) plan: Proposal,
    pub(super) receipt: ownership::Receipt,
    pub(super) receipt_bytes: Vec<u8>,
    pub(super) blobs: Vec<Vec<u8>>,
    preparation: Option<preparation::Prepared>,
    receipt_published: bool,
}

#[derive(Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
pub(super) struct Observation {
    pub(super) missing: Vec<String>,
    pub(super) files: BTreeMap<String, (u64, u64, u32, String)>,
    pub(super) directories: BTreeMap<String, (u64, u64)>,
    pub(super) index_digest: Option<String>,
    pub(super) worktree_config: Option<(u64, u64, u32, String)>,
    #[serde(skip)]
    pub(super) index: Option<Vec<u8>>,
}

pub(super) fn capture(root: &Path, path: &Path, removal: bool) -> Result<Capture> {
    let requested = root.canonicalize()?;
    let root = crate::git::process::repository_root(&requested)?;
    ensure!(
        requested.starts_with(&root),
        "Git resolved a working tree outside the requested directory."
    );
    let input = root.join(path);
    directory(&input)?;
    let destination = input.canonicalize()?;
    ensure!(
        crate::git::process::repository_root(&destination)? == destination,
        "recovery requires a worktree root."
    );
    let shared = common(&root)?;
    ensure!(
        common(&destination)? == shared,
        "recovery destination belongs to another repository."
    );
    let output = checked(
        &destination,
        &["rev-parse", "--path-format=absolute", "--git-path", "index"],
    )?;
    let metadata = Path::new(line(&output)?)
        .parent()
        .context("worktree index needs a directory.")?
        .canonicalize()?;
    ensure!(
        metadata.parent() == Some(shared.join("worktrees").as_path()),
        "recovery requires a linked worktree."
    );
    let receipt_path = metadata.join("fr-creation.json");
    let receipt_exists = !absent(&receipt_path)?;
    if !receipt_exists && !removal {
        let (prepared, plan) = preparation::Prepared::recover(&root, &destination)?;
        ensure!(
            crate::git::worktree_prepared_recovery_allowed(receipt_exists, true, true),
            "prepared ownership evidence does not authorize recovery."
        );
        let receipt =
            ownership::Receipt::inspect(&plan, directory(&destination)?, Some(prepared.id()))?;
        ensure!(
            receipt.path() == receipt_path,
            "prepared creation metadata differs."
        );
        let receipt_bytes = serde_json::to_vec(&receipt)?;
        let blobs = checkout::blobs(&plan)?;
        return Ok(Capture {
            plan,
            receipt,
            receipt_bytes,
            blobs,
            preparation: Some(prepared),
            receipt_published: false,
        });
    }
    let (receipt, receipt_bytes) = ownership::Receipt::read(&receipt_path)?;
    if removal {
        ensure!(
            receipt.complete,
            "removal requires a completed ownership receipt."
        );
    } else {
        ensure!(
            !receipt.complete,
            "worktree creation is already complete; recovery will not restore later deletions."
        );
    }
    ensure!(
        receipt.common == shared && receipt.destination == destination,
        "ownership receipt belongs to another worktree."
    );
    ensure!(
        crate::git::worktree_configuration_allowed(
            receipt.worktree_config,
            super::worktree_config(&root)?,
            false,
            false
        ),
        "extensions.worktreeConfig changed after reviewed creation."
    );
    let selected = if removal {
        ensure!(
            !root.starts_with(&destination),
            "cannot remove the invoking worktree or its ancestor."
        );
        super::commit(&destination, "HEAD")?
    } else {
        receipt.commit.clone()
    };
    let files = checkout::inventory(&root, &selected)?;
    let tree = checked(
        &root,
        &["rev-parse", "--verify", &format!("{selected}^{{tree}}")],
    )?;
    ensure!(
        removal || line(&tree)? == receipt.tree,
        "ownership receipt tree differs from its commit."
    );
    let registrations = checked(
        &root,
        &["worktree", "list", "--porcelain", "-z", "--expire=now"],
    )?;
    let plan = Proposal {
        version: env!("CARGO_PKG_VERSION").to_owned(),
        root,
        common: shared.clone(),
        common_identity: receipt.common_identity,
        worktree_config: receipt.worktree_config,
        destination: destination.clone(),
        parent_identity: receipt.parent_identity,
        branch: receipt.branch.clone(),
        existing_branch: receipt.existing_branch,
        from: receipt.commit.clone(),
        commit: selected,
        tree: line(&tree)?.to_owned(),
        registrations: ownership::digest(&registrations),
        files,
    };
    checkout::check_registration(&plan)?;
    let blobs = checkout::blobs(&plan)?;
    let preparation = receipt
        .preparation
        .as_deref()
        .map(|id| preparation::Prepared::load(&shared, &destination, id))
        .transpose()?
        .flatten();
    ensure!(
        !removal || preparation.is_none(),
        "removal refuses leftover worktree creation preparation."
    );
    Ok(Capture {
        plan,
        receipt,
        receipt_bytes,
        blobs,
        preparation,
        receipt_published: true,
    })
}

pub(super) fn observe(capture: &Capture) -> Result<Observation> {
    let plan = &capture.plan;
    capture.receipt.check()?;
    checkout::check_registration(plan)?;
    let registrations = checked(
        &plan.root,
        &["worktree", "list", "--porcelain", "-z", "--expire=now"],
    )?;
    ensure!(
        ownership::digest(&registrations) == plan.registrations,
        "worktree registrations changed during recovery."
    );
    if capture.receipt_published {
        ensure!(
            ownership::bytes(&capture.receipt.path(), 64 * 1024)? == capture.receipt_bytes,
            "ownership receipt changed."
        );
    } else {
        ensure!(
            absent(&capture.receipt.path())?,
            "ownership receipt appeared after prepared creation review."
        );
    }
    if let Some(prepared) = &capture.preparation {
        prepared.check()?;
    }
    let expected = plan
        .files
        .iter()
        .zip(&capture.blobs)
        .map(|(entry, blob)| (entry.path.as_str(), (entry, blob)))
        .collect::<BTreeMap<_, _>>();
    let directories = plan
        .files
        .iter()
        .flat_map(|entry| Path::new(&entry.path).ancestors().skip(1))
        .map(|path| path.to_str().unwrap().to_owned())
        .collect::<BTreeSet<_>>();
    let mut observed = Observation {
        missing: Vec::new(),
        files: BTreeMap::new(),
        directories: BTreeMap::new(),
        index_digest: None,
        worktree_config: None,
        index: None,
    };
    let mut pending = vec![PathBuf::new()];
    while let Some(relative) = pending.pop() {
        let directory_path = plan.destination.join(&relative);
        observed.directories.insert(
            relative
                .to_str()
                .context("recovery paths must use UTF-8.")?
                .to_owned(),
            directory(&directory_path)?,
        );
        for entry in fs::read_dir(&directory_path)? {
            let entry = entry?;
            let path = relative.join(entry.file_name());
            let name = path.to_str().context("recovery paths must use UTF-8.")?;
            if name == ".git" {
                continue;
            }
            let stat = fs::symlink_metadata(entry.path())?;
            if stat.file_type().is_dir() {
                ensure!(
                    directories.contains(name),
                    "unexpected recovery directory: {name:?}."
                );
                pending.push(path);
            } else {
                let (entry, blob) = expected
                    .get(name)
                    .with_context(|| format!("unexpected recovery file: {name:?}."))?;
                let entry_path = plan.destination.join(&path);
                let raw = checkout::entry_bytes(&entry_path, entry)
                    .with_context(|| format!("reading recovery file {name:?}."))?;
                let after = fs::symlink_metadata(&entry_path)?;
                ensure!(
                    crate::git::worktree_recovery_file_allowed(
                        stat.dev() == after.dev()
                            && stat.ino() == after.ino()
                            && stat.mode() == after.mode(),
                        raw == **blob,
                        entry.metadata_matches(&after)
                    ),
                    "recovery file differs from committed bytes or mode: {name:?}."
                );
                observed.files.insert(
                    name.to_owned(),
                    (
                        after.dev(),
                        after.ino(),
                        after.mode(),
                        ownership::digest(&raw),
                    ),
                );
            }
        }
    }
    observed.missing = plan
        .files
        .iter()
        .filter(|entry| !observed.files.contains_key(&entry.path))
        .map(|entry| entry.path.clone())
        .collect();
    let index = checkout::index_path(plan)?;
    let config = index.parent().unwrap().join("config.worktree");
    match fs::symlink_metadata(&config) {
        Ok(before) => {
            ensure!(
                crate::git::worktree_configuration_allowed(
                    plan.worktree_config,
                    super::worktree_config(&plan.root)?,
                    true,
                    before.file_type().is_file()
                ),
                "per-worktree configuration must be a regular file."
            );
            let raw = ownership::bytes(&config, 1024 * 1024)?;
            let after = fs::symlink_metadata(&config)?;
            ensure!(
                before.dev() == after.dev()
                    && before.ino() == after.ino()
                    && before.mode() == after.mode(),
                "per-worktree configuration changed during inspection."
            );
            observed.worktree_config = Some((
                after.dev(),
                after.ino(),
                after.mode(),
                ownership::digest(&raw),
            ));
        }
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => ensure!(
            crate::git::worktree_configuration_allowed(
                plan.worktree_config,
                super::worktree_config(&plan.root)?,
                false,
                false
            ),
            "extensions.worktreeConfig changed during inspection."
        ),
        Err(error) => return Err(error.into()),
    }
    for marker in [
        "MERGE_HEAD",
        "CHERRY_PICK_HEAD",
        "REVERT_HEAD",
        "rebase-merge",
        "rebase-apply",
        "sequencer",
    ] {
        ensure!(
            absent(&index.parent().unwrap().join(marker))?,
            "recovery refuses an active Git operation: {marker}."
        );
    }
    if !absent(&index)? {
        let raw = ownership::bytes(&index, 64 * 1024 * 1024)?;
        checkout::verify_index(plan)?;
        ensure!(
            ownership::bytes(&index, 64 * 1024 * 1024)? == raw,
            "recovery index changed during inspection."
        );
        observed.index_digest = Some(ownership::digest(&raw));
        observed.index = Some(raw);
    }
    capture.receipt.check()?;
    Ok(observed)
}

fn basis(capture: &Capture, observation: &Observation) -> Result<String> {
    Ok(format!(
        "frwtr1:{}",
        ownership::digest(&serde_json::to_vec(&(
            &capture.plan,
            ownership::digest(&capture.receipt_bytes),
            capture.receipt_published,
            capture
                .preparation
                .as_ref()
                .map(|prepared| prepared.fingerprint()),
            observation
        ))?)
    ))
}

pub(in crate::git::worktree) fn report(root: &Path, options: &RecoverOptions) -> Result<Value> {
    ensure!(
        (1..=500).contains(&options.limit),
        "limit must be between 1 and 500."
    );
    let mut capture = capture(root, &options.path, false)?;
    let lease = options
        .write
        .then(|| ownership::Lease::acquire(capture.receipt.path().with_extension("lock")))
        .transpose()?;
    let observed = observe(&capture)?;
    let token = basis(&capture, &observed)?;
    if let Some(expected) = &options.basis {
        ensure!(
            *expected == token,
            "stale worktree recovery basis; request a new preview."
        );
    }
    let mut result = json!({"schema":1, "operation":if options.write {"worktree-recover"} else {"worktree-recover-preview"},
        "applied":false,"basis":token,"basis_verified":options.basis.is_some(),"destination":capture.plan.destination,
        "repository_root":capture.plan.root,"ownership_record":capture.receipt.path(),"branch":format!("refs/heads/{}",capture.plan.branch),
        "commit":capture.plan.commit,"tree":capture.plan.tree,"checkout":"raw-blobs","existing_files":observed.files.len(),
        "ownership_state":if capture.receipt_published{"receipt"}else{"prepared"},
        "worktree_config":capture.plan.worktree_config,"worktree_config_file":observed.worktree_config.is_some(),
        "index_action":if observed.index.is_some(){"preserve"}else{"create"},
        "missing":observed.missing.iter().take(options.limit).collect::<Vec<_>>(),
        "page":{"total":observed.missing.len(),"returned":observed.missing.len().min(options.limit),
            "omitted":observed.missing.len().saturating_sub(options.limit)}});
    if let Some(prepared) = &capture.preparation {
        result["preparation_record"] = json!(prepared.path());
    }
    if let Some(lease) = lease {
        let current = observe(&capture)?;
        ensure!(
            basis(&capture, &current)? == token,
            "worktree recovery basis changed before writing."
        );
        let outcome = (|| -> Result<()> {
            lease.check()?;
            if !capture.receipt_published {
                capture.receipt_bytes = capture.receipt.publish(&lease)?;
                capture.receipt_published = true;
            }
            if let Some(prepared) = capture.preparation.take() {
                let preparation_lease = ownership::Lease::acquire(prepared.lock_path())?;
                prepared.remove(preparation_lease)?;
            }
            let index_lease = checkout::prepare_index(&capture.plan, current.index.as_deref())?;
            checkout::populate(
                &capture.plan,
                &capture.blobs,
                capture.receipt.destination_identity,
                true,
            )?;
            let finished = observe(&capture)?;
            ensure!(
                finished.missing.is_empty(),
                "recovery still has missing committed files."
            );
            if let Some(before) = current.index {
                ensure!(
                    finished.index == Some(before),
                    "recovery index changed before completion."
                );
            }
            ensure!(
                finished.worktree_config == current.worktree_config,
                "per-worktree configuration changed during recovery."
            );
            checkout::sync(&capture.plan)?;
            index_lease.check()?;
            capture.receipt.finish(&lease, &capture.receipt_bytes)?;
            Ok(())
        })();
        match outcome {
            Ok(()) => result["applied"] = json!(true),
            Err(error) => {
                result["applied"] = Value::Null;
                result["warning"] = json!("Recovery is incomplete or unconfirmed. Inspect the checkout and ownership receipt before retrying.");
                let diagnostic = format!("{error:#}");
                result["diagnostic"] =
                    json!(crate::git::process::diagnostic(diagnostic.as_bytes()));
                result["diagnostic_truncated"] = json!(diagnostic.len() > 16 * 1024);
            }
        }
    }
    Ok(result)
}
