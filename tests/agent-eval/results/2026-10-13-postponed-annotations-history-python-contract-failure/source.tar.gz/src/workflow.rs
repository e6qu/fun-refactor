use crate::checks;
use crate::history::{self, Action, History, Status};
use anyhow::{bail, ensure, Context, Result};
use clap::Args;
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::fs::{self, File};
use std::io::{Read, Write};
use std::path::{Component, Path, PathBuf};

const MAX_MANIFEST_BYTES: u64 = 65_536;
const MAX_PATCH_PATH_BYTES: usize = 4_096;

#[derive(Args)]
pub struct Options {
    #[arg(
        long,
        value_name = "MANIFEST",
        help = "Reviewed workflow manifest, at most 64 KiB."
    )]
    pub from: PathBuf,
    #[arg(
        long,
        help = "Execute the preflighted workflow and write its patch artifact."
    )]
    pub write: bool,
    #[arg(
        long,
        requires = "write",
        value_name = "BASIS",
        help = "Omit the unchanged preflight envelope reviewed under this workflow basis."
    )]
    pub basis: Option<String>,
}

#[derive(Deserialize, Serialize)]
#[serde(deny_unknown_fields, rename_all = "kebab-case")]
pub(crate) struct Manifest {
    pub schema: u32,
    pub transaction: u64,
    pub transaction_context_basis: String,
    #[serde(default)]
    pub resume_applied: bool,
    pub checks: CheckRequest,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub acceptance_checks: Option<AcceptanceRequest>,
    #[serde(default)]
    pub exercise_reversal: bool,
    #[serde(default)]
    pub check_original: bool,
    #[serde(default)]
    pub compact_success: bool,
    pub patch: Option<PatchRequest>,
    #[serde(default = "default_output_bytes")]
    pub check_output_bytes: usize,
}

#[derive(Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
pub(crate) struct CheckRequest {
    pub basis: String,
    pub names: Vec<String>,
}

#[derive(Clone, Deserialize, Serialize)]
#[serde(deny_unknown_fields, rename_all = "kebab-case")]
pub(crate) struct AcceptanceRequest {
    pub basis: String,
    pub names: Vec<String>,
    pub toolchain_digest: String,
}

#[derive(Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
pub(crate) struct PatchRequest {
    pub output: PathBuf,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum Stage {
    Apply = 0,
    CheckApplied = 1,
    Undo = 2,
    CheckRestored = 3,
    Redo = 4,
    DeliverPatch = 5,
    CheckOriginal = 6,
    CheckAcceptance = 7,
}

impl Stage {
    fn name(self) -> &'static str {
        match self {
            Self::Apply => "apply",
            Self::CheckApplied => "check-applied",
            Self::Undo => "undo",
            Self::CheckRestored => "check-restored",
            Self::Redo => "redo",
            Self::DeliverPatch => "deliver-patch",
            Self::CheckOriginal => "check-original",
            Self::CheckAcceptance => "check-acceptance",
        }
    }
}

pub fn workflow_stage_state(applied: bool, stage: usize) -> usize {
    match (applied, stage) {
        (false, 0 | 3 | 6) => usize::from(stage == 0),
        (false, 4) => 1,
        (true, 1 | 5 | 7) => 1,
        (true, 2) => 0,
        _ => 2,
    }
}

fn default_output_bytes() -> usize {
    4_096
}

fn stages(
    check_original: bool,
    exercise_reversal: bool,
    patch: bool,
    acceptance: bool,
) -> Vec<Stage> {
    let mut stages = Vec::new();
    if check_original {
        stages.push(Stage::CheckOriginal);
    }
    stages.extend([Stage::Apply, Stage::CheckApplied]);
    if acceptance {
        stages.push(Stage::CheckAcceptance);
    }
    if exercise_reversal {
        stages.extend([
            Stage::Undo,
            Stage::CheckRestored,
            Stage::Redo,
            Stage::CheckApplied,
        ]);
        if acceptance {
            stages.push(Stage::CheckAcceptance);
        }
    }
    if patch {
        stages.push(Stage::DeliverPatch);
    }
    stages
}

fn manifest_stages(manifest: &Manifest) -> Vec<Stage> {
    let mut result = stages(
        manifest.check_original,
        manifest.exercise_reversal,
        manifest.patch.is_some(),
        manifest.acceptance_checks.is_some(),
    );
    if manifest.resume_applied {
        result.retain(|stage| !matches!(stage, Stage::Apply));
    }
    result
}

pub(crate) fn planned_stage_names(
    check_original: bool,
    exercise_reversal: bool,
    patch: bool,
    acceptance: bool,
) -> Vec<&'static str> {
    stages(check_original, exercise_reversal, patch, acceptance)
        .into_iter()
        .map(Stage::name)
        .collect()
}

fn read_manifest(path: &Path) -> Result<(Manifest, Vec<u8>)> {
    let metadata = fs::symlink_metadata(path)
        .with_context(|| format!("reading workflow manifest {}", path.display()))?;
    ensure!(
        metadata.is_file(),
        "workflow manifest must be a regular file"
    );
    ensure!(
        metadata.len() <= MAX_MANIFEST_BYTES,
        "workflow manifest exceeds 65536 bytes"
    );
    let mut bytes = Vec::new();
    File::open(path)?
        .take(MAX_MANIFEST_BYTES + 1)
        .read_to_end(&mut bytes)?;
    ensure!(
        bytes.len() as u64 <= MAX_MANIFEST_BYTES,
        "workflow manifest exceeds 65536 bytes"
    );
    Ok((serde_json::from_slice(&bytes)?, bytes))
}

fn digest_parts(parts: &[&[u8]]) -> String {
    let mut digest = Sha256::new();
    for part in parts {
        digest.update((part.len() as u64).to_be_bytes());
        digest.update(part);
    }
    hex::encode(digest.finalize())
}

fn basis_matches(supplied: &str, complete: &str) -> bool {
    supplied == complete
        || supplied.len() >= 32 && supplied.len() < complete.len() && complete.starts_with(supplied)
}

fn patch_path(root: &Path, requested: &Path) -> Result<PathBuf> {
    ensure!(
        !requested.as_os_str().is_empty()
            && !requested.is_absolute()
            && requested.as_os_str().as_encoded_bytes().len() <= MAX_PATCH_PATH_BYTES
            && requested
                .components()
                .all(|component| matches!(component, Component::Normal(_))),
        "workflow patch output must be a relative normal path of at most 4096 bytes."
    );
    ensure!(
        !requested.components().any(|component| {
            matches!(component.as_os_str().to_str(), Some(".git" | ".fr-history"))
        }),
        "workflow patch output cannot enter .git or .fr-history."
    );
    let mut path = root.to_path_buf();
    let components = requested.components().collect::<Vec<_>>();
    for (index, component) in components.iter().enumerate() {
        path.push(component.as_os_str());
        match fs::symlink_metadata(&path) {
            Ok(metadata) if metadata.file_type().is_symlink() => {
                bail!("workflow patch output cannot traverse a symlink.")
            }
            Ok(_) if index + 1 == components.len() => {
                bail!(
                    "workflow patch output already exists: {}",
                    requested.display()
                )
            }
            Ok(metadata) if !metadata.is_dir() => {
                bail!("workflow patch output parent is not a directory.")
            }
            Ok(_) => {}
            Err(error) if error.kind() == std::io::ErrorKind::NotFound => {
                if index + 1 != components.len() {
                    bail!("workflow patch output parent does not exist.")
                }
            }
            Err(error) => return Err(error.into()),
        }
    }
    Ok(path)
}

pub(crate) fn validate_patch_output(root: &Path, requested: &Path) -> Result<()> {
    patch_path(&root.canonicalize()?, requested).map(drop)
}

fn write_patch(path: &Path, patch: &str) -> Result<()> {
    let parent = path
        .parent()
        .context("workflow patch output has no parent")?;
    let mut temporary = tempfile::NamedTempFile::new_in(parent)?;
    temporary.write_all(patch.as_bytes())?;
    temporary.flush()?;
    temporary.persist_noclobber(path)?;
    Ok(())
}

struct Preflight {
    root: PathBuf,
    manifest: Manifest,
    manifest_digest: String,
    workflow_basis: String,
    resolved_checks: Vec<String>,
    check_basis: String,
    patch: String,
    patch_digest: String,
    patch_path: Option<PathBuf>,
    report: Value,
}

fn preflight(root: &Path, options: &Options) -> Result<Preflight> {
    let root = root.canonicalize()?;
    ensure!(root.is_dir(), "workflow root must be a directory");
    let (manifest, manifest_bytes) = read_manifest(&root.join(&options.from))?;
    preflight_manifest(root, manifest, manifest_bytes)
}

fn preflight_manifest(
    root: PathBuf,
    manifest: Manifest,
    manifest_bytes: Vec<u8>,
) -> Result<Preflight> {
    ensure!(manifest.schema == 1, "workflow manifest requires schema 1");
    ensure!(
        manifest.transaction > 0,
        "workflow transaction must be positive"
    );
    ensure!(
        manifest.check_output_bytes <= 65_536,
        "workflow check output budget must be between 0 and 65536 bytes."
    );

    let history = History::read(&root)?;
    history.ensure_ready()?;
    let record = history.record(manifest.transaction)?;
    if manifest.resume_applied {
        ensure!(
            record.status == Status::Applied,
            "resume requires an applied transaction"
        );
        ensure!(
            !manifest.check_original,
            "resume cannot check original source before application; use exercise-reversal"
        );
    } else {
        ensure!(
            record.status == Status::Planned,
            "workflow requires a planned transaction"
        );
    }
    let complete_context = history::transaction_context_basis(record);
    ensure!(
        manifest.transaction_context_basis == complete_context,
        "stale or conflicting workflow transaction context basis."
    );
    history::act_with_context(
        &root,
        if manifest.resume_applied {
            Action::Undo
        } else {
            Action::Apply
        },
        manifest.transaction,
        false,
        true,
        (!manifest.resume_applied).then_some(complete_context.as_str()),
    )?;

    let selection = checks::select(&root, &manifest.checks.names)?
        .context("workflow requires at least one declared check.")?;
    ensure!(
        basis_matches(&manifest.checks.basis, &selection.configuration_basis),
        "workflow check configuration basis is missing or stale."
    );
    if let Some(required) = &record.required_checks {
        ensure!(
            required.configuration_basis == selection.configuration_basis
                && required.checks == selection.checks,
            "workflow checks do not satisfy the transaction's required selection."
        );
    }
    if let Some(request) = &manifest.acceptance_checks {
        ensure!(
            request.names.len() <= 32,
            "workflow accepts at most 32 acceptance checks."
        );
        let selected =
            checks::select(&root, &request.names)?.context("acceptance requires named checks.")?;
        ensure!(
            request.basis == selected.configuration_basis,
            "acceptance check configuration changed."
        );
        ensure!(
            request.toolchain_digest == checks::evidence::toolchain_digest(&root)?,
            "acceptance check toolchain changed."
        );
    }

    let export = history::export_patch(&root, manifest.transaction, false)?;
    let patch_digest = hex::encode(Sha256::digest(export.patch.as_bytes()));
    let resolved_path = manifest
        .patch
        .as_ref()
        .map(|request| patch_path(&root, &request.output))
        .transpose()?;
    if let Some(request) = &manifest.patch {
        ensure!(
            !record
                .changes
                .iter()
                .any(|change| change.path == request.output),
            "workflow patch output conflicts with a transaction target."
        );
    }

    let manifest_digest = hex::encode(Sha256::digest(&manifest_bytes));
    let resumed_revision = manifest
        .resume_applied
        .then(|| history::source_revision(&root))
        .transpose()?;
    let workflow_basis = format!(
        "frwb1:{}",
        digest_parts(&[
            b"fr-workflow-1",
            manifest_digest.as_bytes(),
            record.basis.as_bytes(),
            complete_context.as_bytes(),
            selection.configuration_basis.as_bytes(),
            patch_digest.as_bytes(),
            resumed_revision.as_deref().unwrap_or("").as_bytes(),
        ])
    );
    let planned_stages = manifest_stages(&manifest);
    let mut report = json!({
        "schema": "fr-workflow-1",
        "manifest_sha256": manifest_digest,
        "workflow_basis": workflow_basis,
        "transaction": manifest.transaction,
        "transaction_status": record.status,
        "record_basis": record.basis,
        "transaction_context_basis": complete_context,
        "checks": {
            "basis": selection.configuration_basis,
            "names": selection.checks,
            "coverage": selection.coverage,
            "output_bytes": manifest.check_output_bytes,
        },
        "exercise_reversal": manifest.exercise_reversal,
        "check_original": manifest.check_original,
        "compact_success": manifest.compact_success,
        "patch": manifest.patch.as_ref().map(|request| json!({
            "output": request.output,
            "bytes": export.patch.len(),
            "sha256": patch_digest,
            "format": export.format,
        })),
        "stages": planned_stages.iter().map(|stage| json!({
            "stage": stage.name(), "status": "pending"
        })).collect::<Vec<_>>(),
        "ready": true,
        "executed": false,
        "passed": Value::Null,
    });
    if let Some(revision) = resumed_revision {
        report["resume_applied"] = json!(true);
        report["source_revision"] = json!(revision);
    }
    if let Some(request) = &manifest.acceptance_checks {
        report["acceptance_checks"] = json!(request);
    }

    Ok(Preflight {
        root,
        manifest,
        manifest_digest,
        workflow_basis,
        resolved_checks: selection.checks,
        check_basis: selection.configuration_basis,
        patch: export.patch,
        patch_digest,
        patch_path: resolved_path,
        report,
    })
}

fn compact_check(report: Value) -> Value {
    json!({
        "basis": report["basis"],
        "source_revision": report["source_revision"],
        "source_snapshot_stable": report["source_snapshot_stable"],
        "passed": report["passed"],
        "results": report["results"],
        "recorded_evidence": report.get("recorded_evidence").cloned(),
    })
}

fn compact_successful_check(report: &Value) -> Value {
    json!({
        "basis": report["basis"],
        "source_revision": report["source_revision"],
        "source_snapshot_stable": report["source_snapshot_stable"],
        "passed": report["passed"],
        "results": report["results"].as_array().into_iter().flatten().map(|result| json!({
            "name": result["name"],
            "passed": result["passed"],
            "exit_code": result["exit_code"],
            "timed_out": result["timed_out"],
            "output_limit_exceeded": result["output_limit_exceeded"],
            "source_snapshot_stable": result["source_snapshot_stable"],
        })).collect::<Vec<_>>(),
        "recorded_evidence": report.get("recorded_evidence").cloned(),
        "success_detail": "summary",
    })
}

fn current_status(root: &Path, transaction: u64) -> Value {
    History::read(root)
        .ok()
        .and_then(|history| {
            history
                .record(transaction)
                .ok()
                .map(|record| json!(record.status))
        })
        .unwrap_or(Value::Null)
}

fn fail_stage(
    mut report: Value,
    root: &Path,
    transaction: u64,
    index: usize,
    error: String,
) -> Value {
    report["stages"][index]["status"] = json!("failed");
    report["stages"][index]["error"] = json!(error);
    report["transaction_status"] = current_status(root, transaction);
    report["executed"] = json!(true);
    report["passed"] = json!(false);
    report
}

pub struct Outcome {
    pub report: Value,
    pub passed: bool,
}

pub fn run(root: &Path, options: &Options) -> Result<Outcome> {
    let preflight = preflight(root, options)?;
    execute(preflight, options.write, options.basis.as_deref())
}

pub(crate) fn run_manifest(root: &Path, manifest: Manifest, write: bool) -> Result<Outcome> {
    let root = root.canonicalize()?;
    ensure!(root.is_dir(), "workflow root must be a directory");
    let bytes = serde_json::to_vec(&manifest)?;
    let preflight = preflight_manifest(root, manifest, bytes)?;
    let basis = write.then(|| preflight.workflow_basis.clone());
    execute(preflight, write, basis.as_deref())
}

fn execute(preflight: Preflight, write: bool, basis: Option<&str>) -> Result<Outcome> {
    if !write {
        return Ok(Outcome {
            report: preflight.report,
            passed: true,
        });
    }

    ensure!(
        !preflight.manifest.resume_applied || basis.is_some(),
        "resume requires a reviewed workflow basis"
    );
    if let Some(supplied) = basis {
        ensure!(
            supplied == preflight.workflow_basis,
            "stale or conflicting workflow basis."
        );
    }

    let Preflight {
        root,
        manifest,
        manifest_digest,
        workflow_basis,
        resolved_checks,
        check_basis,
        patch,
        patch_digest,
        patch_path,
        mut report,
    } = preflight;
    if basis.is_some() {
        let object = report.as_object_mut().unwrap();
        let omitted = [
            "manifest_sha256",
            "record_basis",
            "transaction_context_basis",
            "checks",
            "exercise_reversal",
            "check_original",
            "compact_success",
            "patch",
            "ready",
        ];
        for key in omitted {
            object.remove(key);
        }
        report["reviewed_context_omitted"] = json!(omitted);
    }
    let transaction = manifest.transaction;
    let planned_stages = manifest_stages(&manifest);
    let mut applied = manifest.resume_applied;

    for (index, stage) in planned_stages.into_iter().enumerate() {
        let next = workflow_stage_state(applied, stage as usize);
        if next == 2 {
            return Ok(Outcome {
                report: fail_stage(
                    report,
                    &root,
                    transaction,
                    index,
                    "workflow lifecycle policy refused the stage.".into(),
                ),
                passed: false,
            });
        }
        let result = match stage {
            Stage::Apply | Stage::Undo | Stage::Redo => {
                let action = match stage {
                    Stage::Apply => Action::Apply,
                    Stage::Undo => Action::Undo,
                    Stage::Redo => Action::Redo,
                    _ => unreachable!(),
                };
                let context = matches!(action, Action::Apply | Action::Redo)
                    .then_some(manifest.transaction_context_basis.as_str());
                history::act_with_context(&root, action, transaction, true, false, context).map(
                    |transition| {
                        report["stages"][index]["result"] = transition;
                    },
                )
            }
            Stage::CheckOriginal | Stage::CheckApplied | Stage::CheckRestored => {
                let options = checks::Options {
                    toolchain: false,
                    run: resolved_checks.clone(),
                    basis: Some(check_basis.clone()),
                    output_bytes: manifest.check_output_bytes,
                    quiet_success: true,
                    no_declarations: true,
                    record_for: (stage == Stage::CheckApplied).then_some(transaction),
                };
                checks::report(&root, &options).and_then(|check| {
                    let passed = check["passed"] == true;
                    report["stages"][index]["result"] = if passed && manifest.compact_success {
                        compact_successful_check(&check)
                    } else {
                        compact_check(check)
                    };
                    ensure!(passed, "declared checks failed");
                    Ok(())
                })
            }
            Stage::CheckAcceptance => {
                let request = manifest.acceptance_checks.as_ref().unwrap();
                let run = || -> Result<Value> {
                    ensure!(
                        request.toolchain_digest == checks::evidence::toolchain_digest(&root)?,
                        "acceptance check toolchain changed before execution."
                    );
                    checks::report(
                        &root,
                        &checks::Options {
                            toolchain: true,
                            run: request.names.clone(),
                            basis: Some(request.basis.clone()),
                            output_bytes: manifest.check_output_bytes,
                            quiet_success: true,
                            no_declarations: false,
                            record_for: None,
                        },
                    )
                };
                run().and_then(|check| {
                    let passed = check["passed"] == true;
                    report["stages"][index]["result"] = check;
                    ensure!(passed, "post-change acceptance checks failed");
                    Ok(())
                })
            }
            Stage::DeliverPatch => {
                let mut delivered = || -> Result<()> {
                    let path = patch_path
                        .as_deref()
                        .context("workflow patch stage has no output path")?;
                    patch_path_for_delivery(&root, &manifest, path)?;
                    write_patch(path, &patch)?;
                    report["stages"][index]["result"] = json!({
                        "output": manifest.patch.as_ref().unwrap().output,
                        "bytes": patch.len(),
                        "sha256": patch_digest,
                    });
                    Ok(())
                };
                delivered()
            }
        };
        if let Err(error) = result {
            return Ok(Outcome {
                report: fail_stage(report, &root, transaction, index, format!("{error:#}")),
                passed: false,
            });
        }
        report["stages"][index]["status"] = json!("passed");
        applied = next == 1;
    }

    report["manifest_sha256"] = json!(manifest_digest);
    report["workflow_basis"] = json!(workflow_basis);
    report["transaction_status"] = current_status(&root, transaction);
    report["executed"] = json!(true);
    report["passed"] = json!(true);
    Ok(Outcome {
        report,
        passed: true,
    })
}

fn patch_path_for_delivery(root: &Path, manifest: &Manifest, expected: &Path) -> Result<()> {
    let requested = &manifest
        .patch
        .as_ref()
        .context("missing patch request")?
        .output;
    let current = patch_path(root, requested)?;
    ensure!(
        current == expected,
        "workflow patch output resolved differently after validation."
    );
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn stage_policy_accepts_only_state_appropriate_steps() {
        let expected = [[1, 2, 2, 0, 1, 2, 0, 2], [2, 1, 0, 2, 2, 1, 2, 1]];
        for (applied, row) in expected.into_iter().enumerate() {
            for (stage, next) in row.into_iter().enumerate() {
                assert_eq!(workflow_stage_state(applied == 1, stage), next);
            }
        }
    }

    #[test]
    fn generated_lifecycles_start_planned_and_finish_applied() {
        for original in [false, true] {
            for exercise in [false, true] {
                for patch in [false, true] {
                    let mut applied = false;
                    for stage in stages(original, exercise, patch, true) {
                        let next = workflow_stage_state(applied, stage as usize);
                        assert_ne!(next, 2);
                        applied = next == 1;
                    }
                    assert!(applied);
                }
            }
        }
    }
}
