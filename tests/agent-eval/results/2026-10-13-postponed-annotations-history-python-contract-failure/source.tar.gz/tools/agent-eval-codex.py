#!/usr/bin/env python3
"""Run an explicitly selected fresh agent-evaluation pair through Codex CLI."""

import argparse
import hashlib
import io
import json
from pathlib import Path
import tempfile
import time

from agent_eval.bounded_host import run as run_bounded


DEFAULT_MODEL = "gpt-5.6-luna"
DEFAULT_EFFORT = "low"
DEFAULT_SERVICE_TIER = "default"


def load(path):
    return json.loads(path.read_text())


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def selected_pairs(sessions, names):
    experiment = load(sessions / "experiment.json")
    planned = experiment.get("trials")
    expected_arms = experiment.get("pair_arms", ["fr", "files"])
    if not isinstance(planned, list) or not planned or not all(isinstance(name, str) for name in planned) or len(set(planned)) != len(planned):
        raise ValueError("Experiment has no planned trials")
    if (
        not isinstance(expected_arms, list)
        or len(expected_arms) != 2
        or not all(isinstance(arm, str) and arm for arm in expected_arms)
        or len(set(expected_arms)) != 2
    ):
        raise ValueError("Experiment pair_arms must name two distinct non-empty arms")
    if not names:
        raise ValueError("Select both members of at least one pair with --trial")
    if len(names) != len(set(names)) or any(name not in planned for name in names):
        raise ValueError("Selected trials must be distinct members of this experiment")
    selected = []
    groups = {}
    for name in planned:
        if name not in names:
            continue
        if Path(name).name != name or name in {".", ".."}:
            raise ValueError("Unsafe trial path")
        session = sessions / name
        if not session.resolve().is_relative_to(sessions.resolve()):
            raise ValueError("Trial path escapes sessions directory")
        config = load(session / "session.json")
        key = (config["task"], config["repetition"], config.get("model"), config.get("mode"))
        if config["arm"] not in expected_arms or config["arm"] in groups.setdefault(key, {}):
            raise ValueError(f"Pair {key} has repeated or unknown arms")
        groups.setdefault(key, {})[config["arm"]] = (name, session, config)
    for key, arms in groups.items():
        if set(arms) != set(expected_arms):
            raise ValueError(f"Select both {expected_arms[0]} and {expected_arms[1]} trials for pair {key}")
        left, right = (arms[arm][2] for arm in expected_arms)
        for field in ("repository_revision", "requirement_sha256", "grader_sha256",
                      "budgets", "model_settings", "fr", "cache_state", "plan_sha256"):
            if (field in left) != (field in right) or left.get(field) != right.get(field):
                raise ValueError(f"Pair {key} has unmatched {field}")
        order = list(arms) if experiment.get("preserve_trial_order") is True else expected_arms
        selected.append(tuple(arms[arm] for arm in order))
    return selected


def codex_command(codex, session, model, effort, service_tier):
    return [
        str(codex),
        "exec",
        "--ephemeral",
        "--ignore-user-config",
        "--ignore-rules",
        "--skip-git-repo-check",
        "--json",
        "--color",
        "never",
        "--sandbox",
        "workspace-write",
        "--add-dir",
        str(session),
        "--model",
        model,
        "--config",
        f'model_reasoning_effort="{effort}"',
        "--config",
        f'service_tier="{service_tier}"',
        "--cd",
        str(session / "project"),
        "--output-last-message",
        str(session / "codex-final.txt"),
        "-",
    ]


def validate_settings(config, model, effort, service_tier):
    if config.get("model", model) != model:
        raise ValueError("Requested model differs from the session's declared model")
    expected = {"reasoning_effort": effort, "service_tier": service_tier}
    if "model_settings" in config and config["model_settings"] != expected:
        raise ValueError("Requested settings differ from the session's declared settings")


def run_trial(codex, entry, model, effort, service_tier, timeout):
    name, session, config = entry
    validate_settings(config, model, effort, service_tier)
    record_path = session / "codex-run.json"
    events_path = session / "codex-events.jsonl"
    stderr_path = session / "codex-stderr.txt"
    if any(path.exists() for path in (record_path, events_path, stderr_path, session / "events.jsonl")):
        raise ValueError(f"Trial {name} is not fresh; prepare a new session")
    prompt_path = session / "prompt.txt"
    command = codex_command(codex, session, model, effort, service_tier)
    started = time.time()
    with events_path.open("wb") as stdout, stderr_path.open("wb") as stderr:
        execution = run_bounded(command, prompt_path.read_bytes(), stdout, stderr, session,
                                wall_seconds=timeout)
    record = {
        "schema": "fr-agent-eval-codex-run-1",
        "trial": name,
        "task": config["task"],
        "arm": config["arm"],
        "repetition": config["repetition"],
        "model": model,
        "reasoning_effort": effort,
        "service_tier": service_tier,
        "ephemeral": True,
        "ignored_user_config": True,
        "ignored_rules": True,
        "sandbox": "workspace-write",
        "prompt_sha256": digest(prompt_path),
        "events_sha256": digest(events_path),
        "stderr_sha256": digest(stderr_path),
        "started_at": started,
        "elapsed_seconds": time.time() - started,
        **execution,
        "command": command,
    }
    record_path.write_text(json.dumps(record, indent=2) + "\n")
    return record


def codex_version(codex):
    with tempfile.TemporaryDirectory() as temporary:
        stdout, stderr = io.BytesIO(), io.BytesIO()
        result = run_bounded([str(codex), "--version"], b"", stdout, stderr, Path(temporary),
                             wall_seconds=10, transcript_bytes=65536)
    if result["stop_reason"] or result["exit_code"] != 0:
        raise ValueError(f"Codex version probe failed: {result}")
    return stdout.getvalue().decode().strip()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("sessions", type=Path)
    parser.add_argument("--trial", action="append", default=[])
    parser.add_argument("--codex", type=Path, default=Path("codex"))
    parser.add_argument("--model", default=DEFAULT_MODEL)
    parser.add_argument("--effort", default=DEFAULT_EFFORT)
    parser.add_argument("--service-tier", default=DEFAULT_SERVICE_TIER)
    parser.add_argument("--timeout", type=int, default=900)
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument(
        "--confirm-agent-spend",
        action="store_true",
        help="Required acknowledgement that the selected Codex runs consume quota.",
    )
    args = parser.parse_args()
    if not 60 <= args.timeout <= 900:
        parser.error("--timeout must be between 60 and 900 seconds")
    try:
        pairs = selected_pairs(args.sessions, args.trial)
        for pair in pairs:
            for entry in pair:
                validate_settings(entry[2], args.model, args.effort, args.service_tier)
    except (OSError, KeyError, ValueError, json.JSONDecodeError) as error:
        parser.error(str(error))
    if args.dry_run:
        print(
            json.dumps(
                {
                    "pairs": [[fr[0], files[0]] for fr, files in pairs],
                    "commands": [
                        codex_command(args.codex, entry[1], args.model, args.effort, args.service_tier)
                        for pair in pairs
                        for entry in pair
                    ],
                },
                indent=2,
            )
        )
        return
    if not args.confirm_agent_spend:
        parser.error("--confirm-agent-spend is required for a real Codex run")
    version = codex_version(args.codex)
    records = []
    for pair in pairs:
        for entry in pair:
            record = run_trial(
                args.codex,
                entry,
                args.model,
                args.effort,
                args.service_tier,
                args.timeout,
            )
            record["codex_version"] = version
            (entry[1] / "codex-run.json").write_text(json.dumps(record, indent=2) + "\n")
            records.append(record)
    print(json.dumps({"runs": records}, indent=2))


if __name__ == "__main__":
    main()
