#!/usr/bin/env bash

set -euo pipefail

cd "$(dirname "$0")/.."

source tools/lean-resources.sh
fr_configure_lean_resources

(
    cd kernels
    lake build --wfail
    lake exe fr-correspondence-kernel >/dev/null
    lake exe fr-investigation-kernel >/dev/null
    lake exe fr-investigation-kernel flow-join >/dev/null
    lake exe fr-investigation-kernel check-scope >/dev/null
    lake exe fr-investigation-kernel proof-evidence >/dev/null
    lake exe fr-investigation-kernel local-module >/dev/null
    lake exe fr-investigation-kernel flow-summary >/dev/null
    lake exe fr-investigation-kernel flow-fact-coverage >/dev/null
    lake exe fr-investigation-kernel compiler-coverage >/dev/null
    lake exe fr-edit-kernel >/dev/null
    lake exe fr-position-kernel >/dev/null
    lake exe fr-history-kernel >/dev/null
    lake exe fr-history-kernel patch-modes >/dev/null
    lake exe fr-history-kernel snapshot-modes >/dev/null
    lake exe fr-history-kernel workflow-stages >/dev/null
    lake exe fr-history-kernel task-change-modes >/dev/null
    lake exe fr-history-kernel agent-session-steps >/dev/null
    lake exe fr-history-kernel agent-guide-routes >/dev/null
    lake exe fr-history-kernel agent-guide-steps >/dev/null
    lake exe fr-history-kernel agent-context-admission >/dev/null
    lake exe fr-history-kernel agent-intent-admission >/dev/null
    lake exe fr-history-kernel agent-intent-sections >/dev/null
    lake exe fr-history-kernel intent-action-purposes >/dev/null
    lake exe fr-history-kernel intent-review-modes >/dev/null
    lake exe fr-history-kernel intent-review-completeness >/dev/null
    lake exe fr-history-kernel host-recovery >/dev/null
    lake exe fr-history-kernel memory-transitions >/dev/null
    lake exe fr-history-kernel memory-restores >/dev/null
    lake exe fr-history-kernel memory-compactions >/dev/null
    lake exe fr-history-kernel patch-basis >/dev/null
    lake exe fr-history-kernel owner-executable >/dev/null
    lake exe fr-project-kernel >/dev/null
    lake exe fr-project-kernel module-offsets >/dev/null
    lake exe fr-project-kernel source-slices >/dev/null
    lake exe fr-project-kernel source-pages >/dev/null
    lake exe fr-digest-kernel >/dev/null
    lake exe fr-pure-kernel >/dev/null
    lake exe fr-project-kernel body-replacement-budget >/dev/null
    lake exe fr-project-kernel plan-basis >/dev/null
    lake exe fr-project-kernel handle-selection >/dev/null
    lake exe fr-project-kernel semantic-sections >/dev/null
    lake exe fr-project-kernel semantic-author-admission >/dev/null
    lake exe fr-project-kernel semantic-ir-catalog >/dev/null
    lake exe fr-project-kernel semantic-source-free >/dev/null
    lake exe fr-project-kernel resolution-snapshots >/dev/null
    lake exe fr-project-kernel agent-discovery >/dev/null
    lake exe fr-project-kernel progressive-disclosure >/dev/null
    lake exe fr-project-kernel framework-boundaries >/dev/null
    lake exe fr-project-kernel application-adapters >/dev/null
    lake exe fr-project-kernel line-ranges >/dev/null
    lake exe fr-project-kernel call-selection >/dev/null
    lake exe fr-project-kernel staging-transition >/dev/null
    lake exe fr-project-kernel commit-basis >/dev/null
    lake exe fr-project-kernel worktree-budget >/dev/null
    lake exe fr-project-kernel worktree-removal >/dev/null
    lake exe fr-project-kernel worktree-removal-resume >/dev/null
    lake exe fr-project-kernel worktree-branch-selection >/dev/null
    lake exe fr-project-kernel worktree-archive-compaction >/dev/null
    lake exe fr-project-kernel worktree-recovery >/dev/null
    lake exe fr-project-kernel patterns >/dev/null
    lake exe fr-project-kernel confidence >/dev/null
    lake exe fr-project-kernel membership >/dev/null
    lake exe fr-project-kernel closure >/dev/null
)
