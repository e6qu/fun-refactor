"""IR-shaped structured goals and deterministic, read/preview-only workflow guides."""

from __future__ import annotations
from dataclasses import dataclass, field, replace
import hashlib
import json
from pathlib import Path
import re
import tempfile
from typing import Any, Mapping, TYPE_CHECKING

from .context import merkle_object_digest
from .runtime import AgentTarget, FrReport, FrRuntimeError
from .ir import ScalarRequest, TaskChange, TaskDelivery, TaskTarget
from .intent_actions import TaggedIntentAction, TaskChangeOperation, _operation_code
from .context import ObjectStore
from .intent import CompiledIntent

if TYPE_CHECKING:
    from .runtime import FrClient, TaskReview

_PURPOSES = ("understand", "trace", "change", "migrate", "prove")
_PROOFS = ("none", "model", "implementation")
_KINDS = ("automatic", "capability", "recipe", "semantic-scalar", "semantic-change",
          "semantic-body", "source-body", "source-bodies", "surface-edit", "framework-migration", "formalize", "proof")
_GUIDED_OPERATIONS = {
    "evidence": ("project-query",),
    "direct-capability": ("capability",),
    "recipe": ("recipe",),
    "semantic-scalar": ("task-change", "author-batch"),
    "semantic-change": ("task-change", "author-batch"),
    "semantic-body": ("task-change", "author-batch"),
    "surface-edit": ("surface-edit",),
    "framework-migration": ("framework-migration", "application-migration"),
    "formalization": ("property-task", "formal-plan"),
    "proof": ("proof-task", "proof-submission"),
    "source-body": ("task-change", "author-batch"),
    "source-bodies": ("task-change", "author-batch"),
}


def _canonical(value: Any) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"),
                      allow_nan=False).encode("utf-8")


def _bounded(value: Any, label: str, maximum: int = 512) -> None:
    if (not isinstance(value, str) or not value or "\0" in value
            or len(value.encode("utf-8")) > maximum):
        raise FrRuntimeError(f"{label} must be a bounded nonempty string")


def _requests_execution(value: str) -> bool:
    return value.split("=", 1)[0] in ("--write", "--save-plan")


@dataclass(frozen=True)
class GoalSelector:
    name: str | None = None
    path: str | None = None
    scope: str = "."
    kind: str | None = None
    language: str | None = None
    locals: bool = False

    def __post_init__(self) -> None:
        if (self.name is None) == (self.path is None):
            raise FrRuntimeError("goal selector needs exactly one name or path")
        for label, value in (("name", self.name), ("path", self.path),
                             ("scope", self.scope), ("kind", self.kind)):
            if value is not None:
                _bounded(value, label)
        if not isinstance(self.locals, bool):
            raise FrRuntimeError("selector locals must be Boolean")

    def to_data(self) -> dict[str, Any]:
        return {"name": self.name, "path": self.path, "scope": self.scope,
                "kind": self.kind, "language": self.language, "locals": self.locals}


@dataclass(frozen=True)
class GoalOperation:
    """A tagged operation; its fields have the same names as the public JSON union."""
    kind: str = "automatic"
    fields: Mapping[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        required = {
            "automatic": (), "capability": ("capability",), "recipe": ("verb",),
            "semantic-scalar": ("operation",), "semantic-change": (), "semantic-body": (),
            "source-body": (),
            "source-bodies": ("additional",),
            "surface-edit": ("surface",), "framework-migration": ("to",),
            "formalize": (), "proof": ("obligation",),
        }
        optional = {"capability": ("parameters", "range"), "semantic-scalar": ("from", "to")}
        if (self.kind not in _KINDS or not isinstance(self.fields, Mapping)
                or not set(required[self.kind]) <= set(self.fields)
                or not set(self.fields) <= set(required[self.kind] + optional.get(self.kind, ()))):
            raise FrRuntimeError("goal operation fields do not match its tagged kind")
        value = json.loads(_canonical(dict(self.fields)))
        for name in required[self.kind]:
            if self.kind != "source-bodies":
                _bounded(value[name], f"operation {name}", 4096)
        if self.kind == "capability":
            span = value.get("range")
            if "range" in value and (not isinstance(span, dict) or set(span) != {"start", "end"}
                    or any(isinstance(item, bool) or not isinstance(item, int) for item in span.values())
                    or not 0 <= span["start"] < span["end"]):
                raise FrRuntimeError("capability goal range must be a nonempty byte span")
            parameters = value.setdefault("parameters", {})
            if not isinstance(parameters, dict):
                raise FrRuntimeError("capability parameters must be a string map")
            for name, item in parameters.items():
                _bounded(name, "parameter name")
                _bounded(item, "parameter value", 4096)
                if item.split("=", 1)[0] in ("--write", "--save-plan"):
                    raise FrRuntimeError("capability parameters cannot request execution or plan persistence")
        if self.kind == "semantic-scalar":
            value.setdefault("from", None)
            value.setdefault("to", None)
            if value["to"] is not None and value["from"] is None:
                raise FrRuntimeError("scalar to needs an exact from value")
            for name in ("from", "to"):
                if value[name] is not None and not isinstance(value[name], str):
                    raise FrRuntimeError("scalar values must use text")
        if self.kind == "source-bodies":
            additional = value["additional"]
            if (not isinstance(additional, list) or not 1 <= len(additional) <= 7
                    or any(not isinstance(item, dict) for item in additional)):
                raise FrRuntimeError("source-bodies needs one through seven additional selectors")
            normalized = []
            for item in additional:
                if set(item) - {"name", "path", "scope", "kind", "language", "locals"}:
                    raise FrRuntimeError("additional selector has unknown fields")
                normalized.append(GoalSelector(**item).to_data())
            value["additional"] = normalized
        object.__setattr__(self, "fields", value)

    def to_data(self) -> dict[str, Any]:
        return {"kind": self.kind, **json.loads(_canonical(self.fields))}


@dataclass(frozen=True)
class GoalConstraints:
    allow_source: bool = False

    def __post_init__(self) -> None:
        if not isinstance(self.allow_source, bool):
            raise FrRuntimeError("allow_source must be Boolean")

    def to_data(self) -> dict[str, Any]:
        return {"allow_source": self.allow_source}


@dataclass(frozen=True)
class GoalLimits:
    token_limit: int = 4096
    packet_limit: int = 16384

    def __post_init__(self) -> None:
        for value, low, high in ((self.token_limit, 1024, 4096),
                                 (self.packet_limit, 2048, 65536)):
            if isinstance(value, bool) or not isinstance(value, int) or not low <= value <= high:
                raise FrRuntimeError("goal context limit is invalid")

    def to_data(self) -> dict[str, Any]:
        return {"token_limit": self.token_limit, "packet_limit": self.packet_limit}


@dataclass(frozen=True)
class AgentGoal:
    purpose: str
    target: str | None = None
    selector: GoalSelector | None = None
    operation: GoalOperation = field(default_factory=GoalOperation)
    constraints: GoalConstraints = field(default_factory=GoalConstraints)
    checks: tuple[str, ...] = ()
    proof: str = "none"
    context: GoalLimits = field(default_factory=GoalLimits)
    delivery: TaskDelivery | None = None

    def __post_init__(self) -> None:
        if self.purpose not in _PURPOSES or self.proof not in _PROOFS:
            raise FrRuntimeError("goal purpose or proof expectation is invalid")
        if self.target is not None:
            _bounded(self.target, "goal target", 16384)
            if not self.target.startswith("frp1:") or self.selector is not None:
                raise FrRuntimeError("choose one full target handle or selector")
        if self.selector is not None and not isinstance(self.selector, GoalSelector):
            raise FrRuntimeError("goal selector requires GoalSelector")
        if (not isinstance(self.operation, GoalOperation)
                or not isinstance(self.constraints, GoalConstraints)
                or not isinstance(self.context, GoalLimits)):
            raise FrRuntimeError("goal fields require their public IR mirrors")
        checks = tuple(self.checks)
        if len(checks) > 32 or len(set(checks)) != len(checks):
            raise FrRuntimeError("goal checks must be at most 32 unique names")
        for name in checks:
            _bounded(name, "check name", 64)
        object.__setattr__(self, "checks", checks)
        if self.delivery is not None and not isinstance(self.delivery, TaskDelivery):
            raise FrRuntimeError("goal delivery requires the public TaskDelivery IR")

    def to_data(self) -> dict[str, Any]:
        return {"schema": "fr-agent-goal-1", "purpose": self.purpose, "target": self.target,
                "selector": self.selector.to_data() if self.selector else None,
                "operation": self.operation.to_data(), "constraints": self.constraints.to_data(),
                "checks": list(self.checks), "proof": self.proof, "context": self.context.to_data(),
                "delivery": self.delivery.to_data() if self.delivery else None}


def _guide_route_admitted(purpose: int, language_class: int, target_kind: int, route: int,
                         supported: bool, source_required: bool, source_allowed: bool,
                         proof_expectation: int) -> bool:
    purpose_matches = ((route == 0 and purpose <= 4)
                       or (route == 1 and purpose <= 2)
                       or (2 <= route <= 6 and purpose == 2)
                       or (route == 7 and purpose == 3)
                       or (route in (8, 9) and purpose == 4))
    return (purpose_matches and language_class <= 1 and target_kind <= 2 and supported
            and (not source_required or source_allowed) and proof_expectation <= 1)


def _guide_step(state: int, action: int, ready: bool, complete_review: bool,
                basis_matches: bool) -> int:
    if state == 0 and action == 0 and ready:
        return 1
    if state == 1 and action == 1 and ready:
        return 2
    if state == 2 and action == 2 and ready and complete_review:
        return 3
    if state == 3 and action == 3 and ready and complete_review and basis_matches:
        return 4
    return 5


def _guide_binding_admitted(expected_fields: int, supplied_fields: int, names_match: bool,
                            values_bounded: bool, execution_disabled: bool,
                            basis_matches: bool) -> bool:
    return (expected_fields <= 32 and expected_fields == supplied_fields and names_match
            and values_bounded and execution_disabled and basis_matches)


def _guided_operation_matches(route: int, operation: int) -> bool:
    return ((route == 0 and operation == 6)
            or (route == 1 and operation in (10, 11))
            or (route == 2 and operation == 2)
            or (route in (3, 4, 5) and operation in (0, 1))
            or (route == 6 and operation == 7)
            or (route == 7 and operation == 3)
            or (route == 8 and operation in (4, 8))
            or (route == 9 and operation in (5, 9)))


def _guide_delivery_admitted(purpose: int, route: int, operation: int, writable: bool,
                             route_admitted: bool, goal_matches: bool, guide_matches: bool,
                             inputs_match: bool, targets_match: bool, revision_matches: bool,
                             checks_match: bool, delivery_matches: bool, review_complete: bool,
                             review_unchanged: bool) -> bool:
    return (_guide_route_admitted(purpose, 0, 0, route, True, False, False, 0)
            and _guided_operation_matches(route, operation) and writable and route_admitted
            and goal_matches and guide_matches and inputs_match and targets_match
            and revision_matches and checks_match and delivery_matches and review_complete
            and review_unchanged)


@dataclass(frozen=True)
class GuideAction:
    guide: AgentGuide = field(repr=False)
    index: int

    def to_data(self) -> dict[str, Any]:
        actions = self.guide.report.at("/actions")
        if isinstance(self.index, bool) or not isinstance(self.index, int) or not 0 <= self.index < len(actions):
            raise FrRuntimeError("guide action index is invalid")
        return actions[self.index]

    @property
    def arguments(self) -> tuple[str, ...]:
        return tuple(self.to_data()["arguments"])


@dataclass(frozen=True)
class GuideFile:
    """One bounded agent-authored file supplied to a guide placeholder."""

    name: str
    text: str

    def __post_init__(self) -> None:
        if (not isinstance(self.name, str) or Path(self.name).name != self.name
                or self.name in ("", ".", "..") or "\0" in self.name
                or len(self.name.encode("utf-8")) > 255):
            raise FrRuntimeError("guide file needs one bounded plain filename")
        if (not isinstance(self.text, str) or "\0" in self.text
                or len(self.text.encode("utf-8")) > 65_536):
            raise FrRuntimeError("guide file content must be at most 65536 UTF-8 bytes")


@dataclass(frozen=True)
class GuideInputs:
    """Exact values for the named author fields of one guide action."""

    values: Mapping[str, str | GuideFile] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not isinstance(self.values, Mapping):
            raise FrRuntimeError("guide inputs must be a field map")
        copied: dict[str, str | GuideFile] = {}
        for name, value in self.values.items():
            _bounded(name, "guide input name")
            if not isinstance(value, (str, GuideFile)):
                raise FrRuntimeError("guide input values must be strings or GuideFile values")
            if isinstance(value, str):
                _bounded(value, "guide input value", 4096)
                if _requests_execution(value):
                    raise FrRuntimeError("guide inputs cannot request execution or plan persistence")
            copied[name] = value
        object.__setattr__(self, "values", copied)


@dataclass(frozen=True)
class GuideRun:
    """A retained guide and every read/preview report followed from it."""

    guide: AgentGuide
    reports: tuple[FrReport, ...]

    def __post_init__(self) -> None:
        if (not isinstance(self.guide, AgentGuide)
                or len(self.reports) != len(self.guide.actions())):
            raise FrRuntimeError("guide run does not cover every retained action")

    def review(self) -> TaskReview:
        """Return the sole immutable task review, refusing routes that need a tagged intent."""
        from .runtime import TaskReview
        reviews = tuple(report for report in self.reports if isinstance(report, TaskReview))
        if len(reviews) != 1:
            raise FrRuntimeError(
                "guide run must retain exactly one task review; use compile_guided_intent "
                "for this route"
            )
        return reviews[0]


@dataclass(frozen=True)
class AgentGuide:
    goal: AgentGoal
    report: FrReport
    report_sha256: str = field(init=False, repr=False)

    def __post_init__(self) -> None:
        value = self.report.to_data()
        encoded = _canonical(value)
        identity = {key: item for key, item in value.items()
                    if key not in ("object_root", "basis", "serialized_bytes")}
        if (value.get("schema") != "fr-agent-guide-1"
                or value.get("goal_sha256") != hashlib.sha256(_canonical(self.goal.to_data())).hexdigest()
                or value.get("purpose") != self.goal.purpose
                or not isinstance(value.get("revision"), str)
                or not re.fullmatch(r"frag1:[0-9a-f]{64}", value.get("basis", ""))
                or value.get("object_root") != merkle_object_digest(identity)
                or value.get("serialized_bytes") != len(encoded)
                or len(encoded) > self.goal.context.packet_limit
                or value.get("execution", {}).get("admitted") is not False
                or not isinstance(value.get("actions"), list)
                or value.get("limits") != {"reveal_token_upper_bound": self.goal.context.token_limit,
                                           "packet_bytes": self.goal.context.packet_limit}):
            raise FrRuntimeError("agent guide failed identity or bounded preview admission")
        for action in value["actions"]:
            fields = action.get("author_fields") if isinstance(action, dict) else None
            names = ([item.get("name") for item in fields]
                     if isinstance(fields, list) and all(isinstance(item, dict) for item in fields)
                     else [])
            placeholders = ({item[1:-1] for item in action.get("arguments", [])
                             if isinstance(item, str) and item.startswith("<") and item.endswith(">")}
                            if isinstance(action, dict) else set())
            if (not isinstance(action, dict) or action.get("writes") is not False
                    or not isinstance(action.get("arguments"), list)
                    or not action["arguments"]
                    or any(not isinstance(item, str) or _requests_execution(item)
                           for item in action["arguments"])
                    or not isinstance(fields, list) or not all(isinstance(name, str) for name in names)
                    or any(not name or "\0" in name or len(name.encode("utf-8")) > 64
                           for name in names)
                    or len(names) > 32 or len(names) != len(set(names))
                    or placeholders != set(names)
                    or action.get("ready") is not (len(fields) == 0)):
                raise FrRuntimeError("guide recommended an invalid or writing action")
        object.__setattr__(self, "report_sha256", hashlib.sha256(encoded).hexdigest())

    def at(self, pointer: str = "") -> Any:
        return self.report.at(pointer)

    def to_data(self) -> dict[str, Any]:
        return self.report.to_data()

    def actions(self) -> tuple[GuideAction, ...]:
        return tuple(GuideAction(self, index) for index in range(len(self.at("/actions"))))

    @property
    def target(self) -> AgentTarget:
        """Return the typed target selected by this guide."""
        return AgentTarget.from_data(self.at("/target"))

    def source_body_action(self, bodies: Mapping[str, str]) -> TaggedIntentAction:
        """Build a checked task from caller-authored bodies keyed by exact guided handles.

        This prepares input only. Review it with ``client.review_guide`` before execution;
        native review still checks source freshness, body syntax and diff completeness.
        """
        data = self.to_data()
        if (hashlib.sha256(_canonical(data)).hexdigest() != self.report_sha256
                or hashlib.sha256(_canonical(self.goal.to_data())).hexdigest() != data["goal_sha256"]):
            raise FrRuntimeError("guide or goal changed after receipt")
        route = data.get("route")
        kind = self.goal.operation.kind
        if (kind not in ("source-body", "source-bodies") or self.goal.purpose != "change"
                or not isinstance(route, Mapping) or route.get("id") != kind
                or route.get("admitted") is not True or data.get("state") != "ready"
                or data.get("refusals") or not self.goal.constraints.allow_source
                or not self.goal.checks or self.goal.delivery is None):
            raise FrRuntimeError("guide does not contain a complete admitted source-body route")
        rows = data.get("targets") if kind == "source-bodies" else [data.get("target")]
        count = 1 + (len(self.goal.operation.fields["additional"]) if kind == "source-bodies" else 0)
        if not isinstance(rows, list) or len(rows) != count:
            raise FrRuntimeError("body guide needs complete distinct declaration targets")
        targets: list[tuple[str, str]] = []
        for row in rows:
            if not isinstance(row, Mapping):
                raise FrRuntimeError("body guide needs complete distinct declaration targets")
            handle, path = row.get("handle"), row.get("path")
            if (not isinstance(handle, str) or not handle.startswith("frp1:")
                    or not isinstance(path, str) or not path):
                raise FrRuntimeError("body guide needs complete distinct declaration targets")
            targets.append((handle, path))
        if len({handle for handle, _ in targets}) != count or rows[0] != data.get("target"):
            raise FrRuntimeError("body guide needs complete distinct declaration targets")
        if (not isinstance(bodies, Mapping) or set(bodies) != {handle for handle, _ in targets}
                or any(not isinstance(body, str) for body in bodies.values())):
            raise FrRuntimeError("bodies must map every exact guided handle to source text")
        paths = sorted({path for _, path in targets})
        change = TaskChange(
            (), tuple(TaskTarget(f"body-{i}", handle, "replace-body",
                                 fragment=bodies[handle]) for i, (handle, _) in enumerate(targets)),
            {"files-changed": len(paths), "edits": count, "changed-operations": count,
             "paths-changed": paths}, self.goal.checks, self.goal.delivery,
        )
        return TaggedIntentAction(
            TaskChangeOperation(change), diff_bytes=self.goal.context.token_limit,
            report_bytes=self.goal.context.packet_limit, proof_expectation=self.goal.proof,
        )

    def semantic_scalar_action(self) -> TaggedIntentAction:
        """Return the exact typed task action already committed by a complete scalar guide."""
        if hashlib.sha256(_canonical(self.to_data())).hexdigest() != self.report_sha256:
            raise FrRuntimeError("guide changed after receipt")
        fields = self.goal.operation.fields
        route = self.at("/route")
        if (self.goal.purpose != "change" or self.goal.operation.kind != "semantic-scalar"
                or not isinstance(route, Mapping) or route.get("id") != "semantic-scalar"
                or route.get("admitted") is not True or fields.get("from") is None
                or fields.get("to") is None or not self.goal.checks
                or self.goal.delivery is None):
            raise FrRuntimeError("guide does not contain one complete semantic scalar action")
        target = self.target
        if target.path is None:
            raise FrRuntimeError("scalar guide has no exact target")
        change = TaskChange(
            (),
            (TaskTarget(
                "goal", target.handle, "edit-body-scalar",
                scalar=ScalarRequest(fields["operation"], fields["from"], fields["to"]),
            ),),
            {"files-changed": 1, "edits": 1, "changed-operations": 1,
             "paths-changed": [target.path]},
            self.goal.checks,
            self.goal.delivery,
        )
        previews = [item for item in self.at("/actions")
                    if item.get("output_schema") == "fr-task-change-1"]
        if (len(previews) != 1 or previews[0].get("ready") is not True
                or previews[0].get("author_fields") != []
                or previews[0].get("input") != change.to_data()):
            raise FrRuntimeError("scalar guide task manifest differs from its typed goal")
        return TaggedIntentAction(
            TaskChangeOperation(change), diff_bytes=self.goal.context.token_limit,
            report_bytes=self.goal.context.packet_limit, proof_expectation=self.goal.proof,
        )


@dataclass(frozen=True)
class GuideReview:
    """One immutable native action review bound to its retained guide."""

    guide: AgentGuide
    compiled: CompiledIntent
    review_sha256: str = field(init=False, repr=False)

    def __post_init__(self) -> None:
        if not isinstance(self.guide, AgentGuide) or not isinstance(self.compiled, CompiledIntent):
            raise FrRuntimeError("guide review requires an AgentGuide and CompiledIntent")
        action = self.compiled.intent.action
        if not isinstance(action, TaggedIntentAction) or action.guide is None:
            raise FrRuntimeError("guide review requires one guide-bound tagged action")
        route = self.guide.at("/route")
        operation = action.operation.to_data()
        review = self.compiled.at("/action/review")
        route_id = route.get("id") if isinstance(route, Mapping) else None
        route_code = (5 if route_id in ("source-body", "source-bodies") else tuple(_GUIDED_OPERATIONS).index(route_id)
                      if route_id in _GUIDED_OPERATIONS else 10)
        basis_matches = (self.compiled.at("/action/basis") == self.compiled.action_basis
                         and isinstance(self.compiled.action_basis, str)
                         and re.fullmatch(r"fraa2:[0-9a-f]{64}", self.compiled.action_basis) is not None)
        review_shape = (isinstance(review, Mapping)
                        and review.get("schema") == "fr-intent-operation-review-2"
                        and review.get("kind") == operation.get("kind")
                        and review.get("ready") is True
                        and review.get("executed") is False
                        and isinstance(review.get("diff"), str))
        targets = review.get("targets") if isinstance(review, Mapping) else None
        checks = review.get("checks") if isinstance(review, Mapping) else None
        if not _guide_delivery_admitted(
            _PURPOSES.index(self.guide.goal.purpose), route_code, _operation_code(operation),
            isinstance(review, Mapping) and review.get("writable") is True,
            isinstance(route, Mapping) and route.get("admitted") is True,
            action.guide.goal == self.guide.goal.to_data(),
            action.guide.basis == self.guide.at("/basis") and basis_matches,
            review.get("input_sha256") == hashlib.sha256(_canonical(action.to_data())).hexdigest()
            if isinstance(review, Mapping) else False,
            isinstance(targets, list) and self.compiled.intent.target in targets,
            self.compiled.at("/revision") == self.guide.at("/revision"),
            isinstance(checks, Mapping) and isinstance(checks.get("names"), list)
            and len(checks["names"]) == len(self.guide.goal.checks)
            and set(checks["names"]) == set(self.guide.goal.checks),
            isinstance(review, Mapping) and review.get("delivery") == (
                self.guide.goal.delivery.to_data() if self.guide.goal.delivery else None),
            review_shape,
            self.compiled.intent.target == self.guide.target.handle
            and self.compiled.intent.purpose == self.guide.goal.purpose,
        ):
            raise FrRuntimeError("native guide review is incomplete or does not bind its guide")
        object.__setattr__(self, "review_sha256", self._digest())

    def _digest(self) -> str:
        return hashlib.sha256(_canonical({
            "goal": self.guide.goal.to_data(),
            "guide": self.guide.to_data(),
            "compiled": self.compiled.to_data(),
        })).hexdigest()

    @property
    def basis(self) -> str:
        assert self.compiled.action_basis is not None
        return self.compiled.action_basis

    def at(self, pointer: str = "") -> Any:
        if pointer and not pointer.startswith("/"):
            raise FrRuntimeError("guide review pointer must be empty or start with /")
        return self.compiled.at(f"/action/review{pointer}")

    def to_data(self) -> Mapping[str, Any]:
        return self.at()


def guide_goal(client: FrClient, goal: AgentGoal) -> AgentGuide:
    if not isinstance(goal, AgentGoal):
        raise FrRuntimeError("guide requires an AgentGoal")
    report = client.call("guide", "--from", "-", input_bytes=_canonical(goal.to_data()))
    return AgentGuide(goal, report)


def follow_guide(
    client: FrClient,
    action: GuideAction,
    inputs: GuideInputs | None = None,
) -> FrReport:
    if not isinstance(action, GuideAction):
        raise FrRuntimeError("follow_guide requires an action retained by a guide")
    if hashlib.sha256(_canonical(action.guide.to_data())).hexdigest() != action.guide.report_sha256:
        raise FrRuntimeError("guide changed after receipt")
    value = action.to_data()
    expected_fields = tuple(field["name"] for field in value["author_fields"])
    supplied = {} if inputs is None else inputs.values
    if set(supplied) != set(expected_fields):
        raise FrRuntimeError("guide inputs must exactly match the action's named author fields")
    if value["ready"] is not (len(expected_fields) == 0):
        raise FrRuntimeError("guide action readiness differs from its author fields")
    current = guide_goal(client, action.guide.goal)
    basis_matches = current.at("/basis") == action.guide.at("/basis")
    if not _guide_binding_admitted(
        len(expected_fields), len(supplied), set(supplied) == set(expected_fields),
        True, True, basis_matches,
    ):
        raise FrRuntimeError("guide basis changed before its read/preview action")
    data = value.get("input")
    with tempfile.TemporaryDirectory(prefix="fr-guide-") as directory:
        replacements: dict[str, str] = {}
        for name, supplied_value in supplied.items():
            if isinstance(supplied_value, GuideFile):
                path = Path(directory) / supplied_value.name
                path.write_text(supplied_value.text, encoding="utf-8")
                replacements[f"<{name}>"] = str(path)
            else:
                replacements[f"<{name}>"] = supplied_value
        arguments = tuple(replacements.get(item, item) for item in action.arguments)
        if any(item.startswith("<") and item.endswith(">") for item in arguments):
            raise FrRuntimeError("guide action retains an unbound author placeholder")
        report = client.call(*arguments, input_bytes=_canonical(data) if data is not None else None)
    expected = value.get("output_schema")
    field_name = value.get("schema_field", "schema")
    if report.to_data().get(field_name) != expected:
        raise FrRuntimeError("guide action returned a different output schema")
    if len(_canonical(report.to_data())) > value["max_output_bytes"]:
        raise FrRuntimeError("guide action response exceeds its explicit output ceiling")
    if expected == "fr-task-change-1" and data is not None:
        from .runtime import TaskReview
        manifest = _canonical(data)
        basis = report.to_data().get("task_change_basis")
        if not isinstance(basis, str):
            raise FrRuntimeError("guided task preview has no reviewed basis")
        return TaskReview(report.to_data(), report.arguments, manifest,
                          hashlib.sha256(manifest).hexdigest(), basis)
    return report


def complete_guide(
    client: FrClient,
    goal: AgentGoal,
    inputs: Mapping[int, GuideInputs] | None = None,
) -> GuideRun:
    """Select one route and follow all its read/preview actions inside the SDK."""
    if inputs is not None and not isinstance(inputs, Mapping):
        raise FrRuntimeError("guide run inputs must be an action-index map")
    authored = {} if inputs is None else dict(inputs)
    if (any(isinstance(index, bool) or not isinstance(index, int) or index < 0
            or not isinstance(value, GuideInputs) for index, value in authored.items())):
        raise FrRuntimeError("guide run inputs must map nonnegative action indexes to GuideInputs")
    guide = guide_goal(client, goal)
    if set(authored) - set(range(len(guide.actions()))):
        raise FrRuntimeError("guide run inputs name an absent action")
    reports = tuple(
        follow_guide(client, action, authored.get(action.index))
        for action in guide.actions()
    )
    return GuideRun(guide, reports)


def compile_guided_intent(client: FrClient, guide: AgentGuide, action: TaggedIntentAction,
                          *, store: ObjectStore | None = None) -> CompiledIntent:
    """Bind an authored operation to a fresh navigator target and its snapshot."""
    from .intent import AgentIntent, IntentNeed
    from .intent_actions import IntentGuideBinding, TaggedIntentAction
    if not isinstance(guide, AgentGuide) or not isinstance(action, TaggedIntentAction):
        raise FrRuntimeError("guided intent requires a retained guide and TaggedIntentAction")
    if hashlib.sha256(_canonical(guide.to_data())).hexdigest() != guide.report_sha256:
        raise FrRuntimeError("guide changed after receipt")
    route = guide.at("/route")
    operation = action.operation.to_data()
    if (route.get("admitted") is not True
            or operation["kind"] not in _GUIDED_OPERATIONS.get(route.get("id"), ())):
        raise FrRuntimeError("intent operation does not match its admitted navigator route")
    action = replace(action, guide=IntentGuideBinding(guide.goal.to_data(),guide.at("/basis")))
    if action.proof_expectation != guide.goal.proof:
        raise FrRuntimeError("intent proof expectation differs from its goal")
    checks = operation.get("checks", ())
    delivery = operation.get("delivery")
    if operation["kind"] == "task-change":
        checks, delivery = operation["task_change"]["checks"], operation["task_change"]["delivery"]
    if len(checks) != len(guide.goal.checks) or set(checks) != set(guide.goal.checks):
        raise FrRuntimeError("intent checks differ from its goal")
    expected_delivery = guide.goal.delivery.to_data() if guide.goal.delivery is not None else None
    if delivery != expected_delivery:
        raise FrRuntimeError("intent delivery differs from its goal")
    compiled = client.compile(AgentIntent(guide.target.handle, guide.goal.purpose,
        needs=(IntentNeed("map", "code_map", "/target"),),
        token_limit=guide.goal.context.token_limit, packet_limit=guide.goal.context.packet_limit,
        action=action), store=store)
    if compiled.at("/revision") != guide.at("/revision"):
        raise FrRuntimeError("project changed between navigator and intent snapshots")
    return compiled


def review_guide(client: FrClient, guide: AgentGuide, action: TaggedIntentAction,
                 *, store: ObjectStore | None = None) -> GuideReview:
    """Create the common immutable review for one admitted writable guide route."""
    return GuideReview(guide, compile_guided_intent(client, guide, action, store=store))


def execute_guide(client: FrClient, review: GuideReview):
    """Execute an unchanged review; native intent revalidates its guide before writing."""
    if not isinstance(review, GuideReview) or review._digest() != review.review_sha256:
        raise FrRuntimeError("guide review changed before execution")
    # The compiled action carries the original goal and guide basis. Native intent
    # recomputes both in the same project snapshot as the edit, before history.
    return client.execute_intent(review.compiled)
