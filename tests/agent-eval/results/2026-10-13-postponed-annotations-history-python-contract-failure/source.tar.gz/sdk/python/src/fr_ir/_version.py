"""Distribution version shared with the native release."""

VERSION = "0.61.0"  # x-release-please-version
