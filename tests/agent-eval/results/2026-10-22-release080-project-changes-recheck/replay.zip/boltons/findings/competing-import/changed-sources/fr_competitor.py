def clamp(*args, **kwargs):
    return None

def fr_added_clamp(*args, **kwargs):
    return clamp(*args, **kwargs)
