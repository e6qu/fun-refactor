def intcomma(*args, **kwargs):
    return None

def fr_added_intcomma(*args, **kwargs):
    return intcomma(*args, **kwargs)
