"""Typed symbolic flow summaries; model convergence does not prove termination."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from .runtime import FrReport, FrRuntimeError, Occurrence


@dataclass(frozen=True)
class SummaryTrace:
    origin: str
    occurrences: tuple[Occurrence, ...]


@dataclass(frozen=True)
class SinkEffect:
    sink: str
    site: Occurrence
    traces: tuple[SummaryTrace, ...]


@dataclass(frozen=True)
class SummaryParameter:
    name: str
    kind: str
    site: Occurrence
    default: Occurrence | None

    @property
    def required(self) -> bool:
        return self.default is None

    @classmethod
    def from_data(cls, value: Any) -> SummaryParameter:
        if (not isinstance(value, dict) or set(value) != {"name", "kind", "site", "default"}
                or not isinstance(value["name"], str) or not value["name"].isascii()
                or not value["name"].isidentifier()
                or not isinstance(value["kind"], str)
                or value["kind"] not in {"positional-only", "positional-or-keyword", "keyword-only"}):
            raise FrRuntimeError("malformed summary parameter")
        site = Occurrence.from_data(value["site"])
        default = None if value["default"] is None else Occurrence.from_data(value["default"])
        if site.role != "summary-parameter" or site.location.span.end - site.location.span.start != len(value["name"]):
            raise FrRuntimeError("malformed parameter location")
        if default is not None and (default.role != "parameter-default"
                or default.path != site.path or default.revision != site.revision
                or default.location.span.start < site.location.span.end):
            raise FrRuntimeError("malformed default location")
        return cls(value["name"], value["kind"], site, default)


@dataclass(frozen=True)
class FunctionSummary:
    function: str
    parameters: tuple[str, ...]
    returns: tuple[SummaryTrace, ...]
    exceptional_returns: tuple[SummaryTrace, ...]
    sinks: tuple[SinkEffect, ...]
    normal_return: bool
    may_raise: bool
    callees: tuple[str, ...]
    evaluations: int
    signature: tuple[SummaryParameter, ...]

    @property
    def return_parameters(self) -> tuple[int, ...]:
        origins = {trace.origin for trace in self.returns}
        return tuple(index for index, parameter in enumerate(self.parameters) if parameter in origins)


_EXPRESSION_CONTROL = {
    "schema": "fr-expression-control",
    "evaluation": "left-to-right; each operand once per expression transfer.",
    "selectors": "Boolean and None literals, not, parentheses and nested selected expressions.",
    "unknowns": "retain both alternatives; no variable or call-result truth specialization.",
    "comparisons": "ordered operands; each comparison result may be true or false.",
    "effects": "join normal, sink and explicit-raise alternatives.",
    "boundary": "scalar truth and comparisons; no overloaded protocols or implicit exceptions.",
    "path_feasibility": False,
}


@dataclass(frozen=True)
class ExpressionControl:
    evaluation: str
    selectors: str
    unknowns: str
    comparisons: str
    effects: str
    boundary: str
    path_feasibility: bool

    @classmethod
    def from_data(cls, value: Any) -> ExpressionControl:
        if (not isinstance(value, dict) or value != _EXPRESSION_CONTROL
                or type(value.get("path_feasibility")) is not bool):
            raise FrRuntimeError("unsupported expression control contract")
        return cls(**{key: item for key, item in value.items() if key != "schema"})


_CALL_BINDING = {
    "schema": "fr-call-binding",
    "parameters": "ASCII-named positional-only, positional-or-keyword and keyword-only parameters; required or immutable literal defaults.",
    "evaluation": "explicit argument values in source order before parameter binding; once per transfer.",
    "binding": "positional slots followed by exact keyword names; substitute in declaration order.",
    "invalid": "incomplete analysis for missing, excess, duplicate or unknown arguments; no TypeError model.",
    "boundary": "no evaluated or mutable defaults, annotations, referenced variadics, extra variadic arguments, unpacking, coroutine or generator execution, keyword external-rule contracts or non-normalized identifier spellings.",
    "definitions": "Declarations with unannotated ASCII parameters defer bodies, including referenced variadics. Defaults must be immutable literals; annotations, decorators and evaluated defaults remain unchecked. Calls require scalar fixed-slot summaries.",
    "implicit_exceptions": False,
    "defaults": "omitted slots use source-free immutable scalar literals; explicit arguments override defaults; analysis refuses definition-time effects.",
    "variadics": "fixed-slot summaries omit unused, unannotated ASCII variadic parameters. Their names must never occur as body identifiers; calls bind only fixed slots.",
}


@dataclass(frozen=True)
class CallBinding:
    parameters: str
    evaluation: str
    binding: str
    invalid: str
    boundary: str
    implicit_exceptions: bool
    defaults: str
    variadics: str
    definitions: str

    @classmethod
    def from_data(cls, value: Any) -> CallBinding:
        if (not isinstance(value, dict) or value != _CALL_BINDING
                or type(value.get("implicit_exceptions")) is not bool):
            raise FrRuntimeError("unsupported call binding contract")
        return cls(**{key: item for key, item in value.items() if key != "schema"})


_ASSIGNMENT_CONTROL = {
    "schema": "fr-scalar-assignment",
    "evaluation": "evaluate all scalar RHS leaves left-to-right once before any target write.",
    "binding": "match literal tuple/list shapes; write local names and chained targets left-to-right.",
    "limits": "64 RHS shape nodes, 64 target names, 64 chained targets and nesting depth 16 per assignment.",
    "boundary": "no starred targets, arbitrary iterables, container-valued bindings, attribute/subscript writes, annotations or implicit unpacking exceptions.",
    "implicit_exceptions": False,
}


@dataclass(frozen=True)
class AssignmentControl:
    evaluation: str
    binding: str
    limits: str
    boundary: str
    implicit_exceptions: bool

    @classmethod
    def from_data(cls, value: Any) -> AssignmentControl:
        if (not isinstance(value, dict) or value != _ASSIGNMENT_CONTROL
                or type(value.get("implicit_exceptions")) is not bool):
            raise FrRuntimeError("unsupported scalar assignment contract")
        return cls(**{key: item for key, item in value.items() if key != "schema"})


@dataclass(frozen=True)
class FunctionSummaries:
    functions: tuple[FunctionSummary, ...]
    converged: bool
    complete: bool
    rounds: int
    expression_control: ExpressionControl
    call_binding: CallBinding
    assignment_control: AssignmentControl

    def for_function(self, name: str) -> FunctionSummary:
        for item in self.functions:
            if item.function == name:
                return item
        raise FrRuntimeError("function summary was not disclosed")

    @classmethod
    def from_report(cls, report: FrReport) -> FunctionSummaries:
        data = report.to_data()
        try:
            value = data["function_summaries"]
            if (report.schema != "fr-dataflow-1" or data["semantics"] != "python-scalar-summaries"
                    or value["schema"] != "fr-function-summaries" or value["enabled"] is not True
                    or value["mutation_authority"] is not False):
                raise FrRuntimeError("report does not disclose function summaries")
            if (type(value["converged"]) is not bool or type(data["complete"]) is not bool
                    or type(value["rounds"]) is not int or value["rounds"] < 1
                    or not isinstance(value["functions"], dict) or len(value["functions"]) > 64
                    or (data["complete"] and not value["converged"])):
                raise FrRuntimeError("inconsistent summary convergence")
            control = ExpressionControl.from_data(data["expression_control"])
            ExpressionControl.from_data(data["inputs"]["expression_control"])
            if data["inputs"]["expression_control"] != data["expression_control"]:
                raise FrRuntimeError("expression control disagrees with analysis inputs")
            binding = CallBinding.from_data(data["call_binding"])
            CallBinding.from_data(data["inputs"]["call_binding"])
            if data["inputs"]["call_binding"] != data["call_binding"]:
                raise FrRuntimeError("call binding disagrees with analysis inputs")
            assignment = AssignmentControl.from_data(data["assignment_control"])
            AssignmentControl.from_data(data["inputs"]["assignment_control"])
            if data["inputs"]["assignment_control"] != data["assignment_control"]:
                raise FrRuntimeError("assignment control disagrees with analysis inputs")
            revision = data["revision"]

            def occurrence(raw: Any) -> Occurrence:
                result = Occurrence.from_data(raw)
                if result.revision != revision:
                    raise FrRuntimeError("summary occurrence belongs to another revision")
                return result

            functions = []
            for name, item in value["functions"].items():
                parameters = item["parameters"]
                if parameters != [f"argument:{name}:{index}" for index in range(len(parameters))]:
                    raise FrRuntimeError("malformed summary parameters")

                def traces(raw: Any) -> tuple[SummaryTrace, ...]:
                    result = []
                    for origin, trace in raw.items():
                        if (origin != trace["origin"] or
                                origin not in parameters and origin not in data["origins"]):
                            raise FrRuntimeError("summary trace has an undeclared origin")
                        points = tuple(occurrence(o) for o in trace["occurrences"])
                        if not points or len({point.id for point in points}) != len(points):
                            raise FrRuntimeError("summary trace needs distinct occurrences")
                        result.append(SummaryTrace(origin, points))
                    return tuple(result)

                sinks = []
                for key, effect in item["sinks"].items():
                    site = occurrence(effect["site"])
                    if key != site.id or not isinstance(effect["sink"], str) or not effect["sink"]:
                        raise FrRuntimeError("malformed summary sink")
                    sinks.append(SinkEffect(effect["sink"], site, traces(effect["flow"])))
                if (type(item["normal_return"]) is not bool or type(item["may_raise"]) is not bool
                        or type(item["evaluations"]) is not int or item["evaluations"] < 0
                        or not isinstance(item["callees"], list)
                        or any(not isinstance(callee, str) for callee in item["callees"])):
                    raise FrRuntimeError("malformed summary effects")
                if data["complete"] and any(callee not in value["functions"] for callee in item["callees"]):
                    raise FrRuntimeError("complete summary has an undisclosed callee")
                raw_signature = item["signature"]
                if not isinstance(raw_signature, list) or len(raw_signature) != len(parameters):
                    raise FrRuntimeError("signature disagrees with summary parameters")
                signature = tuple(SummaryParameter.from_data(raw) for raw in raw_signature)
                seen = set()
                rank, optional = 0, False
                for parameter in signature:
                    current = {"positional-only": 0, "positional-or-keyword": 1, "keyword-only": 2}[parameter.kind]
                    if (parameter.name in seen or current < rank or parameter.site.revision != revision
                            or current < 2 and optional and parameter.required):
                        raise FrRuntimeError("inconsistent summary signature")
                    seen.add(parameter.name)
                    rank = current
                    optional |= not parameter.required
                functions.append(FunctionSummary(name, tuple(parameters), traces(item["returns"]),
                                                 traces(item["exceptional_returns"]), tuple(sinks),
                                                 item["normal_return"], item["may_raise"],
                                                 tuple(item["callees"]), item["evaluations"], signature))
            return cls(tuple(functions), value["converged"], data["complete"], value["rounds"], control, binding, assignment)
        except (KeyError, TypeError, ValueError, AttributeError) as error:
            raise FrRuntimeError("malformed function summaries") from error
