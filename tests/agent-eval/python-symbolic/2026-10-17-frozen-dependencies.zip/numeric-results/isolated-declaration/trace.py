from pinned_clamp import clamp

def entry():
    return record_value(clamp(emit_value(), 1, 10))
