def clamp(x, lower, upper=None):
    """
    Clamps number within the inclusive lower and upper bounds.

    Args:
        x: Number to clamp.
        lower: Lower bound.
        upper: Upper bound

    Returns:
        number

    Example:

        >>> clamp(-10, -5, 5)
        -5
        >>> clamp(10, -5, 5)
        5
        >>> clamp(10, 5)
        5
        >>> clamp(-10, 5)
        -10

    .. versionadded:: 4.0.0
    """
    if upper is None:
        upper = lower  # type: ignore
        lower = x  # type: ignore

    if x < lower:
        x = lower  # type: ignore
    elif x > upper:  # type: ignore
        x = upper  # type: ignore

    return x
