from pydash.numerical import clamp


def ordered(x: int, lower: int, upper: int) -> int:
    """
    pre: lower <= upper
    post: lower <= _ <= upper
    """
    return clamp(x, lower, upper)

def unchecked_bounds(x: int, lower: int, upper: int) -> int:
    """post: lower <= _ <= upper"""
    return clamp(x, lower, upper)

def upper_only(x: int, upper: int) -> int:
    """post: _ == (x if x <= upper else upper)"""
    return clamp(x, upper)
