import heapq
import threading
import time
from unittest import mock

import pytest

import pydash as _


parametrize = pytest.mark.parametrize


@parametrize(
    "case,expected",
    [
        ((lambda: 3, 2), 3),
        ((lambda: 3, -1), 3),
    ],
)
def test_after(case, expected):
    done = _.after(*case)

    for _x in range(case[1] - 1):
        ret = done()
        assert ret is None

    ret = done()
    assert ret == expected


@parametrize(
    "case,args,kwargs,expected",
    [
        ((lambda a=0, b=0, c=0, d=0: a + b + c + d, 1), (1, 2, 3, 4), {}, 1),
        ((lambda a=0, b=0, c=0, d=0: a + b + c + d, 2), (1, 2, 3, 4), {}, 3),
        ((lambda a=0, b=0, c=0, d=0: a + b + c + d, 3), (1, 2, 3, 4), {}, 6),
        ((lambda a=0, b=0, c=0, d=0: a + b + c + d, 1), (1, 2, 3, 4), {"d": 10}, 11),
        ((lambda a=0, b=0, c=0, d=0: a + b + c + d, 2), (1, 2, 3, 4), {"d": 10}, 13),
        ((lambda a=0, b=0, c=0, d=0: a + b + c + d, 3), (1, 2, 3, 4), {"d": 10}, 16),
        ((lambda a=0, b=0, c=0, d=0: a + b + c + d, None), (1, 2, 3, 4), {}, 10),
    ],
)
def test_ary(case, args, kwargs, expected):
    assert _.ary(*case)(*args, **kwargs) == expected


@parametrize(
    "case,expected",
    [
        ((lambda: 3, 2), 3),
        ((lambda: 3, -1), 3),
    ],
)
def test_before(case, expected):
    done = _.before(*case)

    for _x in range(case[1] - 1):
        ret = done()
        assert ret == expected

    ret = done()
    assert ret is None


@parametrize(
    "case,arg,expected",
    [
        ((_.is_boolean, _.is_empty), [False, True], True),
        ((_.is_boolean, _.is_empty), [False, None], False),
    ],
)
def test_conjoin(case, arg, expected):
    assert _.conjoin(*case)(arg) == expected


@parametrize(
    "case,arglist,expected",
    [
        ((lambda a, b, c: [a, b, c],), [(1, 2, 3)], [1, 2, 3]),
        ((lambda a, b, c: [a, b, c],), [(1, 2), (3,)], [1, 2, 3]),
        ((lambda a, b, c: [a, b, c],), [(1,), (2,), (3,)], [1, 2, 3]),
        ((lambda *a: sum(a), 3), [(1, 1, 1)], 3),
        ((lambda *a: sum(a), 3), [(1,), (1,), (1,)], 3),
    ],
)
def test_curry(case, arglist, expected):
    curried = _.curry(*case)

    # Run test twice to verify curried can be reused
    for _x in range(2):
        ret = curried
        for args in arglist:
            ret = ret(*args)

        assert ret == expected


def test_curry_arity_max_from_func():
    def func(data, accum, id):
        accum[id] = _.reduce_(data, lambda total, n: total + n)
        return accum

    ids = [1]
    data = [1, 2]

    curried_func_with_data = _.curry(func)(data)
    result = _.reduce_(ids, curried_func_with_data, {})

    assert result == {1: 3}


@parametrize(
    "case,arglist,expected",
    [
        ((lambda a, b, c: [a, b, c],), [(1, 2, 3)], [1, 2, 3]),
        ((lambda a, b, c: [a, b, c],), [(2, 3), (1,)], [1, 2, 3]),
        ((lambda a, b, c: [a, b, c],), [(3,), (2,), (1,)], [1, 2, 3]),
        ((lambda *a: sum(a), 3), [(1, 1, 1)], 3),
        ((lambda *a: sum(a), 3), [(1,), (1,), (1,)], 3),
    ],
)
def test_curry_right(case, arglist, expected):
    curried = _.curry_right(*case)

    # Run test twice to verify curried can be reused
    for _x in range(2):
        ret = curried
        for args in arglist:
            ret = ret(*args)

        assert ret == expected


def test_debounce():
    calls = []

    def func(*args):
        calls.append(args)
        return args

    wait = 15
    debounced = _.debounce(func, wait)

    # First call is deferred; subsequent calls reset the wait.
    assert debounced(1) is None
    time.sleep(0.01)
    assert debounced(2) is None
    assert calls == []

    time.sleep((wait + 15) / 1000.0)
    assert calls == [(2,)]
    assert debounced.last_result == (2,)

    # After a quiet period, a new call is deferred again and returns the last result.
    result = debounced(3)
    assert result == (2,)
    assert calls == [(2,)]

    time.sleep((wait + 15) / 1000.0)
    assert calls == [(2,), (3,)]


def test_debounce_max_wait():
    calls = []

    def func():
        now = _.now()
        calls.append(now)
        return now

    wait = 15
    max_wait = 30
    debounced = _.debounce(func, wait, max_wait=max_wait)

    start = _.now()
    assert debounced() is None
    assert calls == []

    # Keep invoking so `wait` never elapses; `max_wait` should still fire.
    deadline = start + max_wait + 10
    while _.now() < deadline:
        debounced()
        time.sleep(0.01)

    assert len(calls) >= 1
    assert calls[0] - start >= max_wait - 10


@parametrize(
    "func,wait,args,kwargs,expected",
    [(lambda a, b, c: (a, b, c), 250, (1, 2), {"c": 3}, (1, 2, 3))],
)
def test_delay(mock_sleep, func, wait, args, kwargs, expected):  # noqa: PLR0917
    result = _.delay(func, wait, *args, **kwargs)
    assert result == expected
    assert mock_sleep.call_args_list == [mock.call(pytest.approx(wait / 1000.0))]


@parametrize(
    "case,arg,expected",
    [
        ((_.is_boolean, _.is_empty), [False, True], True),
        ((_.is_boolean, _.is_empty), [False, None], True),
        ((_.is_string, _.is_number), ["one", 1, "two", 2], True),
        ((_.is_string, _.is_number), [True, False, None, []], False),
    ],
)
def test_disjoin(case, arg, expected):
    assert _.disjoin(*case)(arg) == expected


@parametrize(
    "case,args,expected",
    [
        (lambda args: args, (1, 2, 3), (3, 2, 1)),
        (lambda args: [i * 2 for i in args], (1, 2, 3), [6, 4, 2]),
    ],
)
def flip(case, args, expected):
    func = _.flip(case)
    assert func(args) == expected


@parametrize(
    "case,args,expected",
    [
        ((lambda x: "!!!" + x + "!!!", lambda x: f"Hi {x}"), ("Bob",), "Hi !!!Bob!!!"),
        ((lambda x: x + x, lambda x: x * x), (5,), 100),
    ],
)
def test_flow(case, args, expected):
    assert _.flow(*case)(*args) == expected


@parametrize(
    "case,args,expected",
    [
        ((lambda x: f"Hi {x}", lambda x: "!!!" + x + "!!!"), ("Bob",), "Hi !!!Bob!!!"),
        ((lambda x: x + x, lambda x: x * x), (5,), 50),
    ],
)
def test_flow_right(case, args, expected):
    assert _.flow_right(*case)(*args) == expected


@parametrize(
    "func,args,expected",
    [
        (lambda x: x + x, (2, 0), 2),
        (lambda x: x + x, (2, 1), 4),
        (lambda x: x + x, (2, 2), 8),
        (lambda x: x + x, (2, 3), 16),
    ],
)
def test_iterated(func, args, expected):
    assert _.iterated(func)(*args) == expected


@parametrize(
    "funcs,args,expected",
    [
        ((lambda a: a[0], lambda a: a[-1]), ("Foobar",), ["F", "r"]),
        (
            (lambda a, b: a[0] + b[-1], lambda a, b: a[-1] + b[0]),
            ("Foobar", "Barbaz"),
            ["Fz", "rB"],
        ),
    ],
)
def test_juxtapose(funcs, args, expected):
    assert _.juxtapose(*funcs)(*args) == expected


@parametrize(
    "func,args",
    [
        (lambda item: item, (True,)),
        (lambda item: item, (False,)),
    ],
)
def test_negate(func, args):
    assert _.negate(func)(*args) == (not func(*args))


@parametrize("case,arglist,expected", [(lambda a: a * a, [(2,), (4,)], 4)])
def test_once(case, arglist, expected):
    fn = _.once(case)
    for args in arglist:
        assert fn(*args) == expected


@parametrize(
    "func,transforms,args,expected",
    [
        (lambda a, b: [a, b], [lambda x: x**2, lambda x: x * 2], (5, 10), [25, 20]),
        (lambda a, b: [a, b], ([lambda x: x**2, lambda x: x * 2],), (5, 10), [25, 20]),
    ],
)
def test_over_args(func, transforms, args, expected):
    assert _.over_args(func, *transforms)(*args) == expected


@parametrize(
    "case,case_args,case_kwargs,args,expected",
    [
        (lambda a, b, c: a + b + c, ("a", "b"), {}, ("c",), "abc"),
        (lambda a, b, c: a + b + c, ("a",), {"c": "d"}, ("b",), "abd"),
    ],
)
def test_partial(case, case_args, case_kwargs, args, expected):
    assert _.partial(case, *case_args, **case_kwargs)(*args) == expected


def test_partial_as_iteratee():
    func = _.partial(lambda offset, value, *args: value + offset, 5)
    case = [1, 2, 3]
    expected = [6, 7, 8]
    assert _.map_(case, func) == expected


@parametrize(
    "case,case_args,case_kwargs,args,expected",
    [
        (lambda a, b, c: a + b + c, ("a", "b"), {}, ("c",), "cab"),
        (lambda a, b, c: a + b + c, ("a",), {"c": "d"}, ("b",), "bad"),
    ],
)
def test_partial_right(case, case_args, case_kwargs, args, expected):
    assert _.partial_right(case, *case_args, **case_kwargs)(*args) == expected


@parametrize(
    "case,args,kwargs,expected",
    [
        ((lambda a, b, c: [a, b, c], 2, 0, 1), ("b", "c", "a"), {}, ["a", "b", "c"]),
        ((lambda a, b, c: [a, b, c], [2, 0, 1]), ("b", "c", "a"), {}, ["a", "b", "c"]),
        ((lambda a, b, c: [a, b, c], 2, 1), ("b", "c", "a"), {}, ["a", "c", "b"]),
        ((lambda a, b, c: [a, b, c], 1), ("b", "c", "a"), {}, ["c", "b", "a"]),
        ((lambda a, b, c: [a, b, c], 3, 2, 0, 1), ("b", "c", "a"), {}, ["a", "b", "c"]),
    ],
)
def test_rearg(case, args, kwargs, expected):
    assert _.rearg(*case)(*args, **kwargs) == expected


@parametrize(
    "case,args,expected",
    [
        (lambda *args: args, ["a", "b", "c"], ("a", "b", "c")),
        (lambda *args: ",".join(args), ["a", "b", "c"], "a,b,c"),
        (lambda a, b, c: f"{a} {b} {c}", [1, 2, 3], "1 2 3"),
    ],
)
def test_spread(case, args, expected):
    assert _.spread(case)(args) == expected


def test_throttle():
    def func():
        return _.now()

    wait = 250
    throttled = _.throttle(func, wait)

    start = _.now()
    present = _.now()

    expected = throttled()

    while (present - start) < (wait - 50):
        result = throttled()
        present = _.now()

    assert result == expected

    time.sleep(100 / 1000.0)
    assert throttled() > expected


def test_throttle_trailing_call():
    calls = []
    finished = threading.Event()

    def func(value, *, suffix):
        calls.append((value, suffix))
        if value == "last":
            finished.set()
        return value

    throttled = _.throttle(func, 100)
    assert throttled("first", suffix="a") == "first"
    assert throttled("middle", suffix="b") == "first"
    assert throttled("last", suffix="c") == "first"
    assert finished.wait(1), "the last call in the burst was dropped"
    assert calls == [("first", "a"), ("last", "c")]


@pytest.fixture
def throttle_clock(monkeypatch):
    now = [1000]
    queue = []
    timers = []

    class Timer:
        def __init__(self, interval, function, args):
            self.when = now[0] + interval * 1000
            self.function = function
            self.args = args
            self.cancelled = False
            timers.append(self)

        def start(self):
            heapq.heappush(queue, (self.when, len(timers), self))

        def cancel(self):
            self.cancelled = True

    def advance(milliseconds, run_timers=True):
        target = now[0] + milliseconds
        while run_timers and queue and queue[0][0] <= target:
            when, _, timer = heapq.heappop(queue)
            now[0] = max(now[0], when)
            if not timer.cancelled:
                timer.function(*timer.args)
        now[0] = target

    monkeypatch.setattr(_, "now", lambda: now[0])
    monkeypatch.setattr(threading, "Timer", Timer)
    return advance, timers


def test_throttle_single_call_does_not_repeat(throttle_clock):
    advance, timers = throttle_clock
    func = mock.Mock(return_value="result")
    throttled = _.throttle(func, 100)
    assert throttled("first") == "result"
    advance(200)
    func.assert_called_once_with("first")
    assert timers == []


def test_throttle_keeps_fixed_trailing_deadline(throttle_clock):
    advance, _timers = throttle_clock
    calls = []

    def func(value):
        calls.append((_.now(), value))
        return value

    throttled = _.throttle(func, 100)
    assert throttled(1) == 1
    advance(20)
    assert throttled(2) == 1
    advance(40)
    assert throttled(3) == 1
    advance(40)
    assert calls == [(1000, 1), (1100, 3)]
    assert throttled.last_result == 3
    advance(50)
    assert throttled(4) == 3
    advance(50)
    assert calls == [(1000, 1), (1100, 3), (1200, 4)]
    advance(200)
    assert throttled(5) == 5


def test_throttle_late_timer_does_not_duplicate_new_call(throttle_clock):
    advance, timers = throttle_clock
    func = mock.Mock(side_effect=lambda value: value)
    throttled = _.throttle(func, 100)
    assert throttled("first") == "first"
    advance(20)
    throttled("old")
    old_timer = timers[0]

    # Simulate a busy timer thread: a new call arrives after the deadline first.
    advance(100, run_timers=False)
    assert throttled("new") == "new"
    assert old_timer.cancelled
    throttled("pending")
    # Timer.cancel cannot stop a callback that has already started.
    old_timer.function(*old_timer.args)
    advance(100)
    assert func.call_args_list == [mock.call("first"), mock.call("new"), mock.call("pending")]


def test_throttle_reentrant_call_is_deferred(throttle_clock):
    advance, _timers = throttle_clock
    calls = []

    def func(value):
        calls.append(value)
        if value == "first":
            throttled("nested")
        return value

    throttled = _.throttle(func, 100)
    assert throttled("first") == "first"
    advance(100)
    assert calls == ["first", "nested"]


@parametrize(
    "case,args,kwargs,expected",
    [
        (lambda a=0, b=0, c=0, d=0: a + b + c + d, (1, 2, 3, 4), {}, 1),
        (lambda a=0, b=0, c=0, d=0: a + b + c + d, (1, 2, 3, 4), {"d": 10}, 11),
    ],
)
def test_unary(case, args, kwargs, expected):
    assert _.unary(case)(*args, **kwargs) == expected


@parametrize(
    "case,args,expected",
    [
        (
            (lambda a: a.strip(), lambda func, text: f"<p>{func(text)}</p>"),
            ("  hello world!  ",),
            "<p>hello world!</p>",
        )
    ],
)
def test_wrap(case, args, expected):
    assert _.wrap(*case)(*args) == expected


def test_flow_argcount():
    assert _.flow(lambda x, y: x + y, lambda x: x * 2)._argcount == 2


def test_flow_right_argcount():
    assert _.flow_right(lambda x: x * 2, lambda x, y: x + y)._argcount == 2


def test_juxtapose_argcount():
    assert _.juxtapose(lambda x, y, z: x + y + z, lambda x, y, z: x * y * z)._argcount == 3


def test_partial_argcount():
    assert _.partial(lambda x, y, z: x + y + z, 1, 2)._argcount == 1


def test_partial_right_argcount():
    assert _.partial_right(lambda x, y, z: x + y + z, 1, 2)._argcount == 1


def test_curry_argcount():
    assert _.curry(lambda x, y, z: x + y + z)(1)._argcount == 2


def test_curry_right_argcount():
    assert _.curry_right(lambda x, y, z: x + y + z)(1)._argcount == 2


def test_can_be_used_as_predicate_argcount_is_known():
    def is_positive(x: int) -> bool:
        return x > 0

    assert _.filter_([-1, 0, 1], _.negate(is_positive)) == [-1, 0]
